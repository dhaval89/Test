(() => {
  var t = { id: 883, ids: [883] };
  t.modules = {
    72934: (t) => {
      "use strict";
      t.exports = require("next/dist/client/components/action-async-storage.external.js");
    },
    54580: (t) => {
      "use strict";
      t.exports = require("next/dist/client/components/request-async-storage.external.js");
    },
    45869: (t) => {
      "use strict";
      t.exports = require("next/dist/client/components/static-generation-async-storage.external.js");
    },
    20399: (t) => {
      "use strict";
      t.exports = require("next/dist/compiled/next-server/app-page.runtime.prod.js");
    },
    39491: (t) => {
      "use strict";
      t.exports = require("assert");
    },
    82361: (t) => {
      "use strict";
      t.exports = require("events");
    },
    57147: (t) => {
      "use strict";
      t.exports = require("fs");
    },
    13685: (t) => {
      "use strict";
      t.exports = require("http");
    },
    95687: (t) => {
      "use strict";
      t.exports = require("https");
    },
    22037: (t) => {
      "use strict";
      t.exports = require("os");
    },
    71017: (t) => {
      "use strict";
      t.exports = require("path");
    },
    12781: (t) => {
      "use strict";
      t.exports = require("stream");
    },
    76224: (t) => {
      "use strict";
      t.exports = require("tty");
    },
    57310: (t) => {
      "use strict";
      t.exports = require("url");
    },
    73837: (t) => {
      "use strict";
      t.exports = require("util");
    },
    59796: (t) => {
      "use strict";
      t.exports = require("zlib");
    },
    31772: (t, e, i) => {
      "use strict";
      i.r(e),
        i.d(e, {
          GlobalError: () => o.a,
          __next_app__: () => d,
          originalPathname: () => u,
          pages: () => c,
          routeModule: () => g,
          tree: () => h,
        });
      i(30746), i(66485), i(35866);
      var n = i(23191),
        s = i(88716),
        r = i(37922),
        o = i.n(r),
        a = i(95231),
        l = {};
      for (const f in a)
        [
          "default",
          "tree",
          "pages",
          "GlobalError",
          "originalPathname",
          "__next_app__",
          "routeModule",
        ].indexOf(f) < 0 && (l[f] = () => a[f]);
      i.d(e, l);
      const h = [
          "",
          {
            children: [
              "map",
              {
                children: [
                  "__PAGE__",
                  {},
                  {
                    page: [
                      () => Promise.resolve().then(i.bind(i, 30746)),
                      "/Users/sunny/Developer/LiveBird-Project/rapidus/rapidus/src/app/map/page.tsx",
                    ],
                  },
                ],
              },
              {
                layout: [
                  () => Promise.resolve().then(i.bind(i, 66485)),
                  "/Users/sunny/Developer/LiveBird-Project/rapidus/rapidus/src/app/map/layout.tsx",
                ],
                metadata: {
                  icon: [
                    async (t) =>
                      (await Promise.resolve().then(i.bind(i, 73881))).default(
                        t
                      ),
                  ],
                  apple: [],
                  openGraph: [],
                  twitter: [],
                  manifest: void 0,
                },
              },
            ],
          },
          {
            "not-found": [
              () => Promise.resolve().then(i.t.bind(i, 35866, 23)),
              "next/dist/client/components/not-found-error",
            ],
            metadata: {
              icon: [
                async (t) =>
                  (await Promise.resolve().then(i.bind(i, 73881))).default(t),
              ],
              apple: [],
              openGraph: [],
              twitter: [],
              manifest: void 0,
            },
          },
        ],
        c = [
          "/Users/sunny/Developer/LiveBird-Project/rapidus/rapidus/src/app/map/page.tsx",
        ],
        u = "/map/page",
        d = { require: i, loadChunk: () => Promise.resolve() },
        g = new n.AppPageRouteModule({
          definition: {
            kind: s.x.APP_PAGE,
            page: "/map/page",
            pathname: "/map",
            bundlePath: "",
            filename: "",
            appPaths: [],
          },
          userland: { loaderTree: h },
        });
    },
    65895: (t, e, i) => {
      Promise.resolve().then(i.bind(i, 26251));
    },
    29534: (t, e, i) => {
      Promise.resolve().then(i.bind(i, 7557));
    },
    26251: (t, e, i) => {
      "use strict";
      i.r(e), i.d(e, { default: () => l });
      var n = i(10326),
        s = i(35755),
        r = i(75669);
      const o = {
          title: "ZICTA - Geocodes of Zambia",
          description: "ZICTA - Geocodes of Zambia",
        },
        a = (0, r.Z)({
          palette: {
            primary: { main: "#023689" },
            secondary: { main: "#dc004e" },
          },
        });
      function l({ children: t }) {
        return n.jsx(s.b, {
          theme: a,
          children: (0, n.jsxs)("html", {
            lang: "en",
            children: [
              (0, n.jsxs)("head", {
                children: [
                  n.jsx("title", { children: o.title }),
                  n.jsx("meta", {
                    name: "description",
                    content: o.description,
                  }),
                ],
              }),
              n.jsx("body", {
                style: { margin: "0px !important" },
                children: t,
              }),
            ],
          }),
        });
      }
    },
    7557: (t, e, i) => {
      "use strict";
      i.r(e), i.d(e, { default: () => Yc });
      var n = i(10326),
        s = i(17577),
        r = i.n(s);
      i(73914);
      const o = class {
          constructor(t) {
            this.propagationStopped,
              this.defaultPrevented,
              (this.type = t),
              (this.target = null);
          }
          preventDefault() {
            this.defaultPrevented = !0;
          }
          stopPropagation() {
            this.propagationStopped = !0;
          }
        },
        a = "propertychange";
      const l = class {
        constructor() {
          this.disposed = !1;
        }
        dispose() {
          this.disposed || ((this.disposed = !0), this.disposeInternal());
        }
        disposeInternal() {}
      };
      function h(t, e) {
        return t > e ? 1 : t < e ? -1 : 0;
      }
      function c(t, e, i) {
        if (t[0] <= e) return 0;
        const n = t.length;
        if (e <= t[n - 1]) return n - 1;
        if ("function" === typeof i) {
          for (let s = 1; s < n; ++s) {
            const n = t[s];
            if (n === e) return s;
            if (n < e) return i(e, t[s - 1], n) > 0 ? s - 1 : s;
          }
          return n - 1;
        }
        if (i > 0) {
          for (let i = 1; i < n; ++i) if (t[i] < e) return i - 1;
          return n - 1;
        }
        if (i < 0) {
          for (let i = 1; i < n; ++i) if (t[i] <= e) return i;
          return n - 1;
        }
        for (let s = 1; s < n; ++s) {
          if (t[s] == e) return s;
          if (t[s] < e) return t[s - 1] - e < e - t[s] ? s - 1 : s;
        }
        return n - 1;
      }
      function u(t, e, i) {
        for (; e < i; ) {
          const n = t[e];
          (t[e] = t[i]), (t[i] = n), ++e, --i;
        }
      }
      function d(t, e) {
        const i = Array.isArray(e) ? e : [e],
          n = i.length;
        for (let s = 0; s < n; s++) t[t.length] = i[s];
      }
      function g(t, e) {
        const i = t.length;
        if (i !== e.length) return !1;
        for (let n = 0; n < i; n++) if (t[n] !== e[n]) return !1;
        return !0;
      }
      function f() {
        return !0;
      }
      function p() {
        return !1;
      }
      function m() {}
      function _(t) {
        let e, i, n;
        return function () {
          const s = Array.prototype.slice.call(arguments);
          return (
            (i && this === n && g(s, i)) ||
              ((n = this), (i = s), (e = t.apply(this, arguments))),
            e
          );
        };
      }
      function y(t) {
        for (const e in t) delete t[e];
      }
      function x(t) {
        let e;
        for (e in t) return !1;
        return !e;
      }
      const v = class extends l {
          constructor(t) {
            super(),
              (this.eventTarget_ = t),
              (this.pendingRemovals_ = null),
              (this.dispatching_ = null),
              (this.listeners_ = null);
          }
          addEventListener(t, e) {
            if (!t || !e) return;
            const i = this.listeners_ || (this.listeners_ = {}),
              n = i[t] || (i[t] = []);
            n.includes(e) || n.push(e);
          }
          dispatchEvent(t) {
            const e = "string" === typeof t,
              i = e ? t : t.type,
              n = this.listeners_ && this.listeners_[i];
            if (!n) return;
            const s = e ? new o(t) : t;
            s.target || (s.target = this.eventTarget_ || this);
            const r = this.dispatching_ || (this.dispatching_ = {}),
              a = this.pendingRemovals_ || (this.pendingRemovals_ = {});
            let l;
            i in r || ((r[i] = 0), (a[i] = 0)), ++r[i];
            for (let o = 0, h = n.length; o < h; ++o)
              if (
                ((l =
                  "handleEvent" in n[o]
                    ? n[o].handleEvent(s)
                    : n[o].call(this, s)),
                !1 === l || s.propagationStopped)
              ) {
                l = !1;
                break;
              }
            if (0 === --r[i]) {
              let t = a[i];
              for (delete a[i]; t--; ) this.removeEventListener(i, m);
              delete r[i];
            }
            return l;
          }
          disposeInternal() {
            this.listeners_ && y(this.listeners_);
          }
          getListeners(t) {
            return (this.listeners_ && this.listeners_[t]) || void 0;
          }
          hasListener(t) {
            return (
              !!this.listeners_ &&
              (t
                ? t in this.listeners_
                : Object.keys(this.listeners_).length > 0)
            );
          }
          removeEventListener(t, e) {
            if (!this.listeners_) return;
            const i = this.listeners_[t];
            if (!i) return;
            const n = i.indexOf(e);
            -1 !== n &&
              (this.pendingRemovals_ && t in this.pendingRemovals_
                ? ((i[n] = m), ++this.pendingRemovals_[t])
                : (i.splice(n, 1),
                  0 === i.length && delete this.listeners_[t]));
          }
        },
        w = "change",
        S = "contextmenu",
        C = "dblclick";
      function b(t, e, i, n, s) {
        if (s) {
          const s = i;
          i = function () {
            t.removeEventListener(e, i), s.apply(n ?? this, arguments);
          };
        } else n && n !== t && (i = i.bind(n));
        const r = { target: t, type: e, listener: i };
        return t.addEventListener(e, i), r;
      }
      function k(t, e, i, n) {
        return b(t, e, i, n, !0);
      }
      function M(t) {
        t &&
          t.target &&
          (t.target.removeEventListener(t.type, t.listener), y(t));
      }
      class I extends v {
        constructor() {
          super(),
            (this.on = this.onInternal),
            (this.once = this.onceInternal),
            (this.un = this.unInternal),
            (this.revision_ = 0);
        }
        changed() {
          ++this.revision_, this.dispatchEvent(w);
        }
        getRevision() {
          return this.revision_;
        }
        onInternal(t, e) {
          if (Array.isArray(t)) {
            const i = t.length,
              n = new Array(i);
            for (let s = 0; s < i; ++s) n[s] = b(this, t[s], e);
            return n;
          }
          return b(this, t, e);
        }
        onceInternal(t, e) {
          let i;
          if (Array.isArray(t)) {
            const n = t.length;
            i = new Array(n);
            for (let s = 0; s < n; ++s) i[s] = k(this, t[s], e);
          } else i = k(this, t, e);
          return (e.ol_key = i), i;
        }
        unInternal(t, e) {
          const i = e.ol_key;
          if (i)
            !(function (t) {
              if (Array.isArray(t))
                for (let e = 0, i = t.length; e < i; ++e) M(t[e]);
              else M(t);
            })(i);
          else if (Array.isArray(t))
            for (let n = 0, s = t.length; n < s; ++n)
              this.removeEventListener(t[n], e);
          else this.removeEventListener(t, e);
        }
      }
      I.prototype.on, I.prototype.once, I.prototype.un;
      const E = I;
      function R() {
        throw new Error("Unimplemented abstract method.");
      }
      let P = 0;
      function F(t) {
        return t.ol_uid || (t.ol_uid = String(++P));
      }
      class L extends o {
        constructor(t, e, i) {
          super(t), (this.key = e), (this.oldValue = i);
        }
      }
      const T = class extends E {
        constructor(t) {
          super(),
            this.on,
            this.once,
            this.un,
            F(this),
            (this.values_ = null),
            void 0 !== t && this.setProperties(t);
        }
        get(t) {
          let e;
          return (
            this.values_ &&
              this.values_.hasOwnProperty(t) &&
              (e = this.values_[t]),
            e
          );
        }
        getKeys() {
          return (this.values_ && Object.keys(this.values_)) || [];
        }
        getProperties() {
          return (this.values_ && Object.assign({}, this.values_)) || {};
        }
        getPropertiesInternal() {
          return this.values_;
        }
        hasProperties() {
          return !!this.values_;
        }
        notify(t, e) {
          let i;
          (i = `change:${t}`),
            this.hasListener(i) && this.dispatchEvent(new L(i, t, e)),
            (i = a),
            this.hasListener(i) && this.dispatchEvent(new L(i, t, e));
        }
        addChangeListener(t, e) {
          this.addEventListener(`change:${t}`, e);
        }
        removeChangeListener(t, e) {
          this.removeEventListener(`change:${t}`, e);
        }
        set(t, e, i) {
          const n = this.values_ || (this.values_ = {});
          if (i) n[t] = e;
          else {
            const i = n[t];
            (n[t] = e), i !== e && this.notify(t, i);
          }
        }
        setProperties(t, e) {
          for (const i in t) this.set(i, t[i], e);
        }
        applyProperties(t) {
          t.values_ &&
            Object.assign(this.values_ || (this.values_ = {}), t.values_);
        }
        unset(t, e) {
          if (this.values_ && t in this.values_) {
            const i = this.values_[t];
            delete this.values_[t],
              x(this.values_) && (this.values_ = null),
              e || this.notify(t, i);
          }
        }
      };
      function D(t, e) {
        if (!t) throw new Error(e);
      }
      class A extends T {
        constructor(t) {
          if (
            (super(),
            this.on,
            this.once,
            this.un,
            (this.id_ = void 0),
            (this.geometryName_ = "geometry"),
            (this.style_ = null),
            (this.styleFunction_ = void 0),
            (this.geometryChangeKey_ = null),
            this.addChangeListener(
              this.geometryName_,
              this.handleGeometryChanged_
            ),
            t)
          )
            if ("function" === typeof t.getSimplifiedGeometry) {
              const e = t;
              this.setGeometry(e);
            } else {
              const e = t;
              this.setProperties(e);
            }
        }
        clone() {
          const t = new A(this.hasProperties() ? this.getProperties() : null);
          t.setGeometryName(this.getGeometryName());
          const e = this.getGeometry();
          e && t.setGeometry(e.clone());
          const i = this.getStyle();
          return i && t.setStyle(i), t;
        }
        getGeometry() {
          return this.get(this.geometryName_);
        }
        getId() {
          return this.id_;
        }
        getGeometryName() {
          return this.geometryName_;
        }
        getStyle() {
          return this.style_;
        }
        getStyleFunction() {
          return this.styleFunction_;
        }
        handleGeometryChange_() {
          this.changed();
        }
        handleGeometryChanged_() {
          this.geometryChangeKey_ &&
            (M(this.geometryChangeKey_), (this.geometryChangeKey_ = null));
          const t = this.getGeometry();
          t &&
            (this.geometryChangeKey_ = b(
              t,
              w,
              this.handleGeometryChange_,
              this
            )),
            this.changed();
        }
        setGeometry(t) {
          this.set(this.geometryName_, t);
        }
        setStyle(t) {
          (this.style_ = t),
            (this.styleFunction_ = t
              ? (function (t) {
                  if ("function" === typeof t) return t;
                  let e;
                  if (Array.isArray(t)) e = t;
                  else {
                    D(
                      "function" === typeof t.getZIndex,
                      "Expected an `ol/style/Style` or an array of `ol/style/Style.js`"
                    );
                    e = [t];
                  }
                  return function () {
                    return e;
                  };
                })(t)
              : void 0),
            this.changed();
        }
        setId(t) {
          (this.id_ = t), this.changed();
        }
        setGeometryName(t) {
          this.removeChangeListener(
            this.geometryName_,
            this.handleGeometryChanged_
          ),
            (this.geometryName_ = t),
            this.addChangeListener(
              this.geometryName_,
              this.handleGeometryChanged_
            ),
            this.handleGeometryChanged_();
        }
      }
      const O = A,
        j = "add",
        G = "remove",
        Z = "length";
      class z extends o {
        constructor(t, e, i) {
          super(t), (this.element = e), (this.index = i);
        }
      }
      const B = class extends T {
        constructor(t, e) {
          if (
            (super(),
            this.on,
            this.once,
            this.un,
            (e = e || {}),
            (this.unique_ = !!e.unique),
            (this.array_ = t || []),
            this.unique_)
          )
            for (let i = 0, n = this.array_.length; i < n; ++i)
              this.assertUnique_(this.array_[i], i);
          this.updateLength_();
        }
        clear() {
          for (; this.getLength() > 0; ) this.pop();
        }
        extend(t) {
          for (let e = 0, i = t.length; e < i; ++e) this.push(t[e]);
          return this;
        }
        forEach(t) {
          const e = this.array_;
          for (let i = 0, n = e.length; i < n; ++i) t(e[i], i, e);
        }
        getArray() {
          return this.array_;
        }
        item(t) {
          return this.array_[t];
        }
        getLength() {
          return this.get(Z);
        }
        insertAt(t, e) {
          if (t < 0 || t > this.getLength())
            throw new Error("Index out of bounds: " + t);
          this.unique_ && this.assertUnique_(e),
            this.array_.splice(t, 0, e),
            this.updateLength_(),
            this.dispatchEvent(new z(j, e, t));
        }
        pop() {
          return this.removeAt(this.getLength() - 1);
        }
        push(t) {
          this.unique_ && this.assertUnique_(t);
          const e = this.getLength();
          return this.insertAt(e, t), this.getLength();
        }
        remove(t) {
          const e = this.array_;
          for (let i = 0, n = e.length; i < n; ++i)
            if (e[i] === t) return this.removeAt(i);
        }
        removeAt(t) {
          if (t < 0 || t >= this.getLength()) return;
          const e = this.array_[t];
          return (
            this.array_.splice(t, 1),
            this.updateLength_(),
            this.dispatchEvent(new z(G, e, t)),
            e
          );
        }
        setAt(t, e) {
          if (t >= this.getLength()) return void this.insertAt(t, e);
          if (t < 0) throw new Error("Index out of bounds: " + t);
          this.unique_ && this.assertUnique_(e, t);
          const i = this.array_[t];
          (this.array_[t] = e),
            this.dispatchEvent(new z(G, i, t)),
            this.dispatchEvent(new z(j, e, t));
        }
        updateLength_() {
          this.set(Z, this.array_.length);
        }
        assertUnique_(t, e) {
          for (let i = 0, n = this.array_.length; i < n; ++i)
            if (this.array_[i] === t && i !== e)
              throw new Error("Duplicate item added to a unique collection");
        }
      };
      function N(t, e, i = 0, n = t.length - 1, s = X) {
        for (; n > i; ) {
          if (n - i > 600) {
            const r = n - i + 1,
              o = e - i + 1,
              a = Math.log(r),
              l = 0.5 * Math.exp((2 * a) / 3),
              h =
                0.5 *
                Math.sqrt((a * l * (r - l)) / r) *
                (o - r / 2 < 0 ? -1 : 1);
            N(
              t,
              e,
              Math.max(i, Math.floor(e - (o * l) / r + h)),
              Math.min(n, Math.floor(e + ((r - o) * l) / r + h)),
              s
            );
          }
          const r = t[e];
          let o = i,
            a = n;
          for (W(t, i, e), s(t[n], r) > 0 && W(t, i, n); o < a; ) {
            for (W(t, o, a), o++, a--; s(t[o], r) < 0; ) o++;
            for (; s(t[a], r) > 0; ) a--;
          }
          0 === s(t[i], r) ? W(t, i, a) : (a++, W(t, a, n)),
            a <= e && (i = a + 1),
            e <= a && (n = a - 1);
        }
      }
      function W(t, e, i) {
        const n = t[e];
        (t[e] = t[i]), (t[i] = n);
      }
      function X(t, e) {
        return t < e ? -1 : t > e ? 1 : 0;
      }
      class Y {
        constructor(t = 9) {
          (this._maxEntries = Math.max(4, t)),
            (this._minEntries = Math.max(2, Math.ceil(0.4 * this._maxEntries))),
            this.clear();
        }
        all() {
          return this._all(this.data, []);
        }
        search(t) {
          let e = this.data;
          const i = [];
          if (!it(t, e)) return i;
          const n = this.toBBox,
            s = [];
          for (; e; ) {
            for (let r = 0; r < e.children.length; r++) {
              const o = e.children[r],
                a = e.leaf ? n(o) : o;
              it(t, a) &&
                (e.leaf ? i.push(o) : et(t, a) ? this._all(o, i) : s.push(o));
            }
            e = s.pop();
          }
          return i;
        }
        collides(t) {
          let e = this.data;
          if (!it(t, e)) return !1;
          const i = [];
          for (; e; ) {
            for (let n = 0; n < e.children.length; n++) {
              const s = e.children[n],
                r = e.leaf ? this.toBBox(s) : s;
              if (it(t, r)) {
                if (e.leaf || et(t, r)) return !0;
                i.push(s);
              }
            }
            e = i.pop();
          }
          return !1;
        }
        load(t) {
          if (!t || !t.length) return this;
          if (t.length < this._minEntries) {
            for (let e = 0; e < t.length; e++) this.insert(t[e]);
            return this;
          }
          let e = this._build(t.slice(), 0, t.length - 1, 0);
          if (this.data.children.length)
            if (this.data.height === e.height) this._splitRoot(this.data, e);
            else {
              if (this.data.height < e.height) {
                const t = this.data;
                (this.data = e), (e = t);
              }
              this._insert(e, this.data.height - e.height - 1, !0);
            }
          else this.data = e;
          return this;
        }
        insert(t) {
          return t && this._insert(t, this.data.height - 1), this;
        }
        clear() {
          return (this.data = nt([])), this;
        }
        remove(t, e) {
          if (!t) return this;
          let i = this.data;
          const n = this.toBBox(t),
            s = [],
            r = [];
          let o, a, l;
          for (; i || s.length; ) {
            if (
              (i ||
                ((i = s.pop()), (a = s[s.length - 1]), (o = r.pop()), (l = !0)),
              i.leaf)
            ) {
              const n = V(t, i.children, e);
              if (-1 !== n)
                return (
                  i.children.splice(n, 1), s.push(i), this._condense(s), this
                );
            }
            l || i.leaf || !et(i, n)
              ? a
                ? (o++, (i = a.children[o]), (l = !1))
                : (i = null)
              : (s.push(i), r.push(o), (o = 0), (a = i), (i = i.children[0]));
          }
          return this;
        }
        toBBox(t) {
          return t;
        }
        compareMinX(t, e) {
          return t.minX - e.minX;
        }
        compareMinY(t, e) {
          return t.minY - e.minY;
        }
        toJSON() {
          return this.data;
        }
        fromJSON(t) {
          return (this.data = t), this;
        }
        _all(t, e) {
          const i = [];
          for (; t; )
            t.leaf ? e.push(...t.children) : i.push(...t.children),
              (t = i.pop());
          return e;
        }
        _build(t, e, i, n) {
          const s = i - e + 1;
          let r,
            o = this._maxEntries;
          if (s <= o) return (r = nt(t.slice(e, i + 1))), q(r, this.toBBox), r;
          n ||
            ((n = Math.ceil(Math.log(s) / Math.log(o))),
            (o = Math.ceil(s / Math.pow(o, n - 1)))),
            (r = nt([])),
            (r.leaf = !1),
            (r.height = n);
          const a = Math.ceil(s / o),
            l = a * Math.ceil(Math.sqrt(o));
          st(t, e, i, l, this.compareMinX);
          for (let h = e; h <= i; h += l) {
            const e = Math.min(h + l - 1, i);
            st(t, h, e, a, this.compareMinY);
            for (let i = h; i <= e; i += a) {
              const s = Math.min(i + a - 1, e);
              r.children.push(this._build(t, i, s, n - 1));
            }
          }
          return q(r, this.toBBox), r;
        }
        _chooseSubtree(t, e, i, n) {
          for (; n.push(e), !e.leaf && n.length - 1 !== i; ) {
            let i,
              n = 1 / 0,
              o = 1 / 0;
            for (let a = 0; a < e.children.length; a++) {
              const l = e.children[a],
                h = J(l),
                c =
                  ((s = t),
                  (r = l),
                  (Math.max(r.maxX, s.maxX) - Math.min(r.minX, s.minX)) *
                    (Math.max(r.maxY, s.maxY) - Math.min(r.minY, s.minY)) -
                    h);
              c < o
                ? ((o = c), (n = h < n ? h : n), (i = l))
                : c === o && h < n && ((n = h), (i = l));
            }
            e = i || e.children[0];
          }
          var s, r;
          return e;
        }
        _insert(t, e, i) {
          const n = i ? t : this.toBBox(t),
            s = [],
            r = this._chooseSubtree(n, this.data, e, s);
          for (
            r.children.push(t), U(r, n);
            e >= 0 && s[e].children.length > this._maxEntries;

          )
            this._split(s, e), e--;
          this._adjustParentBBoxes(n, s, e);
        }
        _split(t, e) {
          const i = t[e],
            n = i.children.length,
            s = this._minEntries;
          this._chooseSplitAxis(i, s, n);
          const r = this._chooseSplitIndex(i, s, n),
            o = nt(i.children.splice(r, i.children.length - r));
          (o.height = i.height),
            (o.leaf = i.leaf),
            q(i, this.toBBox),
            q(o, this.toBBox),
            e ? t[e - 1].children.push(o) : this._splitRoot(i, o);
        }
        _splitRoot(t, e) {
          (this.data = nt([t, e])),
            (this.data.height = t.height + 1),
            (this.data.leaf = !1),
            q(this.data, this.toBBox);
        }
        _chooseSplitIndex(t, e, i) {
          let n,
            s = 1 / 0,
            r = 1 / 0;
          for (let o = e; o <= i - e; o++) {
            const e = $(t, 0, o, this.toBBox),
              a = $(t, o, i, this.toBBox),
              l = tt(e, a),
              h = J(e) + J(a);
            l < s
              ? ((s = l), (n = o), (r = h < r ? h : r))
              : l === s && h < r && ((r = h), (n = o));
          }
          return n || i - e;
        }
        _chooseSplitAxis(t, e, i) {
          const n = t.leaf ? this.compareMinX : H,
            s = t.leaf ? this.compareMinY : K;
          this._allDistMargin(t, e, i, n) < this._allDistMargin(t, e, i, s) &&
            t.children.sort(n);
        }
        _allDistMargin(t, e, i, n) {
          t.children.sort(n);
          const s = this.toBBox,
            r = $(t, 0, e, s),
            o = $(t, i - e, i, s);
          let a = Q(r) + Q(o);
          for (let l = e; l < i - e; l++) {
            const e = t.children[l];
            U(r, t.leaf ? s(e) : e), (a += Q(r));
          }
          for (let l = i - e - 1; l >= e; l--) {
            const e = t.children[l];
            U(o, t.leaf ? s(e) : e), (a += Q(o));
          }
          return a;
        }
        _adjustParentBBoxes(t, e, i) {
          for (let n = i; n >= 0; n--) U(e[n], t);
        }
        _condense(t) {
          for (let e, i = t.length - 1; i >= 0; i--)
            0 === t[i].children.length
              ? i > 0
                ? ((e = t[i - 1].children), e.splice(e.indexOf(t[i]), 1))
                : this.clear()
              : q(t[i], this.toBBox);
        }
      }
      function V(t, e, i) {
        if (!i) return e.indexOf(t);
        for (let n = 0; n < e.length; n++) if (i(t, e[n])) return n;
        return -1;
      }
      function q(t, e) {
        $(t, 0, t.children.length, e, t);
      }
      function $(t, e, i, n, s) {
        s || (s = nt(null)),
          (s.minX = 1 / 0),
          (s.minY = 1 / 0),
          (s.maxX = -1 / 0),
          (s.maxY = -1 / 0);
        for (let r = e; r < i; r++) {
          const e = t.children[r];
          U(s, t.leaf ? n(e) : e);
        }
        return s;
      }
      function U(t, e) {
        return (
          (t.minX = Math.min(t.minX, e.minX)),
          (t.minY = Math.min(t.minY, e.minY)),
          (t.maxX = Math.max(t.maxX, e.maxX)),
          (t.maxY = Math.max(t.maxY, e.maxY)),
          t
        );
      }
      function H(t, e) {
        return t.minX - e.minX;
      }
      function K(t, e) {
        return t.minY - e.minY;
      }
      function J(t) {
        return (t.maxX - t.minX) * (t.maxY - t.minY);
      }
      function Q(t) {
        return t.maxX - t.minX + (t.maxY - t.minY);
      }
      function tt(t, e) {
        const i = Math.max(t.minX, e.minX),
          n = Math.max(t.minY, e.minY),
          s = Math.min(t.maxX, e.maxX),
          r = Math.min(t.maxY, e.maxY);
        return Math.max(0, s - i) * Math.max(0, r - n);
      }
      function et(t, e) {
        return (
          t.minX <= e.minX &&
          t.minY <= e.minY &&
          e.maxX <= t.maxX &&
          e.maxY <= t.maxY
        );
      }
      function it(t, e) {
        return (
          e.minX <= t.maxX &&
          e.minY <= t.maxY &&
          e.maxX >= t.minX &&
          e.maxY >= t.minY
        );
      }
      function nt(t) {
        return {
          children: t,
          height: 1,
          leaf: !0,
          minX: 1 / 0,
          minY: 1 / 0,
          maxX: -1 / 0,
          maxY: -1 / 0,
        };
      }
      function st(t, e, i, n, s) {
        const r = [e, i];
        for (; r.length; ) {
          if ((i = r.pop()) - (e = r.pop()) <= n) continue;
          const o = e + Math.ceil((i - e) / n / 2) * n;
          N(t, o, e, i, s), r.push(e, o, o, i);
        }
      }
      const rt = {
        UNKNOWN: 0,
        INTERSECTING: 1,
        ABOVE: 2,
        RIGHT: 4,
        BELOW: 8,
        LEFT: 16,
      };
      function ot(t) {
        const e = gt();
        for (let i = 0, n = t.length; i < n; ++i) vt(e, t[i]);
        return e;
      }
      function at(t, e, i) {
        return i
          ? ((i[0] = t[0] - e),
            (i[1] = t[1] - e),
            (i[2] = t[2] + e),
            (i[3] = t[3] + e),
            i)
          : [t[0] - e, t[1] - e, t[2] + e, t[3] + e];
      }
      function lt(t, e, i) {
        let n, s;
        return (
          (n = e < t[0] ? t[0] - e : t[2] < e ? e - t[2] : 0),
          (s = i < t[1] ? t[1] - i : t[3] < i ? i - t[3] : 0),
          n * n + s * s
        );
      }
      function ht(t, e) {
        return ut(t, e[0], e[1]);
      }
      function ct(t, e) {
        return t[0] <= e[0] && e[2] <= t[2] && t[1] <= e[1] && e[3] <= t[3];
      }
      function ut(t, e, i) {
        return t[0] <= e && e <= t[2] && t[1] <= i && i <= t[3];
      }
      function dt(t, e) {
        const i = t[0],
          n = t[1],
          s = t[2],
          r = t[3],
          o = e[0],
          a = e[1];
        let l = rt.UNKNOWN;
        return (
          o < i ? (l |= rt.LEFT) : o > s && (l |= rt.RIGHT),
          a < n ? (l |= rt.BELOW) : a > r && (l |= rt.ABOVE),
          l === rt.UNKNOWN && (l = rt.INTERSECTING),
          l
        );
      }
      function gt() {
        return [1 / 0, 1 / 0, -1 / 0, -1 / 0];
      }
      function ft(t, e, i, n, s) {
        return s
          ? ((s[0] = t), (s[1] = e), (s[2] = i), (s[3] = n), s)
          : [t, e, i, n];
      }
      function pt(t) {
        return ft(1 / 0, 1 / 0, -1 / 0, -1 / 0, t);
      }
      function mt(t, e) {
        const i = t[0],
          n = t[1];
        return ft(i, n, i, n, e);
      }
      function _t(t, e, i, n, s) {
        return wt(pt(s), t, e, i, n);
      }
      function yt(t, e) {
        return t[0] == e[0] && t[2] == e[2] && t[1] == e[1] && t[3] == e[3];
      }
      function xt(t, e) {
        return (
          e[0] < t[0] && (t[0] = e[0]),
          e[2] > t[2] && (t[2] = e[2]),
          e[1] < t[1] && (t[1] = e[1]),
          e[3] > t[3] && (t[3] = e[3]),
          t
        );
      }
      function vt(t, e) {
        e[0] < t[0] && (t[0] = e[0]),
          e[0] > t[2] && (t[2] = e[0]),
          e[1] < t[1] && (t[1] = e[1]),
          e[1] > t[3] && (t[3] = e[1]);
      }
      function wt(t, e, i, n, s) {
        for (; i < n; i += s) St(t, e[i], e[i + 1]);
        return t;
      }
      function St(t, e, i) {
        (t[0] = Math.min(t[0], e)),
          (t[1] = Math.min(t[1], i)),
          (t[2] = Math.max(t[2], e)),
          (t[3] = Math.max(t[3], i));
      }
      function Ct(t, e) {
        let i;
        return (
          (i = e(bt(t))),
          i ||
            ((i = e(kt(t))),
            i || ((i = e(Pt(t))), i || ((i = e(Rt(t))), i || !1)))
        );
      }
      function bt(t) {
        return [t[0], t[1]];
      }
      function kt(t) {
        return [t[2], t[1]];
      }
      function Mt(t) {
        return [(t[0] + t[2]) / 2, (t[1] + t[3]) / 2];
      }
      function It(t, e, i, n, s) {
        const [r, o, a, l, h, c, u, d] = (function (t, e, i, n) {
          const s = (e * n[0]) / 2,
            r = (e * n[1]) / 2,
            o = Math.cos(i),
            a = Math.sin(i),
            l = s * o,
            h = s * a,
            c = r * o,
            u = r * a,
            d = t[0],
            g = t[1];
          return [
            d - l + u,
            g - h - c,
            d - l - u,
            g - h + c,
            d + l - u,
            g + h + c,
            d + l + u,
            g + h - c,
            d - l + u,
            g - h - c,
          ];
        })(t, e, i, n);
        return ft(
          Math.min(r, a, h, u),
          Math.min(o, l, c, d),
          Math.max(r, a, h, u),
          Math.max(o, l, c, d),
          s
        );
      }
      function Et(t) {
        return t[3] - t[1];
      }
      function Rt(t) {
        return [t[0], t[3]];
      }
      function Pt(t) {
        return [t[2], t[3]];
      }
      function Ft(t) {
        return t[2] - t[0];
      }
      function Lt(t, e) {
        return t[0] <= e[2] && t[2] >= e[0] && t[1] <= e[3] && t[3] >= e[1];
      }
      function Tt(t) {
        return t[2] < t[0] || t[3] < t[1];
      }
      function Dt(t, e, i, n) {
        if (Tt(t)) return pt(i);
        let s = [];
        if (n > 1) {
          const e = t[2] - t[0],
            i = t[3] - t[1];
          for (let r = 0; r < n; ++r)
            s.push(
              t[0] + (e * r) / n,
              t[1],
              t[2],
              t[1] + (i * r) / n,
              t[2] - (e * r) / n,
              t[3],
              t[0],
              t[3] - (i * r) / n
            );
        } else s = [t[0], t[1], t[2], t[1], t[2], t[3], t[0], t[3]];
        e(s, s, 2);
        const r = [],
          o = [];
        for (let a = 0, l = s.length; a < l; a += 2)
          r.push(s[a]), o.push(s[a + 1]);
        return (function (t, e, i) {
          return ft(
            Math.min.apply(null, t),
            Math.min.apply(null, e),
            Math.max.apply(null, t),
            Math.max.apply(null, e),
            i
          );
        })(r, o, i);
      }
      function At(t, e) {
        const i = e.getExtent(),
          n = Mt(t);
        if (e.canWrapX() && (n[0] < i[0] || n[0] >= i[2])) {
          const e = Ft(i),
            s = Math.floor((n[0] - i[0]) / e) * e;
          (t[0] -= s), (t[2] -= s);
        }
        return t;
      }
      const Ot = class {
        constructor(t) {
          (this.rbush_ = new Y(t)), (this.items_ = {});
        }
        insert(t, e) {
          const i = {
            minX: t[0],
            minY: t[1],
            maxX: t[2],
            maxY: t[3],
            value: e,
          };
          this.rbush_.insert(i), (this.items_[F(e)] = i);
        }
        load(t, e) {
          const i = new Array(e.length);
          for (let n = 0, s = e.length; n < s; n++) {
            const s = t[n],
              r = e[n],
              o = { minX: s[0], minY: s[1], maxX: s[2], maxY: s[3], value: r };
            (i[n] = o), (this.items_[F(r)] = o);
          }
          this.rbush_.load(i);
        }
        remove(t) {
          const e = F(t),
            i = this.items_[e];
          return delete this.items_[e], null !== this.rbush_.remove(i);
        }
        update(t, e) {
          const i = this.items_[F(e)];
          yt([i.minX, i.minY, i.maxX, i.maxY], t) ||
            (this.remove(e), this.insert(t, e));
        }
        getAll() {
          return this.rbush_.all().map(function (t) {
            return t.value;
          });
        }
        getInExtent(t) {
          const e = { minX: t[0], minY: t[1], maxX: t[2], maxY: t[3] };
          return this.rbush_.search(e).map(function (t) {
            return t.value;
          });
        }
        forEach(t) {
          return this.forEach_(this.getAll(), t);
        }
        forEachInExtent(t, e) {
          return this.forEach_(this.getInExtent(t), e);
        }
        forEach_(t, e) {
          let i;
          for (let n = 0, s = t.length; n < s; n++)
            if (((i = e(t[n])), i)) return i;
          return i;
        }
        isEmpty() {
          return x(this.items_);
        }
        clear() {
          this.rbush_.clear(), (this.items_ = {});
        }
        getExtent(t) {
          const e = this.rbush_.toJSON();
          return ft(e.minX, e.minY, e.maxX, e.maxY, t);
        }
        concat(t) {
          this.rbush_.load(t.rbush_.all());
          for (const e in t.items_) this.items_[e] = t.items_[e];
        }
      };
      new Array(6);
      function jt(t, e) {
        const i = e[0],
          n = e[1];
        return (
          (e[0] = t[0] * i + t[2] * n + t[4]),
          (e[1] = t[1] * i + t[3] * n + t[5]),
          e
        );
      }
      function Gt(t, e, i, n, s, r, o, a) {
        const l = Math.sin(r),
          h = Math.cos(r);
        return (
          (t[0] = n * h),
          (t[1] = s * l),
          (t[2] = -n * l),
          (t[3] = s * h),
          (t[4] = o * n * h - a * n * l + e),
          (t[5] = o * s * l + a * s * h + i),
          t
        );
      }
      function Zt(t, e) {
        const i = (n = e)[0] * n[3] - n[1] * n[2];
        var n;
        D(0 !== i, "Transformation matrix cannot be inverted");
        const s = e[0],
          r = e[1],
          o = e[2],
          a = e[3],
          l = e[4],
          h = e[5];
        return (
          (t[0] = a / i),
          (t[1] = -r / i),
          (t[2] = -o / i),
          (t[3] = s / i),
          (t[4] = (o * h - a * l) / i),
          (t[5] = -(s * h - r * l) / i),
          t
        );
      }
      const zt = [1e6, 1e6, 1e6, 1e6, 2, 2];
      function Bt(t) {
        return (
          "matrix(" +
          t.map((t, e) => Math.round(t * zt[e]) / zt[e]).join(", ") +
          ")"
        );
      }
      function Nt(t, e, i) {
        return Math.min(Math.max(t, e), i);
      }
      function Wt(t, e, i, n, s, r) {
        const o = s - i,
          a = r - n;
        if (0 !== o || 0 !== a) {
          const l = ((t - i) * o + (e - n) * a) / (o * o + a * a);
          l > 1 ? ((i = s), (n = r)) : l > 0 && ((i += o * l), (n += a * l));
        }
        return Xt(t, e, i, n);
      }
      function Xt(t, e, i, n) {
        const s = i - t,
          r = n - e;
        return s * s + r * r;
      }
      function Yt(t) {
        return (t * Math.PI) / 180;
      }
      function Vt(t, e) {
        const i = t % e;
        return i * e < 0 ? i + e : i;
      }
      function qt(t, e, i) {
        return t + i * (e - t);
      }
      function $t(t, e) {
        const i = Math.pow(10, e);
        return Math.round(t * i) / i;
      }
      function Ut(t, e, i, n, s, r, o) {
        const a = (i - e) / n;
        if (a < 3) {
          for (; e < i; e += n) (r[o++] = t[e]), (r[o++] = t[e + 1]);
          return o;
        }
        const l = new Array(a);
        (l[0] = 1), (l[a - 1] = 1);
        const h = [e, i - n];
        let c = 0;
        for (; h.length > 0; ) {
          const i = h.pop(),
            r = h.pop();
          let o = 0;
          const a = t[r],
            u = t[r + 1],
            d = t[i],
            g = t[i + 1];
          for (let e = r + n; e < i; e += n) {
            const i = Wt(t[e], t[e + 1], a, u, d, g);
            i > o && ((c = e), (o = i));
          }
          o > s &&
            ((l[(c - e) / n] = 1),
            r + n < c && h.push(r, c),
            c + n < i && h.push(c, i));
        }
        for (let u = 0; u < a; ++u)
          l[u] && ((r[o++] = t[e + u * n]), (r[o++] = t[e + u * n + 1]));
        return o;
      }
      function Ht(t, e, i, n, s, r, o, a) {
        for (let l = 0, h = i.length; l < h; ++l) {
          const h = i[l];
          (o = Ut(t, e, h, n, s, r, o)), a.push(o), (e = h);
        }
        return o;
      }
      function Kt(t, e) {
        return e * Math.round(t / e);
      }
      function Jt(t, e, i, n, s, r, o) {
        if (e == i) return o;
        let a,
          l,
          h = Kt(t[e], s),
          c = Kt(t[e + 1], s);
        (e += n), (r[o++] = h), (r[o++] = c);
        do {
          if (((a = Kt(t[e], s)), (l = Kt(t[e + 1], s)), (e += n) == i))
            return (r[o++] = a), (r[o++] = l), o;
        } while (a == h && l == c);
        for (; e < i; ) {
          const i = Kt(t[e], s),
            u = Kt(t[e + 1], s);
          if (((e += n), i == a && u == l)) continue;
          const d = a - h,
            g = l - c,
            f = i - h,
            p = u - c;
          d * p == g * f &&
          ((d < 0 && f < d) || d == f || (d > 0 && f > d)) &&
          ((g < 0 && p < g) || g == p || (g > 0 && p > g))
            ? ((a = i), (l = u))
            : ((r[o++] = a), (r[o++] = l), (h = a), (c = l), (a = i), (l = u));
        }
        return (r[o++] = a), (r[o++] = l), o;
      }
      function Qt(t, e, i, n, s, r, o, a) {
        for (let l = 0, h = i.length; l < h; ++l) {
          const h = i[l];
          (o = Jt(t, e, h, n, s, r, o)), a.push(o), (e = h);
        }
        return o;
      }
      function te(t, e, i, n, s) {
        return !Ct(s, function (s) {
          return !ee(t, e, i, n, s[0], s[1]);
        });
      }
      function ee(t, e, i, n, s, r) {
        let o = 0,
          a = t[i - n],
          l = t[i - n + 1];
        for (; e < i; e += n) {
          const i = t[e],
            n = t[e + 1];
          l <= r
            ? n > r && (i - a) * (r - l) - (s - a) * (n - l) > 0 && o++
            : n <= r && (i - a) * (r - l) - (s - a) * (n - l) < 0 && o--,
            (a = i),
            (l = n);
        }
        return 0 !== o;
      }
      function ie(t, e, i, n, s, r) {
        if (0 === i.length) return !1;
        if (!ee(t, e, i[0], n, s, r)) return !1;
        for (let o = 1, a = i.length; o < a; ++o)
          if (ee(t, i[o - 1], i[o], n, s, r)) return !1;
        return !0;
      }
      function ne(t, e, i, n, s, r, o) {
        let a, l, c, u, d, g, f;
        const p = s[r + 1],
          m = [];
        for (let h = 0, x = i.length; h < x; ++h) {
          const s = i[h];
          for (u = t[s - n], g = t[s - n + 1], a = e; a < s; a += n)
            (d = t[a]),
              (f = t[a + 1]),
              ((p <= g && f <= p) || (g <= p && p <= f)) &&
                ((c = ((p - g) / (f - g)) * (d - u) + u), m.push(c)),
              (u = d),
              (g = f);
        }
        let _ = NaN,
          y = -1 / 0;
        for (m.sort(h), u = m[0], a = 1, l = m.length; a < l; ++a) {
          d = m[a];
          const s = Math.abs(d - u);
          s > y &&
            ((c = (u + d) / 2), ie(t, e, i, n, c, p) && ((_ = c), (y = s))),
            (u = d);
        }
        return isNaN(_) && (_ = s[r]), o ? (o.push(_, p, y), o) : [_, p, y];
      }
      function se(t, e, i, n, s) {
        let r = [];
        for (let o = 0, a = i.length; o < a; ++o) {
          const a = i[o];
          (r = ne(t, e, a, n, s, 2 * o, r)), (e = a[a.length - 1]);
        }
        return r;
      }
      const re = {
        radians: 6370997 / (2 * Math.PI),
        degrees: (2 * Math.PI * 6370997) / 360,
        ft: 0.3048,
        m: 1,
        "us-ft": 1200 / 3937,
      };
      const oe = class {
          constructor(t) {
            (this.code_ = t.code),
              (this.units_ = t.units),
              (this.extent_ = void 0 !== t.extent ? t.extent : null),
              (this.worldExtent_ =
                void 0 !== t.worldExtent ? t.worldExtent : null),
              (this.axisOrientation_ =
                void 0 !== t.axisOrientation ? t.axisOrientation : "enu"),
              (this.global_ = void 0 !== t.global && t.global),
              (this.canWrapX_ = !(!this.global_ || !this.extent_)),
              (this.getPointResolutionFunc_ = t.getPointResolution),
              (this.defaultTileGrid_ = null),
              (this.metersPerUnit_ = t.metersPerUnit);
          }
          canWrapX() {
            return this.canWrapX_;
          }
          getCode() {
            return this.code_;
          }
          getExtent() {
            return this.extent_;
          }
          getUnits() {
            return this.units_;
          }
          getMetersPerUnit() {
            return this.metersPerUnit_ || re[this.units_];
          }
          getWorldExtent() {
            return this.worldExtent_;
          }
          getAxisOrientation() {
            return this.axisOrientation_;
          }
          isGlobal() {
            return this.global_;
          }
          setGlobal(t) {
            (this.global_ = t), (this.canWrapX_ = !(!t || !this.extent_));
          }
          getDefaultTileGrid() {
            return this.defaultTileGrid_;
          }
          setDefaultTileGrid(t) {
            this.defaultTileGrid_ = t;
          }
          setExtent(t) {
            (this.extent_ = t), (this.canWrapX_ = !(!this.global_ || !t));
          }
          setWorldExtent(t) {
            this.worldExtent_ = t;
          }
          setGetPointResolution(t) {
            this.getPointResolutionFunc_ = t;
          }
          getPointResolutionFunc() {
            return this.getPointResolutionFunc_;
          }
        },
        ae = 6378137,
        le = Math.PI * ae,
        he = [-le, -le, le, le],
        ce = [-180, -85, 180, 85],
        ue = ae * Math.log(Math.tan(Math.PI / 2));
      class de extends oe {
        constructor(t) {
          super({
            code: t,
            units: "m",
            extent: he,
            global: !0,
            worldExtent: ce,
            getPointResolution: function (t, e) {
              return t / Math.cosh(e[1] / ae);
            },
          });
        }
      }
      const ge = [
        new de("EPSG:3857"),
        new de("EPSG:102100"),
        new de("EPSG:102113"),
        new de("EPSG:900913"),
        new de("http://www.opengis.net/def/crs/EPSG/0/3857"),
        new de("http://www.opengis.net/gml/srs/epsg.xml#3857"),
      ];
      function fe(t, e, i, n) {
        const s = t.length;
        (i = i > 1 ? i : 2),
          (n = n ?? i),
          void 0 === e && (e = i > 2 ? t.slice() : new Array(s));
        for (let r = 0; r < s; r += n) {
          e[r] = (le * t[r]) / 180;
          let i = ae * Math.log(Math.tan((Math.PI * (+t[r + 1] + 90)) / 360));
          i > ue ? (i = ue) : i < -ue && (i = -ue), (e[r + 1] = i);
        }
        return e;
      }
      function pe(t, e, i, n) {
        const s = t.length;
        (i = i > 1 ? i : 2),
          (n = n ?? i),
          void 0 === e && (e = i > 2 ? t.slice() : new Array(s));
        for (let r = 0; r < s; r += n)
          (e[r] = (180 * t[r]) / le),
            (e[r + 1] =
              (360 * Math.atan(Math.exp(t[r + 1] / ae))) / Math.PI - 90);
        return e;
      }
      const me = [-180, -90, 180, 90],
        _e = (6378137 * Math.PI) / 180;
      class ye extends oe {
        constructor(t, e) {
          super({
            code: t,
            units: "degrees",
            extent: me,
            axisOrientation: e,
            global: !0,
            metersPerUnit: _e,
            worldExtent: me,
          });
        }
      }
      const xe = [
        new ye("CRS:84"),
        new ye("EPSG:4326", "neu"),
        new ye("urn:ogc:def:crs:OGC:1.3:CRS84"),
        new ye("urn:ogc:def:crs:OGC:2:84"),
        new ye("http://www.opengis.net/def/crs/OGC/1.3/CRS84"),
        new ye("http://www.opengis.net/gml/srs/epsg.xml#4326", "neu"),
        new ye("http://www.opengis.net/def/crs/EPSG/0/4326", "neu"),
      ];
      let ve = {};
      let we = {};
      function Se(t, e, i) {
        const n = t.getCode(),
          s = e.getCode();
        n in we || (we[n] = {}), (we[n][s] = i);
      }
      function Ce(t, e) {
        const i = t[0],
          n = t[1],
          s = e[0],
          r = e[1],
          o = s[0],
          a = s[1],
          l = r[0],
          h = r[1],
          c = l - o,
          u = h - a,
          d =
            0 === c && 0 === u
              ? 0
              : (c * (i - o) + u * (n - a)) / (c * c + u * u || 0);
        let g, f;
        return (
          d <= 0
            ? ((g = o), (f = a))
            : d >= 1
            ? ((g = l), (f = h))
            : ((g = o + d * c), (f = a + d * u)),
          [g, f]
        );
      }
      function be(t, e) {
        let i = !0;
        for (let n = t.length - 1; n >= 0; --n)
          if (t[n] != e[n]) {
            i = !1;
            break;
          }
        return i;
      }
      function ke(t, e) {
        const i = t[0] - e[0],
          n = t[1] - e[1];
        return i * i + n * n;
      }
      function Me(t, e) {
        return Math.sqrt(ke(t, e));
      }
      function Ie(t, e) {
        if (e.canWrapX()) {
          const i = Ft(e.getExtent()),
            n = (function (t, e, i) {
              const n = e.getExtent();
              let s = 0;
              e.canWrapX() &&
                (t[0] < n[0] || t[0] > n[2]) &&
                ((i = i || Ft(n)), (s = Math.floor((t[0] - n[0]) / i)));
              return s;
            })(t, e, i);
          n && (t[0] -= n * i);
        }
        return t;
      }
      const Ee = { info: 1, warn: 2, error: 3, none: 4 };
      let Re = Ee.info;
      let Pe = !0;
      function Fe(t) {
        Pe = !(void 0 === t || t);
      }
      function Le(t, e) {
        if (void 0 !== e) for (let i = 0, n = t.length; i < n; ++i) e[i] = t[i];
        else e = t.slice();
        return e;
      }
      function Te(t, e) {
        if (void 0 !== e && t !== e) {
          for (let i = 0, n = t.length; i < n; ++i) e[i] = t[i];
          t = e;
        }
        return t;
      }
      function De(t) {
        !(function (t, e) {
          ve[t] = e;
        })(t.getCode(), t),
          Se(t, t, Le);
      }
      function Ae(t) {
        return "string" === typeof t
          ? ve[(e = t)] ||
              ve[
                e.replace(/urn:(x-)?ogc:def:crs:EPSG:(.*:)?(\w+)$/, "EPSG:$3")
              ] ||
              null
          : t || null;
        var e;
      }
      function Oe(t) {
        !(function (t) {
          t.forEach(De);
        })(t),
          t.forEach(function (e) {
            t.forEach(function (t) {
              e !== t && Se(e, t, Le);
            });
          });
      }
      function je(t, e) {
        return t ? ("string" === typeof t ? Ae(t) : t) : Ae(e);
      }
      function Ge(t, e) {
        let i = (function (t, e) {
          let i;
          return t in we && e in we[t] && (i = we[t][e]), i;
        })(t.getCode(), e.getCode());
        return i || (i = Te), i;
      }
      function Ze(t, e) {
        return Ge(Ae(t), Ae(e));
      }
      function ze(t, e, i) {
        return Ze(e, i)(t, void 0, t.length);
      }
      function Be(t, e, i, n) {
        return Dt(t, Ze(e, i), void 0, n);
      }
      let Ne = null;
      function We() {
        return Ne;
      }
      function Xe(t, e) {
        return Ne ? ze(t, e, Ne) : t;
      }
      function Ye(t, e) {
        return Ne
          ? ze(t, Ne, e)
          : (Pe &&
              !be(t, [0, 0]) &&
              t[0] >= -180 &&
              t[0] <= 180 &&
              t[1] >= -90 &&
              t[1] <= 90 &&
              ((Pe = !1),
              (function (...t) {
                Re > Ee.warn || console.warn(...t);
              })(
                "Call useGeographic() from ol/proj once to work with [longitude, latitude] coordinates."
              )),
            t);
      }
      function Ve(t, e) {
        return Ne ? Be(t, e, Ne) : t;
      }
      function qe(t, e) {
        return Ne ? Be(t, Ne, e) : t;
      }
      function $e(t, e) {
        if (!Ne) return t;
        const i = Ae(e).getMetersPerUnit(),
          n = Ne.getMetersPerUnit();
        return i && n ? (t * i) / n : t;
      }
      function Ue(t, e, i, n) {
        for (; e < i - n; ) {
          for (let s = 0; s < n; ++s) {
            const r = t[e + s];
            (t[e + s] = t[i - n + s]), (t[i - n + s] = r);
          }
          (e += n), (i -= n);
        }
      }
      function He(t, e, i, n) {
        let s = 0,
          r = t[i - n],
          o = t[i - n + 1];
        for (; e < i; e += n) {
          const i = t[e],
            n = t[e + 1];
          (s += (i - r) * (n + o)), (r = i), (o = n);
        }
        return 0 === s ? void 0 : s > 0;
      }
      function Ke(t, e, i, n, s) {
        s = void 0 !== s && s;
        for (let r = 0, o = i.length; r < o; ++r) {
          const o = i[r],
            a = He(t, e, o, n);
          if (0 === r) {
            if ((s && a) || (!s && !a)) return !1;
          } else if ((s && !a) || (!s && a)) return !1;
          e = o;
        }
        return !0;
      }
      function Je(t, e, i, n, s) {
        for (let r = 0, o = i.length; r < o; ++r) {
          const o = i[r];
          if (!Ke(t, e, o, n, s)) return !1;
          o.length && (e = o[o.length - 1]);
        }
        return !0;
      }
      function Qe(t, e, i, n, s) {
        s = void 0 !== s && s;
        for (let r = 0, o = i.length; r < o; ++r) {
          const o = i[r],
            a = He(t, e, o, n);
          (0 === r ? (s && a) || (!s && !a) : (s && !a) || (!s && a)) &&
            Ue(t, e, o, n),
            (e = o);
        }
        return e;
      }
      function ti(t, e, i, n, s) {
        for (let r = 0, o = i.length; r < o; ++r) e = Qe(t, e, i[r], n, s);
        return e;
      }
      function ei(t, e, i, n, s, r, o) {
        let a, l;
        const c = (i - e) / n;
        if (1 === c) a = e;
        else if (2 === c) (a = e), (l = s);
        else if (0 !== c) {
          let r = t[e],
            o = t[e + 1],
            c = 0;
          const u = [0];
          for (let s = e + n; s < i; s += n) {
            const e = t[s],
              i = t[s + 1];
            (c += Math.sqrt((e - r) * (e - r) + (i - o) * (i - o))),
              u.push(c),
              (r = e),
              (o = i);
          }
          const d = s * c,
            g = (function (t, e, i) {
              let n, s;
              i = i || h;
              let r = 0,
                o = t.length,
                a = !1;
              for (; r < o; )
                (n = r + ((o - r) >> 1)),
                  (s = +i(t[n], e)),
                  s < 0 ? (r = n + 1) : ((o = n), (a = !s));
              return a ? r : ~r;
            })(u, d);
          g < 0
            ? ((l = (d - u[-g - 2]) / (u[-g - 1] - u[-g - 2])),
              (a = e + (-g - 2) * n))
            : (a = e + g * n);
        }
        (o = o > 1 ? o : 2), (r = r || new Array(o));
        for (let h = 0; h < o; ++h)
          r[h] =
            void 0 === a
              ? NaN
              : void 0 === l
              ? t[a + h]
              : qt(t[a + h], t[a + n + h], l);
        return r;
      }
      function ii(t, e, i, n, s, r) {
        if (i == e) return null;
        let o;
        if (s < t[e + n - 1])
          return r ? ((o = t.slice(e, e + n)), (o[n - 1] = s), o) : null;
        if (t[i - 1] < s)
          return r ? ((o = t.slice(i - n, i)), (o[n - 1] = s), o) : null;
        if (s == t[e + n - 1]) return t.slice(e, e + n);
        let a = e / n,
          l = i / n;
        for (; a < l; ) {
          const e = (a + l) >> 1;
          s < t[(e + 1) * n - 1] ? (l = e) : (a = e + 1);
        }
        const h = t[a * n - 1];
        if (s == h) return t.slice((a - 1) * n, (a - 1) * n + n);
        const c = (s - h) / (t[(a + 1) * n - 1] - h);
        o = [];
        for (let u = 0; u < n - 1; ++u)
          o.push(qt(t[(a - 1) * n + u], t[a * n + u], c));
        return o.push(s), o;
      }
      function ni(t, e, i, n) {
        const s = [];
        let r = [1 / 0, 1 / 0, -1 / 0, -1 / 0];
        for (let o = 0, a = i.length; o < a; ++o) {
          const a = i[o];
          (r = _t(t, e, a[0], n)),
            s.push((r[0] + r[2]) / 2, (r[1] + r[3]) / 2),
            (e = a[a.length - 1]);
        }
        return s;
      }
      function si(t, e, i, n, s, r, o) {
        (r = r || []), (o = o || 2);
        let a = 0;
        for (let l = e; l < i; l += n) {
          const e = t[l],
            i = t[l + 1];
          (r[a++] = s[0] * e + s[2] * i + s[4]),
            (r[a++] = s[1] * e + s[3] * i + s[5]);
          for (let n = 2; n < o; n++) r[a++] = t[l + n];
        }
        return r && r.length != a && (r.length = a), r;
      }
      function ri(t, e, i, n, s, r, o) {
        o = o || [];
        const a = Math.cos(s),
          l = Math.sin(s),
          h = r[0],
          c = r[1];
        let u = 0;
        for (let d = e; d < i; d += n) {
          const e = t[d] - h,
            i = t[d + 1] - c;
          (o[u++] = h + e * a - i * l), (o[u++] = c + e * l + i * a);
          for (let s = d + 2; s < d + n; ++s) o[u++] = t[s];
        }
        return o && o.length != u && (o.length = u), o;
      }
      !(function () {
        var t, e, i;
        Oe(ge),
          Oe(xe),
          (t = ge),
          (e = fe),
          (i = pe),
          xe.forEach(function (n) {
            t.forEach(function (t) {
              Se(n, t, e), Se(t, n, i);
            });
          });
      })();
      const oi = [1, 0, 0, 1, 0, 0];
      class ai {
        constructor(t, e, i, n, s, r) {
          this.styleFunction,
            this.extent_,
            (this.id_ = r),
            (this.type_ = t),
            (this.flatCoordinates_ = e),
            (this.flatInteriorPoints_ = null),
            (this.flatMidpoints_ = null),
            (this.ends_ = i || null),
            (this.properties_ = s),
            this.squaredTolerance_,
            (this.stride_ = n),
            this.simplifiedGeometry_;
        }
        get(t) {
          return this.properties_[t];
        }
        getExtent() {
          return (
            this.extent_ ||
              (this.extent_ =
                "Point" === this.type_
                  ? mt(this.flatCoordinates_)
                  : _t(
                      this.flatCoordinates_,
                      0,
                      this.flatCoordinates_.length,
                      2
                    )),
            this.extent_
          );
        }
        getFlatInteriorPoint() {
          if (!this.flatInteriorPoints_) {
            const t = Mt(this.getExtent());
            this.flatInteriorPoints_ = ne(
              this.flatCoordinates_,
              0,
              this.ends_,
              2,
              t,
              0
            );
          }
          return this.flatInteriorPoints_;
        }
        getFlatInteriorPoints() {
          if (!this.flatInteriorPoints_) {
            const t = (function (t, e) {
                const i = [];
                let n,
                  s = 0,
                  r = 0;
                for (let o = 0, a = e.length; o < a; ++o) {
                  const a = e[o],
                    l = He(t, s, a, 2);
                  if ((void 0 === n && (n = l), l === n))
                    i.push(e.slice(r, o + 1));
                  else {
                    if (0 === i.length) continue;
                    i[i.length - 1].push(e[r]);
                  }
                  (r = o + 1), (s = a);
                }
                return i;
              })(this.flatCoordinates_, this.ends_),
              e = ni(this.flatCoordinates_, 0, t, 2);
            this.flatInteriorPoints_ = se(this.flatCoordinates_, 0, t, 2, e);
          }
          return this.flatInteriorPoints_;
        }
        getFlatMidpoint() {
          return (
            this.flatMidpoints_ ||
              (this.flatMidpoints_ = ei(
                this.flatCoordinates_,
                0,
                this.flatCoordinates_.length,
                2,
                0.5
              )),
            this.flatMidpoints_
          );
        }
        getFlatMidpoints() {
          if (!this.flatMidpoints_) {
            this.flatMidpoints_ = [];
            const t = this.flatCoordinates_;
            let e = 0;
            const i = this.ends_;
            for (let n = 0, s = i.length; n < s; ++n) {
              const s = i[n],
                r = ei(t, e, s, 2, 0.5);
              d(this.flatMidpoints_, r), (e = s);
            }
          }
          return this.flatMidpoints_;
        }
        getId() {
          return this.id_;
        }
        getOrientedFlatCoordinates() {
          return this.flatCoordinates_;
        }
        getGeometry() {
          return this;
        }
        getSimplifiedGeometry(t) {
          return this;
        }
        simplifyTransformed(t, e) {
          return this;
        }
        getProperties() {
          return this.properties_;
        }
        getPropertiesInternal() {
          return this.properties_;
        }
        getStride() {
          return this.stride_;
        }
        getStyleFunction() {
          return this.styleFunction;
        }
        getType() {
          return this.type_;
        }
        transform(t) {
          const e = (t = Ae(t)).getExtent(),
            i = t.getWorldExtent();
          if (e && i) {
            const t = Et(i) / Et(e);
            Gt(oi, i[0], i[3], t, -t, 0, 0, 0),
              si(
                this.flatCoordinates_,
                0,
                this.flatCoordinates_.length,
                2,
                oi,
                this.flatCoordinates_
              );
          }
        }
        applyTransform(t) {
          t(this.flatCoordinates_, this.flatCoordinates_, this.stride_);
        }
        clone() {
          return new ai(
            this.type_,
            this.flatCoordinates_.slice(),
            this.ends_?.slice(),
            this.stride_,
            Object.assign({}, this.properties_),
            this.id_
          );
        }
        getEnds() {
          return this.ends_;
        }
        enableSimplifyTransformed() {
          return (
            (this.simplifyTransformed = _((t, e) => {
              if (t === this.squaredTolerance_) return this.simplifiedGeometry_;
              (this.simplifiedGeometry_ = this.clone()),
                e && this.simplifiedGeometry_.applyTransform(e);
              const i = this.simplifiedGeometry_.getFlatCoordinates();
              let n;
              switch (this.type_) {
                case "LineString":
                  (i.length = Ut(
                    i,
                    0,
                    this.simplifiedGeometry_.flatCoordinates_.length,
                    this.simplifiedGeometry_.stride_,
                    t,
                    i,
                    0
                  )),
                    (n = [i.length]);
                  break;
                case "MultiLineString":
                  (n = []),
                    (i.length = Ht(
                      i,
                      0,
                      this.simplifiedGeometry_.ends_,
                      this.simplifiedGeometry_.stride_,
                      t,
                      i,
                      0,
                      n
                    ));
                  break;
                case "Polygon":
                  (n = []),
                    (i.length = Qt(
                      i,
                      0,
                      this.simplifiedGeometry_.ends_,
                      this.simplifiedGeometry_.stride_,
                      Math.sqrt(t),
                      i,
                      0,
                      n
                    ));
              }
              return (
                n &&
                  (this.simplifiedGeometry_ = new ai(
                    this.type_,
                    i,
                    n,
                    2,
                    this.properties_,
                    this.id_
                  )),
                (this.squaredTolerance_ = t),
                this.simplifiedGeometry_
              );
            })),
            this
          );
        }
      }
      ai.prototype.getFlatCoordinates = ai.prototype.getOrientedFlatCoordinates;
      const li = ai;
      function hi(t) {
        return t
          ? "function" === typeof t
            ? t
            : (Array.isArray(t) || (t = [t]), (e) => t)
          : null;
      }
      const ci = class extends T {
          constructor(t) {
            super(),
              (this.projection = Ae(t.projection)),
              (this.attributions_ = hi(t.attributions)),
              (this.attributionsCollapsible_ = t.attributionsCollapsible ?? !0),
              (this.loading = !1),
              (this.state_ = void 0 !== t.state ? t.state : "ready"),
              (this.wrapX_ = void 0 !== t.wrapX && t.wrapX),
              (this.interpolate_ = !!t.interpolate),
              (this.viewResolver = null),
              (this.viewRejector = null);
            const e = this;
            this.viewPromise_ = new Promise(function (t, i) {
              (e.viewResolver = t), (e.viewRejector = i);
            });
          }
          getAttributions() {
            return this.attributions_;
          }
          getAttributionsCollapsible() {
            return this.attributionsCollapsible_;
          }
          getProjection() {
            return this.projection;
          }
          getResolutions(t) {
            return null;
          }
          getView() {
            return this.viewPromise_;
          }
          getState() {
            return this.state_;
          }
          getWrapX() {
            return this.wrapX_;
          }
          getInterpolate() {
            return this.interpolate_;
          }
          refresh() {
            this.changed();
          }
          setAttributions(t) {
            (this.attributions_ = hi(t)), this.changed();
          }
          setState(t) {
            (this.state_ = t), this.changed();
          }
        },
        ui = "addfeature",
        di = "changefeature",
        gi = "clear",
        fi = "removefeature",
        pi = "featuresloadstart",
        mi = "featuresloadend",
        _i = "featuresloaderror";
      function yi(t, e) {
        return [[-1 / 0, -1 / 0, 1 / 0, 1 / 0]];
      }
      function xi(t, e) {
        return [t];
      }
      let vi = !1;
      function wi(t, e) {
        return function (i, n, s, r, o) {
          const a = this;
          !(function (t, e, i, n, s, r, o) {
            const a = new XMLHttpRequest();
            a.open("GET", "function" === typeof t ? t(i, n, s) : t, !0),
              "arraybuffer" == e.getType() && (a.responseType = "arraybuffer"),
              (a.withCredentials = vi),
              (a.onload = function (t) {
                if (!a.status || (a.status >= 200 && a.status < 300)) {
                  const t = e.getType();
                  try {
                    let n;
                    "text" == t || "json" == t
                      ? (n = a.responseText)
                      : "xml" == t
                      ? (n = a.responseXML || a.responseText)
                      : "arraybuffer" == t && (n = a.response),
                      n
                        ? r(
                            e.readFeatures(n, {
                              extent: i,
                              featureProjection: s,
                            }),
                            e.readProjection(n)
                          )
                        : o();
                  } catch {
                    o();
                  }
                } else o();
              }),
              (a.onerror = o),
              a.send();
          })(
            t,
            e,
            i,
            n,
            s,
            function (t, e) {
              a.addFeatures(t), void 0 !== r && r(t);
            },
            o || m
          );
        };
      }
      class Si extends o {
        constructor(t, e, i) {
          super(t), (this.feature = e), (this.features = i);
        }
      }
      const Ci = class extends ci {
        constructor(t) {
          super({
            attributions: (t = t || {}).attributions,
            interpolate: !0,
            projection: void 0,
            state: "ready",
            wrapX: void 0 === t.wrapX || t.wrapX,
          }),
            this.on,
            this.once,
            this.un,
            (this.loader_ = m),
            (this.format_ = t.format || null),
            (this.overlaps_ = void 0 === t.overlaps || t.overlaps),
            (this.url_ = t.url),
            void 0 !== t.loader
              ? (this.loader_ = t.loader)
              : void 0 !== this.url_ &&
                (D(this.format_, "`format` must be set when `url` is set"),
                (this.loader_ = wi(this.url_, this.format_))),
            (this.strategy_ = void 0 !== t.strategy ? t.strategy : yi);
          const e = void 0 === t.useSpatialIndex || t.useSpatialIndex;
          let i, n;
          (this.featuresRtree_ = e ? new Ot() : null),
            (this.loadedExtentsRtree_ = new Ot()),
            (this.loadingExtentsCount_ = 0),
            (this.nullGeometryFeatures_ = {}),
            (this.idIndex_ = {}),
            (this.uidIndex_ = {}),
            (this.featureChangeKeys_ = {}),
            (this.featuresCollection_ = null),
            Array.isArray(t.features)
              ? (n = t.features)
              : t.features && ((i = t.features), (n = i.getArray())),
            e || void 0 !== i || (i = new B(n)),
            void 0 !== n && this.addFeaturesInternal(n),
            void 0 !== i && this.bindFeaturesCollection_(i);
        }
        addFeature(t) {
          this.addFeatureInternal(t), this.changed();
        }
        addFeatureInternal(t) {
          const e = F(t);
          if (!this.addToIndex_(e, t))
            return void (
              this.featuresCollection_ && this.featuresCollection_.remove(t)
            );
          this.setupChangeEvents_(e, t);
          const i = t.getGeometry();
          if (i) {
            const e = i.getExtent();
            this.featuresRtree_ && this.featuresRtree_.insert(e, t);
          } else this.nullGeometryFeatures_[e] = t;
          this.dispatchEvent(new Si(ui, t));
        }
        setupChangeEvents_(t, e) {
          e instanceof li ||
            (this.featureChangeKeys_[t] = [
              b(e, w, this.handleFeatureChange_, this),
              b(e, a, this.handleFeatureChange_, this),
            ]);
        }
        addToIndex_(t, e) {
          let i = !0;
          if (void 0 !== e.getId()) {
            const t = String(e.getId());
            if (t in this.idIndex_)
              if (e instanceof li) {
                const n = this.idIndex_[t];
                n instanceof li
                  ? Array.isArray(n)
                    ? n.push(e)
                    : (this.idIndex_[t] = [n, e])
                  : (i = !1);
              } else i = !1;
            else this.idIndex_[t] = e;
          }
          return (
            i &&
              (D(
                !(t in this.uidIndex_),
                "The passed `feature` was already added to the source"
              ),
              (this.uidIndex_[t] = e)),
            i
          );
        }
        addFeatures(t) {
          this.addFeaturesInternal(t), this.changed();
        }
        addFeaturesInternal(t) {
          const e = [],
            i = [],
            n = [];
          for (let s = 0, r = t.length; s < r; s++) {
            const e = t[s],
              n = F(e);
            this.addToIndex_(n, e) && i.push(e);
          }
          for (let s = 0, r = i.length; s < r; s++) {
            const t = i[s],
              r = F(t);
            this.setupChangeEvents_(r, t);
            const o = t.getGeometry();
            if (o) {
              const i = o.getExtent();
              e.push(i), n.push(t);
            } else this.nullGeometryFeatures_[r] = t;
          }
          if (
            (this.featuresRtree_ && this.featuresRtree_.load(e, n),
            this.hasListener(ui))
          )
            for (let s = 0, r = i.length; s < r; s++)
              this.dispatchEvent(new Si(ui, i[s]));
        }
        bindFeaturesCollection_(t) {
          let e = !1;
          this.addEventListener(ui, function (i) {
            e || ((e = !0), t.push(i.feature), (e = !1));
          }),
            this.addEventListener(fi, function (i) {
              e || ((e = !0), t.remove(i.feature), (e = !1));
            }),
            t.addEventListener(j, (t) => {
              e || ((e = !0), this.addFeature(t.element), (e = !1));
            }),
            t.addEventListener(G, (t) => {
              e || ((e = !0), this.removeFeature(t.element), (e = !1));
            }),
            (this.featuresCollection_ = t);
        }
        clear(t) {
          if (t) {
            for (const t in this.featureChangeKeys_) {
              this.featureChangeKeys_[t].forEach(M);
            }
            this.featuresCollection_ ||
              ((this.featureChangeKeys_ = {}),
              (this.idIndex_ = {}),
              (this.uidIndex_ = {}));
          } else if (this.featuresRtree_) {
            const t = (t) => {
              this.removeFeatureInternal(t);
            };
            this.featuresRtree_.forEach(t);
            for (const e in this.nullGeometryFeatures_)
              this.removeFeatureInternal(this.nullGeometryFeatures_[e]);
          }
          this.featuresCollection_ && this.featuresCollection_.clear(),
            this.featuresRtree_ && this.featuresRtree_.clear(),
            (this.nullGeometryFeatures_ = {});
          const e = new Si(gi);
          this.dispatchEvent(e), this.changed();
        }
        forEachFeature(t) {
          if (this.featuresRtree_) return this.featuresRtree_.forEach(t);
          this.featuresCollection_ && this.featuresCollection_.forEach(t);
        }
        forEachFeatureAtCoordinateDirect(t, e) {
          const i = [t[0], t[1], t[0], t[1]];
          return this.forEachFeatureInExtent(i, function (i) {
            const n = i.getGeometry();
            if (n instanceof li || n.intersectsCoordinate(t)) return e(i);
          });
        }
        forEachFeatureInExtent(t, e) {
          if (this.featuresRtree_)
            return this.featuresRtree_.forEachInExtent(t, e);
          this.featuresCollection_ && this.featuresCollection_.forEach(e);
        }
        forEachFeatureIntersectingExtent(t, e) {
          return this.forEachFeatureInExtent(t, function (i) {
            const n = i.getGeometry();
            if (n instanceof li || n.intersectsExtent(t)) {
              const t = e(i);
              if (t) return t;
            }
          });
        }
        getFeaturesCollection() {
          return this.featuresCollection_;
        }
        getFeatures() {
          let t;
          return (
            this.featuresCollection_
              ? (t = this.featuresCollection_.getArray().slice(0))
              : this.featuresRtree_ &&
                ((t = this.featuresRtree_.getAll()),
                x(this.nullGeometryFeatures_) ||
                  d(t, Object.values(this.nullGeometryFeatures_))),
            t
          );
        }
        getFeaturesAtCoordinate(t) {
          const e = [];
          return (
            this.forEachFeatureAtCoordinateDirect(t, function (t) {
              e.push(t);
            }),
            e
          );
        }
        getFeaturesInExtent(t, e) {
          if (this.featuresRtree_) {
            if (!(e && e.canWrapX() && this.getWrapX()))
              return this.featuresRtree_.getInExtent(t);
            const i = (function (t, e, i) {
              if (e.canWrapX()) {
                const n = e.getExtent();
                if (!isFinite(t[0]) || !isFinite(t[2]))
                  return [[n[0], t[1], n[2], t[3]]];
                At(t, e);
                const s = Ft(n);
                if (Ft(t) > s && !i) return [[n[0], t[1], n[2], t[3]]];
                if (t[0] < n[0])
                  return [
                    [t[0] + s, t[1], n[2], t[3]],
                    [n[0], t[1], t[2], t[3]],
                  ];
                if (t[2] > n[2])
                  return [
                    [t[0], t[1], n[2], t[3]],
                    [n[0], t[1], t[2] - s, t[3]],
                  ];
              }
              return [t];
            })(t, e);
            return [].concat(
              ...i.map((t) => this.featuresRtree_.getInExtent(t))
            );
          }
          return this.featuresCollection_
            ? this.featuresCollection_.getArray().slice(0)
            : [];
        }
        getClosestFeatureToCoordinate(t, e) {
          const i = t[0],
            n = t[1];
          let s = null;
          const r = [NaN, NaN];
          let o = 1 / 0;
          const a = [-1 / 0, -1 / 0, 1 / 0, 1 / 0];
          return (
            (e = e || f),
            this.featuresRtree_.forEachInExtent(a, function (t) {
              if (e(t)) {
                const e = t.getGeometry(),
                  l = o;
                if (
                  ((o = e instanceof li ? 0 : e.closestPointXY(i, n, r, o)),
                  o < l)
                ) {
                  s = t;
                  const e = Math.sqrt(o);
                  (a[0] = i - e),
                    (a[1] = n - e),
                    (a[2] = i + e),
                    (a[3] = n + e);
                }
              }
            }),
            s
          );
        }
        getExtent(t) {
          return this.featuresRtree_.getExtent(t);
        }
        getFeatureById(t) {
          const e = this.idIndex_[t.toString()];
          return void 0 !== e ? e : null;
        }
        getFeatureByUid(t) {
          const e = this.uidIndex_[t];
          return void 0 !== e ? e : null;
        }
        getFormat() {
          return this.format_;
        }
        getOverlaps() {
          return this.overlaps_;
        }
        getUrl() {
          return this.url_;
        }
        handleFeatureChange_(t) {
          const e = t.target,
            i = F(e),
            n = e.getGeometry();
          if (n) {
            const t = n.getExtent();
            i in this.nullGeometryFeatures_
              ? (delete this.nullGeometryFeatures_[i],
                this.featuresRtree_ && this.featuresRtree_.insert(t, e))
              : this.featuresRtree_ && this.featuresRtree_.update(t, e);
          } else
            i in this.nullGeometryFeatures_ ||
              (this.featuresRtree_ && this.featuresRtree_.remove(e),
              (this.nullGeometryFeatures_[i] = e));
          const s = e.getId();
          if (void 0 !== s) {
            const t = s.toString();
            this.idIndex_[t] !== e &&
              (this.removeFromIdIndex_(e), (this.idIndex_[t] = e));
          } else this.removeFromIdIndex_(e), (this.uidIndex_[i] = e);
          this.changed(), this.dispatchEvent(new Si(di, e));
        }
        hasFeature(t) {
          const e = t.getId();
          return void 0 !== e ? e in this.idIndex_ : F(t) in this.uidIndex_;
        }
        isEmpty() {
          return this.featuresRtree_
            ? this.featuresRtree_.isEmpty() && x(this.nullGeometryFeatures_)
            : !this.featuresCollection_ ||
                0 === this.featuresCollection_.getLength();
        }
        loadFeatures(t, e, i) {
          const n = this.loadedExtentsRtree_,
            s = this.strategy_(t, e, i);
          for (let r = 0, o = s.length; r < o; ++r) {
            const t = s[r];
            n.forEachInExtent(t, function (e) {
              return ct(e.extent, t);
            }) ||
              (++this.loadingExtentsCount_,
              this.dispatchEvent(new Si(pi)),
              this.loader_.call(
                this,
                t,
                e,
                i,
                (t) => {
                  --this.loadingExtentsCount_,
                    this.dispatchEvent(new Si(mi, void 0, t));
                },
                () => {
                  --this.loadingExtentsCount_, this.dispatchEvent(new Si(_i));
                }
              ),
              n.insert(t, { extent: t.slice() }));
          }
          this.loading =
            !(this.loader_.length < 4) && this.loadingExtentsCount_ > 0;
        }
        refresh() {
          this.clear(!0), this.loadedExtentsRtree_.clear(), super.refresh();
        }
        removeLoadedExtent(t) {
          const e = this.loadedExtentsRtree_;
          let i;
          e.forEachInExtent(t, function (e) {
            if (yt(e.extent, t)) return (i = e), !0;
          }),
            i && e.remove(i);
        }
        removeFeatures(t) {
          let e = !1;
          for (let i = 0, n = t.length; i < n; ++i)
            e = this.removeFeatureInternal(t[i]) || e;
          e && this.changed();
        }
        removeFeature(t) {
          if (!t) return;
          this.removeFeatureInternal(t) && this.changed();
        }
        removeFeatureInternal(t) {
          const e = F(t);
          if (!(e in this.uidIndex_)) return !1;
          e in this.nullGeometryFeatures_
            ? delete this.nullGeometryFeatures_[e]
            : this.featuresRtree_ && this.featuresRtree_.remove(t);
          const i = this.featureChangeKeys_[e];
          i?.forEach(M), delete this.featureChangeKeys_[e];
          const n = t.getId();
          if (void 0 !== n) {
            const e = n.toString(),
              i = this.idIndex_[e];
            i === t
              ? delete this.idIndex_[e]
              : Array.isArray(i) &&
                (i.splice(i.indexOf(t), 1),
                1 === i.length && (this.idIndex_[e] = i[0]));
          }
          return (
            delete this.uidIndex_[e],
            this.hasListener(fi) && this.dispatchEvent(new Si(fi, t)),
            !0
          );
        }
        removeFromIdIndex_(t) {
          for (const e in this.idIndex_)
            if (this.idIndex_[e] === t) {
              delete this.idIndex_[e];
              break;
            }
        }
        setLoader(t) {
          this.loader_ = t;
        }
        setUrl(t) {
          D(this.format_, "`format` must be set when `url` is set"),
            (this.url_ = t),
            this.setLoader(wi(t, this.format_));
        }
      };
      var bi = i(51426);
      const ki = (0, bi.Z)(
          (0, n.jsx)("path", {
            d: "M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z",
          }),
          "Close"
        ),
        Mi = [1, 0, 0, 1, 0, 0];
      const Ii = class extends T {
        constructor() {
          super(),
            (this.extent_ = [1 / 0, 1 / 0, -1 / 0, -1 / 0]),
            (this.extentRevision_ = -1),
            (this.simplifiedGeometryMaxMinSquaredTolerance = 0),
            (this.simplifiedGeometryRevision = 0),
            (this.simplifyTransformedInternal = _((t, e, i) => {
              if (!i) return this.getSimplifiedGeometry(e);
              const n = this.clone();
              return n.applyTransform(i), n.getSimplifiedGeometry(e);
            }));
        }
        simplifyTransformed(t, e) {
          return this.simplifyTransformedInternal(this.getRevision(), t, e);
        }
        clone() {
          return R();
        }
        closestPointXY(t, e, i, n) {
          return R();
        }
        containsXY(t, e) {
          const i = this.getClosestPoint([t, e]);
          return i[0] === t && i[1] === e;
        }
        getClosestPoint(t, e) {
          return (
            (e = e || [NaN, NaN]), this.closestPointXY(t[0], t[1], e, 1 / 0), e
          );
        }
        intersectsCoordinate(t) {
          return this.containsXY(t[0], t[1]);
        }
        computeExtent(t) {
          return R();
        }
        getExtent(t) {
          if (this.extentRevision_ != this.getRevision()) {
            const t = this.computeExtent(this.extent_);
            (isNaN(t[0]) || isNaN(t[1])) && pt(t),
              (this.extentRevision_ = this.getRevision());
          }
          return (function (t, e) {
            return e
              ? ((e[0] = t[0]), (e[1] = t[1]), (e[2] = t[2]), (e[3] = t[3]), e)
              : t;
          })(this.extent_, t);
        }
        rotate(t, e) {
          R();
        }
        scale(t, e, i) {
          R();
        }
        simplify(t) {
          return this.getSimplifiedGeometry(t * t);
        }
        getSimplifiedGeometry(t) {
          return R();
        }
        getType() {
          return R();
        }
        applyTransform(t) {
          R();
        }
        intersectsExtent(t) {
          return R();
        }
        translate(t, e) {
          R();
        }
        transform(t, e) {
          const i = Ae(t),
            n =
              "tile-pixels" == i.getUnits()
                ? function (t, n, s) {
                    const r = i.getExtent(),
                      o = i.getWorldExtent(),
                      a = Et(o) / Et(r);
                    return (
                      Gt(Mi, o[0], o[3], a, -a, 0, 0, 0),
                      si(t, 0, t.length, s, Mi, n),
                      Ze(i, e)(t, n, s)
                    );
                  }
                : Ze(i, e);
          return this.applyTransform(n), this;
        }
      };
      function Ei(t) {
        let e;
        return (
          2 == t ? (e = "XY") : 3 == t ? (e = "XYZ") : 4 == t && (e = "XYZM"), e
        );
      }
      function Ri(t) {
        let e;
        return (
          "XY" == t
            ? (e = 2)
            : "XYZ" == t || "XYM" == t
            ? (e = 3)
            : "XYZM" == t && (e = 4),
          e
        );
      }
      const Pi = class extends Ii {
        constructor() {
          super(),
            (this.layout = "XY"),
            (this.stride = 2),
            this.flatCoordinates;
        }
        computeExtent(t) {
          return _t(
            this.flatCoordinates,
            0,
            this.flatCoordinates.length,
            this.stride,
            t
          );
        }
        getCoordinates() {
          return R();
        }
        getFirstCoordinate() {
          return this.flatCoordinates.slice(0, this.stride);
        }
        getFlatCoordinates() {
          return this.flatCoordinates;
        }
        getLastCoordinate() {
          return this.flatCoordinates.slice(
            this.flatCoordinates.length - this.stride
          );
        }
        getLayout() {
          return this.layout;
        }
        getSimplifiedGeometry(t) {
          if (
            (this.simplifiedGeometryRevision !== this.getRevision() &&
              ((this.simplifiedGeometryMaxMinSquaredTolerance = 0),
              (this.simplifiedGeometryRevision = this.getRevision())),
            t < 0 ||
              (0 !== this.simplifiedGeometryMaxMinSquaredTolerance &&
                t <= this.simplifiedGeometryMaxMinSquaredTolerance))
          )
            return this;
          const e = this.getSimplifiedGeometryInternal(t);
          return e.getFlatCoordinates().length < this.flatCoordinates.length
            ? e
            : ((this.simplifiedGeometryMaxMinSquaredTolerance = t), this);
        }
        getSimplifiedGeometryInternal(t) {
          return this;
        }
        getStride() {
          return this.stride;
        }
        setFlatCoordinates(t, e) {
          (this.stride = Ri(t)), (this.layout = t), (this.flatCoordinates = e);
        }
        setCoordinates(t, e) {
          R();
        }
        setLayout(t, e, i) {
          let n;
          if (t) n = Ri(t);
          else {
            for (let t = 0; t < i; ++t) {
              if (0 === e.length)
                return (this.layout = "XY"), void (this.stride = 2);
              e = e[0];
            }
            (n = e.length), (t = Ei(n));
          }
          (this.layout = t), (this.stride = n);
        }
        applyTransform(t) {
          this.flatCoordinates &&
            (t(
              this.flatCoordinates,
              this.flatCoordinates,
              this.layout.startsWith("XYZ") ? 3 : 2,
              this.stride
            ),
            this.changed());
        }
        rotate(t, e) {
          const i = this.getFlatCoordinates();
          if (i) {
            const n = this.getStride();
            ri(i, 0, i.length, n, t, e, i), this.changed();
          }
        }
        scale(t, e, i) {
          void 0 === e && (e = t), i || (i = Mt(this.getExtent()));
          const n = this.getFlatCoordinates();
          if (n) {
            const s = this.getStride();
            !(function (t, e, i, n, s, r, o, a) {
              a = a || [];
              const l = o[0],
                h = o[1];
              let c = 0;
              for (let u = e; u < i; u += n) {
                const e = t[u] - l,
                  i = t[u + 1] - h;
                (a[c++] = l + s * e), (a[c++] = h + r * i);
                for (let s = u + 2; s < u + n; ++s) a[c++] = t[s];
              }
              a && a.length != c && (a.length = c);
            })(n, 0, n.length, s, t, e, i, n),
              this.changed();
          }
        }
        translate(t, e) {
          const i = this.getFlatCoordinates();
          if (i) {
            const n = this.getStride();
            !(function (t, e, i, n, s, r, o) {
              o = o || [];
              let a = 0;
              for (let l = e; l < i; l += n) {
                (o[a++] = t[l] + s), (o[a++] = t[l + 1] + r);
                for (let e = l + 2; e < l + n; ++e) o[a++] = t[e];
              }
              o && o.length != a && (o.length = a);
            })(i, 0, i.length, n, t, e, i),
              this.changed();
          }
        }
      };
      function Fi(t, e, i, n) {
        for (let s = 0, r = i.length; s < r; ++s) t[e++] = i[s];
        return e;
      }
      function Li(t, e, i, n) {
        for (let s = 0, r = i.length; s < r; ++s) {
          const r = i[s];
          for (let i = 0; i < n; ++i) t[e++] = r[i];
        }
        return e;
      }
      function Ti(t, e, i, n, s) {
        s = s || [];
        let r = 0;
        for (let o = 0, a = i.length; o < a; ++o) {
          const a = Li(t, e, i[o], n);
          (s[r++] = a), (e = a);
        }
        return (s.length = r), s;
      }
      function Di(t, e, i, n, s) {
        s = s || [];
        let r = 0;
        for (let o = 0, a = i.length; o < a; ++o) {
          const a = Ti(t, e, i[o], n, s[r]);
          0 === a.length && (a[0] = e), (s[r++] = a), (e = a[a.length - 1]);
        }
        return (s.length = r), s;
      }
      class Ai extends Pi {
        constructor(t, e) {
          super(), this.setCoordinates(t, e);
        }
        clone() {
          const t = new Ai(this.flatCoordinates.slice(), this.layout);
          return t.applyProperties(this), t;
        }
        closestPointXY(t, e, i, n) {
          const s = this.flatCoordinates,
            r = Xt(t, e, s[0], s[1]);
          if (r < n) {
            const t = this.stride;
            for (let e = 0; e < t; ++e) i[e] = s[e];
            return (i.length = t), r;
          }
          return n;
        }
        getCoordinates() {
          return this.flatCoordinates.slice();
        }
        computeExtent(t) {
          return mt(this.flatCoordinates, t);
        }
        getType() {
          return "Point";
        }
        intersectsExtent(t) {
          return ut(t, this.flatCoordinates[0], this.flatCoordinates[1]);
        }
        setCoordinates(t, e) {
          this.setLayout(e, t, 0),
            this.flatCoordinates || (this.flatCoordinates = []),
            (this.flatCoordinates.length = Fi(
              this.flatCoordinates,
              0,
              t,
              this.stride
            )),
            this.changed();
        }
      }
      const Oi = Ai;
      function ji(t, e, i, n, s, r, o) {
        const a = t[e],
          l = t[e + 1],
          h = t[i] - a,
          c = t[i + 1] - l;
        let u;
        if (0 === h && 0 === c) u = e;
        else {
          const d = ((s - a) * h + (r - l) * c) / (h * h + c * c);
          if (d > 1) u = i;
          else {
            if (d > 0) {
              for (let s = 0; s < n; ++s) o[s] = qt(t[e + s], t[i + s], d);
              return void (o.length = n);
            }
            u = e;
          }
        }
        for (let d = 0; d < n; ++d) o[d] = t[u + d];
        o.length = n;
      }
      function Gi(t, e, i, n, s) {
        let r = t[e],
          o = t[e + 1];
        for (e += n; e < i; e += n) {
          const i = t[e],
            n = t[e + 1],
            a = Xt(r, o, i, n);
          a > s && (s = a), (r = i), (o = n);
        }
        return s;
      }
      function Zi(t, e, i, n, s) {
        for (let r = 0, o = i.length; r < o; ++r) {
          const o = i[r];
          (s = Gi(t, e, o, n, s)), (e = o);
        }
        return s;
      }
      function zi(t, e, i, n, s, r, o, a, l, h, c) {
        if (e == i) return h;
        let u, d;
        if (0 === s) {
          if (((d = Xt(o, a, t[e], t[e + 1])), d < h)) {
            for (u = 0; u < n; ++u) l[u] = t[e + u];
            return (l.length = n), d;
          }
          return h;
        }
        c = c || [NaN, NaN];
        let g = e + n;
        for (; g < i; )
          if (
            (ji(t, g - n, g, n, o, a, c), (d = Xt(o, a, c[0], c[1])), d < h)
          ) {
            for (h = d, u = 0; u < n; ++u) l[u] = c[u];
            (l.length = n), (g += n);
          } else g += n * Math.max(((Math.sqrt(d) - Math.sqrt(h)) / s) | 0, 1);
        if (
          r &&
          (ji(t, i - n, e, n, o, a, c), (d = Xt(o, a, c[0], c[1])), d < h)
        ) {
          for (h = d, u = 0; u < n; ++u) l[u] = c[u];
          l.length = n;
        }
        return h;
      }
      function Bi(t, e, i, n, s, r, o, a, l, h, c) {
        c = c || [NaN, NaN];
        for (let u = 0, d = i.length; u < d; ++u) {
          const d = i[u];
          (h = zi(t, e, d, n, s, r, o, a, l, h, c)), (e = d);
        }
        return h;
      }
      function Ni(t, e, i, n, s) {
        let r;
        for (e += n; e < i; e += n)
          if (((r = s(t.slice(e - n, e), t.slice(e, e + n))), r)) return r;
        return !1;
      }
      function Wi(t, e, i, n, s) {
        s = void 0 !== s ? s : [];
        let r = 0;
        for (let o = e; o < i; o += n) s[r++] = t.slice(o, o + n);
        return (s.length = r), s;
      }
      function Xi(t, e, i, n, s) {
        s = void 0 !== s ? s : [];
        let r = 0;
        for (let o = 0, a = i.length; o < a; ++o) {
          const a = i[o];
          (s[r++] = Wi(t, e, a, n, s[r])), (e = a);
        }
        return (s.length = r), s;
      }
      function Yi(t, e, i, n, s) {
        s = void 0 !== s ? s : [];
        let r = 0;
        for (let o = 0, a = i.length; o < a; ++o) {
          const a = i[o];
          (s[r++] = 1 === a.length && a[0] === e ? [] : Xi(t, e, a, n, s[r])),
            (e = a[a.length - 1]);
        }
        return (s.length = r), s;
      }
      function Vi(t, e, i, n, s) {
        const r = wt([1 / 0, 1 / 0, -1 / 0, -1 / 0], t, e, i, n);
        return (
          !!Lt(s, r) &&
          (!!ct(s, r) ||
            (r[0] >= s[0] && r[2] <= s[2]) ||
            (r[1] >= s[1] && r[3] <= s[3]) ||
            Ni(t, e, i, n, function (t, e) {
              return (function (t, e, i) {
                let n = !1;
                const s = dt(t, e),
                  r = dt(t, i);
                if (s === rt.INTERSECTING || r === rt.INTERSECTING) n = !0;
                else {
                  const o = t[0],
                    a = t[1],
                    l = t[2],
                    h = t[3],
                    c = e[0],
                    u = e[1],
                    d = i[0],
                    g = i[1],
                    f = (g - u) / (d - c);
                  let p, m;
                  r & rt.ABOVE &&
                    !(s & rt.ABOVE) &&
                    ((p = d - (g - h) / f), (n = p >= o && p <= l)),
                    n ||
                      !(r & rt.RIGHT) ||
                      s & rt.RIGHT ||
                      ((m = g - (d - l) * f), (n = m >= a && m <= h)),
                    n ||
                      !(r & rt.BELOW) ||
                      s & rt.BELOW ||
                      ((p = d - (g - a) / f), (n = p >= o && p <= l)),
                    n ||
                      !(r & rt.LEFT) ||
                      s & rt.LEFT ||
                      ((m = g - (d - o) * f), (n = m >= a && m <= h));
                }
                return n;
              })(s, t, e);
            }))
        );
      }
      function qi(t, e, i, n, s) {
        if (
          !(function (t, e, i, n, s) {
            return (
              !!Vi(t, e, i, n, s) ||
              !!ee(t, e, i, n, s[0], s[1]) ||
              !!ee(t, e, i, n, s[0], s[3]) ||
              !!ee(t, e, i, n, s[2], s[1]) ||
              !!ee(t, e, i, n, s[2], s[3])
            );
          })(t, e, i[0], n, s)
        )
          return !1;
        if (1 === i.length) return !0;
        for (let r = 1, o = i.length; r < o; ++r)
          if (te(t, i[r - 1], i[r], n, s) && !Vi(t, i[r - 1], i[r], n, s))
            return !1;
        return !0;
      }
      function $i(t, e, i, n) {
        let s = t[e],
          r = t[e + 1],
          o = 0;
        for (let a = e + n; a < i; a += n) {
          const e = t[a],
            i = t[a + 1];
          (o += Math.sqrt((e - s) * (e - s) + (i - r) * (i - r))),
            (s = e),
            (r = i);
        }
        return o;
      }
      class Ui extends Pi {
        constructor(t, e) {
          super(),
            (this.flatMidpoint_ = null),
            (this.flatMidpointRevision_ = -1),
            (this.maxDelta_ = -1),
            (this.maxDeltaRevision_ = -1),
            void 0 === e || Array.isArray(t[0])
              ? this.setCoordinates(t, e)
              : this.setFlatCoordinates(e, t);
        }
        appendCoordinate(t) {
          d(this.flatCoordinates, t), this.changed();
        }
        clone() {
          const t = new Ui(this.flatCoordinates.slice(), this.layout);
          return t.applyProperties(this), t;
        }
        closestPointXY(t, e, i, n) {
          return n < lt(this.getExtent(), t, e)
            ? n
            : (this.maxDeltaRevision_ != this.getRevision() &&
                ((this.maxDelta_ = Math.sqrt(
                  Gi(
                    this.flatCoordinates,
                    0,
                    this.flatCoordinates.length,
                    this.stride,
                    0
                  )
                )),
                (this.maxDeltaRevision_ = this.getRevision())),
              zi(
                this.flatCoordinates,
                0,
                this.flatCoordinates.length,
                this.stride,
                this.maxDelta_,
                !1,
                t,
                e,
                i,
                n
              ));
        }
        forEachSegment(t) {
          return Ni(
            this.flatCoordinates,
            0,
            this.flatCoordinates.length,
            this.stride,
            t
          );
        }
        getCoordinateAtM(t, e) {
          return "XYM" != this.layout && "XYZM" != this.layout
            ? null
            : ((e = void 0 !== e && e),
              ii(
                this.flatCoordinates,
                0,
                this.flatCoordinates.length,
                this.stride,
                t,
                e
              ));
        }
        getCoordinates() {
          return Wi(
            this.flatCoordinates,
            0,
            this.flatCoordinates.length,
            this.stride
          );
        }
        getCoordinateAt(t, e) {
          return ei(
            this.flatCoordinates,
            0,
            this.flatCoordinates.length,
            this.stride,
            t,
            e,
            this.stride
          );
        }
        getLength() {
          return $i(
            this.flatCoordinates,
            0,
            this.flatCoordinates.length,
            this.stride
          );
        }
        getFlatMidpoint() {
          return (
            this.flatMidpointRevision_ != this.getRevision() &&
              ((this.flatMidpoint_ = this.getCoordinateAt(
                0.5,
                this.flatMidpoint_ ?? void 0
              )),
              (this.flatMidpointRevision_ = this.getRevision())),
            this.flatMidpoint_
          );
        }
        getSimplifiedGeometryInternal(t) {
          const e = [];
          return (
            (e.length = Ut(
              this.flatCoordinates,
              0,
              this.flatCoordinates.length,
              this.stride,
              t,
              e,
              0
            )),
            new Ui(e, "XY")
          );
        }
        getType() {
          return "LineString";
        }
        intersectsExtent(t) {
          return Vi(
            this.flatCoordinates,
            0,
            this.flatCoordinates.length,
            this.stride,
            t
          );
        }
        setCoordinates(t, e) {
          this.setLayout(e, t, 1),
            this.flatCoordinates || (this.flatCoordinates = []),
            (this.flatCoordinates.length = Li(
              this.flatCoordinates,
              0,
              t,
              this.stride
            )),
            this.changed();
        }
      }
      const Hi = Ui;
      function Ki(t, e, i, n) {
        let s = 0;
        const r = t[i - n],
          o = t[i - n + 1];
        let a = 0,
          l = 0;
        for (; e < i; e += n) {
          const i = t[e] - r,
            n = t[e + 1] - o;
          (s += l * i - a * n), (a = i), (l = n);
        }
        return s / 2;
      }
      function Ji(t, e, i, n) {
        let s = 0;
        for (let r = 0, o = i.length; r < o; ++r) {
          const o = i[r];
          (s += Ki(t, e, o, n)), (e = o);
        }
        return s;
      }
      class Qi extends Pi {
        constructor(t, e) {
          super(),
            (this.maxDelta_ = -1),
            (this.maxDeltaRevision_ = -1),
            void 0 === e || Array.isArray(t[0])
              ? this.setCoordinates(t, e)
              : this.setFlatCoordinates(e, t);
        }
        clone() {
          return new Qi(this.flatCoordinates.slice(), this.layout);
        }
        closestPointXY(t, e, i, n) {
          return n < lt(this.getExtent(), t, e)
            ? n
            : (this.maxDeltaRevision_ != this.getRevision() &&
                ((this.maxDelta_ = Math.sqrt(
                  Gi(
                    this.flatCoordinates,
                    0,
                    this.flatCoordinates.length,
                    this.stride,
                    0
                  )
                )),
                (this.maxDeltaRevision_ = this.getRevision())),
              zi(
                this.flatCoordinates,
                0,
                this.flatCoordinates.length,
                this.stride,
                this.maxDelta_,
                !0,
                t,
                e,
                i,
                n
              ));
        }
        getArea() {
          return Ki(
            this.flatCoordinates,
            0,
            this.flatCoordinates.length,
            this.stride
          );
        }
        getCoordinates() {
          return Wi(
            this.flatCoordinates,
            0,
            this.flatCoordinates.length,
            this.stride
          );
        }
        getSimplifiedGeometryInternal(t) {
          const e = [];
          return (
            (e.length = Ut(
              this.flatCoordinates,
              0,
              this.flatCoordinates.length,
              this.stride,
              t,
              e,
              0
            )),
            new Qi(e, "XY")
          );
        }
        getType() {
          return "LinearRing";
        }
        intersectsExtent(t) {
          return !1;
        }
        setCoordinates(t, e) {
          this.setLayout(e, t, 1),
            this.flatCoordinates || (this.flatCoordinates = []),
            (this.flatCoordinates.length = Li(
              this.flatCoordinates,
              0,
              t,
              this.stride
            )),
            this.changed();
        }
      }
      const tn = Qi;
      class en extends Pi {
        constructor(t, e, i) {
          super(),
            (this.ends_ = []),
            (this.flatInteriorPointRevision_ = -1),
            (this.flatInteriorPoint_ = null),
            (this.maxDelta_ = -1),
            (this.maxDeltaRevision_ = -1),
            (this.orientedRevision_ = -1),
            (this.orientedFlatCoordinates_ = null),
            void 0 !== e && i
              ? (this.setFlatCoordinates(e, t), (this.ends_ = i))
              : this.setCoordinates(t, e);
        }
        appendLinearRing(t) {
          this.flatCoordinates
            ? d(this.flatCoordinates, t.getFlatCoordinates())
            : (this.flatCoordinates = t.getFlatCoordinates().slice()),
            this.ends_.push(this.flatCoordinates.length),
            this.changed();
        }
        clone() {
          const t = new en(
            this.flatCoordinates.slice(),
            this.layout,
            this.ends_.slice()
          );
          return t.applyProperties(this), t;
        }
        closestPointXY(t, e, i, n) {
          return n < lt(this.getExtent(), t, e)
            ? n
            : (this.maxDeltaRevision_ != this.getRevision() &&
                ((this.maxDelta_ = Math.sqrt(
                  Zi(this.flatCoordinates, 0, this.ends_, this.stride, 0)
                )),
                (this.maxDeltaRevision_ = this.getRevision())),
              Bi(
                this.flatCoordinates,
                0,
                this.ends_,
                this.stride,
                this.maxDelta_,
                !0,
                t,
                e,
                i,
                n
              ));
        }
        containsXY(t, e) {
          return ie(
            this.getOrientedFlatCoordinates(),
            0,
            this.ends_,
            this.stride,
            t,
            e
          );
        }
        getArea() {
          return Ji(
            this.getOrientedFlatCoordinates(),
            0,
            this.ends_,
            this.stride
          );
        }
        getCoordinates(t) {
          let e;
          return (
            void 0 !== t
              ? ((e = this.getOrientedFlatCoordinates().slice()),
                Qe(e, 0, this.ends_, this.stride, t))
              : (e = this.flatCoordinates),
            Xi(e, 0, this.ends_, this.stride)
          );
        }
        getEnds() {
          return this.ends_;
        }
        getFlatInteriorPoint() {
          if (this.flatInteriorPointRevision_ != this.getRevision()) {
            const t = Mt(this.getExtent());
            (this.flatInteriorPoint_ = ne(
              this.getOrientedFlatCoordinates(),
              0,
              this.ends_,
              this.stride,
              t,
              0
            )),
              (this.flatInteriorPointRevision_ = this.getRevision());
          }
          return this.flatInteriorPoint_;
        }
        getInteriorPoint() {
          return new Oi(this.getFlatInteriorPoint(), "XYM");
        }
        getLinearRingCount() {
          return this.ends_.length;
        }
        getLinearRing(t) {
          return t < 0 || this.ends_.length <= t
            ? null
            : new tn(
                this.flatCoordinates.slice(
                  0 === t ? 0 : this.ends_[t - 1],
                  this.ends_[t]
                ),
                this.layout
              );
        }
        getLinearRings() {
          const t = this.layout,
            e = this.flatCoordinates,
            i = this.ends_,
            n = [];
          let s = 0;
          for (let r = 0, o = i.length; r < o; ++r) {
            const o = i[r],
              a = new tn(e.slice(s, o), t);
            n.push(a), (s = o);
          }
          return n;
        }
        getOrientedFlatCoordinates() {
          if (this.orientedRevision_ != this.getRevision()) {
            const t = this.flatCoordinates;
            Ke(t, 0, this.ends_, this.stride)
              ? (this.orientedFlatCoordinates_ = t)
              : ((this.orientedFlatCoordinates_ = t.slice()),
                (this.orientedFlatCoordinates_.length = Qe(
                  this.orientedFlatCoordinates_,
                  0,
                  this.ends_,
                  this.stride
                ))),
              (this.orientedRevision_ = this.getRevision());
          }
          return this.orientedFlatCoordinates_;
        }
        getSimplifiedGeometryInternal(t) {
          const e = [],
            i = [];
          return (
            (e.length = Qt(
              this.flatCoordinates,
              0,
              this.ends_,
              this.stride,
              Math.sqrt(t),
              e,
              0,
              i
            )),
            new en(e, "XY", i)
          );
        }
        getType() {
          return "Polygon";
        }
        intersectsExtent(t) {
          return qi(
            this.getOrientedFlatCoordinates(),
            0,
            this.ends_,
            this.stride,
            t
          );
        }
        setCoordinates(t, e) {
          this.setLayout(e, t, 2),
            this.flatCoordinates || (this.flatCoordinates = []);
          const i = Ti(this.flatCoordinates, 0, t, this.stride, this.ends_);
          (this.flatCoordinates.length = 0 === i.length ? 0 : i[i.length - 1]),
            this.changed();
        }
      }
      const nn = en;
      function sn(t) {
        if (Tt(t)) throw new Error("Cannot create polygon from empty extent");
        const e = t[0],
          i = t[1],
          n = t[2],
          s = t[3],
          r = [e, i, e, s, n, s, n, i, e, i];
        return new en(r, "XY", [r.length]);
      }
      function rn(t, e, i) {
        e = e || 32;
        const n = t.getStride(),
          s = t.getLayout(),
          r = t.getCenter(),
          o = n * (e + 1),
          a = new Array(o);
        for (let c = 0; c < o; c += n) {
          (a[c] = 0), (a[c + 1] = 0);
          for (let t = 2; t < n; t++) a[c + t] = r[t];
        }
        const l = [a.length],
          h = new en(a, s, l);
        return (
          (function (t, e, i, n) {
            const s = t.getFlatCoordinates(),
              r = t.getStride(),
              o = s.length / r - 1,
              a = n || 0;
            for (let l = 0; l <= o; ++l) {
              const t = l * r,
                n = a + (2 * Vt(l, o) * Math.PI) / o;
              (s[t] = e[0] + i * Math.cos(n)),
                (s[t + 1] = e[1] + i * Math.sin(n));
            }
            t.changed();
          })(h, r, t.getRadius(), i),
          h
        );
      }
      class on extends Pi {
        constructor(t, e) {
          super(),
            e && !Array.isArray(t[0])
              ? this.setFlatCoordinates(e, t)
              : this.setCoordinates(t, e);
        }
        appendPoint(t) {
          d(this.flatCoordinates, t.getFlatCoordinates()), this.changed();
        }
        clone() {
          const t = new on(this.flatCoordinates.slice(), this.layout);
          return t.applyProperties(this), t;
        }
        closestPointXY(t, e, i, n) {
          if (n < lt(this.getExtent(), t, e)) return n;
          const s = this.flatCoordinates,
            r = this.stride;
          for (let o = 0, a = s.length; o < a; o += r) {
            const a = Xt(t, e, s[o], s[o + 1]);
            if (a < n) {
              n = a;
              for (let t = 0; t < r; ++t) i[t] = s[o + t];
              i.length = r;
            }
          }
          return n;
        }
        getCoordinates() {
          return Wi(
            this.flatCoordinates,
            0,
            this.flatCoordinates.length,
            this.stride
          );
        }
        getPoint(t) {
          const e = this.flatCoordinates.length / this.stride;
          return t < 0 || e <= t
            ? null
            : new Oi(
                this.flatCoordinates.slice(
                  t * this.stride,
                  (t + 1) * this.stride
                ),
                this.layout
              );
        }
        getPoints() {
          const t = this.flatCoordinates,
            e = this.layout,
            i = this.stride,
            n = [];
          for (let s = 0, r = t.length; s < r; s += i) {
            const r = new Oi(t.slice(s, s + i), e);
            n.push(r);
          }
          return n;
        }
        getType() {
          return "MultiPoint";
        }
        intersectsExtent(t) {
          const e = this.flatCoordinates,
            i = this.stride;
          for (let n = 0, s = e.length; n < s; n += i) {
            if (ut(t, e[n], e[n + 1])) return !0;
          }
          return !1;
        }
        setCoordinates(t, e) {
          this.setLayout(e, t, 1),
            this.flatCoordinates || (this.flatCoordinates = []),
            (this.flatCoordinates.length = Li(
              this.flatCoordinates,
              0,
              t,
              this.stride
            )),
            this.changed();
        }
      }
      const an = on;
      class ln extends Pi {
        constructor(t, e, i) {
          if (
            (super(),
            (this.ends_ = []),
            (this.maxDelta_ = -1),
            (this.maxDeltaRevision_ = -1),
            Array.isArray(t[0]))
          )
            this.setCoordinates(t, e);
          else if (void 0 !== e && i)
            this.setFlatCoordinates(e, t), (this.ends_ = i);
          else {
            const e = t,
              i = [],
              n = [];
            for (let t = 0, r = e.length; t < r; ++t) {
              d(i, e[t].getFlatCoordinates()), n.push(i.length);
            }
            const s = 0 === e.length ? this.getLayout() : e[0].getLayout();
            this.setFlatCoordinates(s, i), (this.ends_ = n);
          }
        }
        appendLineString(t) {
          d(this.flatCoordinates, t.getFlatCoordinates().slice()),
            this.ends_.push(this.flatCoordinates.length),
            this.changed();
        }
        clone() {
          const t = new ln(
            this.flatCoordinates.slice(),
            this.layout,
            this.ends_.slice()
          );
          return t.applyProperties(this), t;
        }
        closestPointXY(t, e, i, n) {
          return n < lt(this.getExtent(), t, e)
            ? n
            : (this.maxDeltaRevision_ != this.getRevision() &&
                ((this.maxDelta_ = Math.sqrt(
                  Zi(this.flatCoordinates, 0, this.ends_, this.stride, 0)
                )),
                (this.maxDeltaRevision_ = this.getRevision())),
              Bi(
                this.flatCoordinates,
                0,
                this.ends_,
                this.stride,
                this.maxDelta_,
                !1,
                t,
                e,
                i,
                n
              ));
        }
        getCoordinateAtM(t, e, i) {
          return ("XYM" != this.layout && "XYZM" != this.layout) ||
            0 === this.flatCoordinates.length
            ? null
            : ((e = void 0 !== e && e),
              (i = void 0 !== i && i),
              (function (t, e, i, n, s, r, o) {
                if (o) return ii(t, e, i[i.length - 1], n, s, r);
                let a;
                if (s < t[n - 1])
                  return r ? ((a = t.slice(0, n)), (a[n - 1] = s), a) : null;
                if (t[t.length - 1] < s)
                  return r
                    ? ((a = t.slice(t.length - n)), (a[n - 1] = s), a)
                    : null;
                for (let l = 0, h = i.length; l < h; ++l) {
                  const r = i[l];
                  if (e != r) {
                    if (s < t[e + n - 1]) return null;
                    if (s <= t[r - 1]) return ii(t, e, r, n, s, !1);
                    e = r;
                  }
                }
                return null;
              })(this.flatCoordinates, 0, this.ends_, this.stride, t, e, i));
        }
        getCoordinates() {
          return Xi(this.flatCoordinates, 0, this.ends_, this.stride);
        }
        getEnds() {
          return this.ends_;
        }
        getLineString(t) {
          return t < 0 || this.ends_.length <= t
            ? null
            : new Hi(
                this.flatCoordinates.slice(
                  0 === t ? 0 : this.ends_[t - 1],
                  this.ends_[t]
                ),
                this.layout
              );
        }
        getLineStrings() {
          const t = this.flatCoordinates,
            e = this.ends_,
            i = this.layout,
            n = [];
          let s = 0;
          for (let r = 0, o = e.length; r < o; ++r) {
            const o = e[r],
              a = new Hi(t.slice(s, o), i);
            n.push(a), (s = o);
          }
          return n;
        }
        getFlatMidpoints() {
          const t = [],
            e = this.flatCoordinates;
          let i = 0;
          const n = this.ends_,
            s = this.stride;
          for (let r = 0, o = n.length; r < o; ++r) {
            const o = n[r];
            d(t, ei(e, i, o, s, 0.5)), (i = o);
          }
          return t;
        }
        getSimplifiedGeometryInternal(t) {
          const e = [],
            i = [];
          return (
            (e.length = Ht(
              this.flatCoordinates,
              0,
              this.ends_,
              this.stride,
              t,
              e,
              0,
              i
            )),
            new ln(e, "XY", i)
          );
        }
        getType() {
          return "MultiLineString";
        }
        intersectsExtent(t) {
          return (function (t, e, i, n, s) {
            for (let r = 0, o = i.length; r < o; ++r) {
              if (Vi(t, e, i[r], n, s)) return !0;
              e = i[r];
            }
            return !1;
          })(this.flatCoordinates, 0, this.ends_, this.stride, t);
        }
        setCoordinates(t, e) {
          this.setLayout(e, t, 2),
            this.flatCoordinates || (this.flatCoordinates = []);
          const i = Ti(this.flatCoordinates, 0, t, this.stride, this.ends_);
          (this.flatCoordinates.length = 0 === i.length ? 0 : i[i.length - 1]),
            this.changed();
        }
      }
      const hn = ln;
      class cn extends Pi {
        constructor(t, e, i) {
          if (
            (super(),
            (this.endss_ = []),
            (this.flatInteriorPointsRevision_ = -1),
            (this.flatInteriorPoints_ = null),
            (this.maxDelta_ = -1),
            (this.maxDeltaRevision_ = -1),
            (this.orientedRevision_ = -1),
            (this.orientedFlatCoordinates_ = null),
            !i && !Array.isArray(t[0]))
          ) {
            const n = t,
              s = [],
              r = [];
            for (let t = 0, e = n.length; t < e; ++t) {
              const e = n[t],
                i = s.length,
                o = e.getEnds();
              for (let t = 0, n = o.length; t < n; ++t) o[t] += i;
              d(s, e.getFlatCoordinates()), r.push(o);
            }
            (e = 0 === n.length ? this.getLayout() : n[0].getLayout()),
              (t = s),
              (i = r);
          }
          void 0 !== e && i
            ? (this.setFlatCoordinates(e, t), (this.endss_ = i))
            : this.setCoordinates(t, e);
        }
        appendPolygon(t) {
          let e;
          if (this.flatCoordinates) {
            const i = this.flatCoordinates.length;
            d(this.flatCoordinates, t.getFlatCoordinates()),
              (e = t.getEnds().slice());
            for (let t = 0, n = e.length; t < n; ++t) e[t] += i;
          } else
            (this.flatCoordinates = t.getFlatCoordinates().slice()),
              (e = t.getEnds().slice()),
              this.endss_.push();
          this.endss_.push(e), this.changed();
        }
        clone() {
          const t = this.endss_.length,
            e = new Array(t);
          for (let n = 0; n < t; ++n) e[n] = this.endss_[n].slice();
          const i = new cn(this.flatCoordinates.slice(), this.layout, e);
          return i.applyProperties(this), i;
        }
        closestPointXY(t, e, i, n) {
          return n < lt(this.getExtent(), t, e)
            ? n
            : (this.maxDeltaRevision_ != this.getRevision() &&
                ((this.maxDelta_ = Math.sqrt(
                  (function (t, e, i, n, s) {
                    for (let r = 0, o = i.length; r < o; ++r) {
                      const o = i[r];
                      (s = Zi(t, e, o, n, s)), (e = o[o.length - 1]);
                    }
                    return s;
                  })(this.flatCoordinates, 0, this.endss_, this.stride, 0)
                )),
                (this.maxDeltaRevision_ = this.getRevision())),
              (function (t, e, i, n, s, r, o, a, l, h, c) {
                c = c || [NaN, NaN];
                for (let u = 0, d = i.length; u < d; ++u) {
                  const d = i[u];
                  (h = Bi(t, e, d, n, s, r, o, a, l, h, c)),
                    (e = d[d.length - 1]);
                }
                return h;
              })(
                this.getOrientedFlatCoordinates(),
                0,
                this.endss_,
                this.stride,
                this.maxDelta_,
                !0,
                t,
                e,
                i,
                n
              ));
        }
        containsXY(t, e) {
          return (function (t, e, i, n, s, r) {
            if (0 === i.length) return !1;
            for (let o = 0, a = i.length; o < a; ++o) {
              const a = i[o];
              if (ie(t, e, a, n, s, r)) return !0;
              e = a[a.length - 1];
            }
            return !1;
          })(
            this.getOrientedFlatCoordinates(),
            0,
            this.endss_,
            this.stride,
            t,
            e
          );
        }
        getArea() {
          return (function (t, e, i, n) {
            let s = 0;
            for (let r = 0, o = i.length; r < o; ++r) {
              const o = i[r];
              (s += Ji(t, e, o, n)), (e = o[o.length - 1]);
            }
            return s;
          })(this.getOrientedFlatCoordinates(), 0, this.endss_, this.stride);
        }
        getCoordinates(t) {
          let e;
          return (
            void 0 !== t
              ? ((e = this.getOrientedFlatCoordinates().slice()),
                ti(e, 0, this.endss_, this.stride, t))
              : (e = this.flatCoordinates),
            Yi(e, 0, this.endss_, this.stride)
          );
        }
        getEndss() {
          return this.endss_;
        }
        getFlatInteriorPoints() {
          if (this.flatInteriorPointsRevision_ != this.getRevision()) {
            const t = ni(this.flatCoordinates, 0, this.endss_, this.stride);
            (this.flatInteriorPoints_ = se(
              this.getOrientedFlatCoordinates(),
              0,
              this.endss_,
              this.stride,
              t
            )),
              (this.flatInteriorPointsRevision_ = this.getRevision());
          }
          return this.flatInteriorPoints_;
        }
        getInteriorPoints() {
          return new an(this.getFlatInteriorPoints().slice(), "XYM");
        }
        getOrientedFlatCoordinates() {
          if (this.orientedRevision_ != this.getRevision()) {
            const t = this.flatCoordinates;
            Je(t, 0, this.endss_, this.stride)
              ? (this.orientedFlatCoordinates_ = t)
              : ((this.orientedFlatCoordinates_ = t.slice()),
                (this.orientedFlatCoordinates_.length = ti(
                  this.orientedFlatCoordinates_,
                  0,
                  this.endss_,
                  this.stride
                ))),
              (this.orientedRevision_ = this.getRevision());
          }
          return this.orientedFlatCoordinates_;
        }
        getSimplifiedGeometryInternal(t) {
          const e = [],
            i = [];
          return (
            (e.length = (function (t, e, i, n, s, r, o, a) {
              for (let l = 0, h = i.length; l < h; ++l) {
                const h = i[l],
                  c = [];
                (o = Qt(t, e, h, n, s, r, o, c)),
                  a.push(c),
                  (e = h[h.length - 1]);
              }
              return o;
            })(
              this.flatCoordinates,
              0,
              this.endss_,
              this.stride,
              Math.sqrt(t),
              e,
              0,
              i
            )),
            new cn(e, "XY", i)
          );
        }
        getPolygon(t) {
          if (t < 0 || this.endss_.length <= t) return null;
          let e;
          if (0 === t) e = 0;
          else {
            const i = this.endss_[t - 1];
            e = i[i.length - 1];
          }
          const i = this.endss_[t].slice(),
            n = i[i.length - 1];
          if (0 !== e) for (let s = 0, r = i.length; s < r; ++s) i[s] -= e;
          return new nn(this.flatCoordinates.slice(e, n), this.layout, i);
        }
        getPolygons() {
          const t = this.layout,
            e = this.flatCoordinates,
            i = this.endss_,
            n = [];
          let s = 0;
          for (let r = 0, o = i.length; r < o; ++r) {
            const o = i[r].slice(),
              a = o[o.length - 1];
            if (0 !== s) for (let t = 0, e = o.length; t < e; ++t) o[t] -= s;
            const l = new nn(e.slice(s, a), t, o);
            n.push(l), (s = a);
          }
          return n;
        }
        getType() {
          return "MultiPolygon";
        }
        intersectsExtent(t) {
          return (function (t, e, i, n, s) {
            for (let r = 0, o = i.length; r < o; ++r) {
              const o = i[r];
              if (qi(t, e, o, n, s)) return !0;
              e = o[o.length - 1];
            }
            return !1;
          })(this.getOrientedFlatCoordinates(), 0, this.endss_, this.stride, t);
        }
        setCoordinates(t, e) {
          this.setLayout(e, t, 3),
            this.flatCoordinates || (this.flatCoordinates = []);
          const i = Di(this.flatCoordinates, 0, t, this.stride, this.endss_);
          if (0 === i.length) this.flatCoordinates.length = 0;
          else {
            const t = i[i.length - 1];
            this.flatCoordinates.length = 0 === t.length ? 0 : t[t.length - 1];
          }
          this.changed();
        }
      }
      const un = cn;
      class dn extends Ii {
        constructor(t) {
          super(),
            (this.geometries_ = t),
            (this.changeEventsKeys_ = []),
            this.listenGeometriesChange_();
        }
        unlistenGeometriesChange_() {
          this.changeEventsKeys_.forEach(M),
            (this.changeEventsKeys_.length = 0);
        }
        listenGeometriesChange_() {
          const t = this.geometries_;
          for (let e = 0, i = t.length; e < i; ++e)
            this.changeEventsKeys_.push(b(t[e], w, this.changed, this));
        }
        clone() {
          const t = new dn(gn(this.geometries_));
          return t.applyProperties(this), t;
        }
        closestPointXY(t, e, i, n) {
          if (n < lt(this.getExtent(), t, e)) return n;
          const s = this.geometries_;
          for (let r = 0, o = s.length; r < o; ++r)
            n = s[r].closestPointXY(t, e, i, n);
          return n;
        }
        containsXY(t, e) {
          const i = this.geometries_;
          for (let n = 0, s = i.length; n < s; ++n)
            if (i[n].containsXY(t, e)) return !0;
          return !1;
        }
        computeExtent(t) {
          pt(t);
          const e = this.geometries_;
          for (let i = 0, n = e.length; i < n; ++i) xt(t, e[i].getExtent());
          return t;
        }
        getGeometries() {
          return gn(this.geometries_);
        }
        getGeometriesArray() {
          return this.geometries_;
        }
        getGeometriesArrayRecursive() {
          let t = [];
          const e = this.geometries_;
          for (let i = 0, n = e.length; i < n; ++i)
            e[i].getType() === this.getType()
              ? (t = t.concat(e[i].getGeometriesArrayRecursive()))
              : t.push(e[i]);
          return t;
        }
        getSimplifiedGeometry(t) {
          if (
            (this.simplifiedGeometryRevision !== this.getRevision() &&
              ((this.simplifiedGeometryMaxMinSquaredTolerance = 0),
              (this.simplifiedGeometryRevision = this.getRevision())),
            t < 0 ||
              (0 !== this.simplifiedGeometryMaxMinSquaredTolerance &&
                t < this.simplifiedGeometryMaxMinSquaredTolerance))
          )
            return this;
          const e = [],
            i = this.geometries_;
          let n = !1;
          for (let s = 0, r = i.length; s < r; ++s) {
            const r = i[s],
              o = r.getSimplifiedGeometry(t);
            e.push(o), o !== r && (n = !0);
          }
          if (n) {
            return new dn(e);
          }
          return (this.simplifiedGeometryMaxMinSquaredTolerance = t), this;
        }
        getType() {
          return "GeometryCollection";
        }
        intersectsExtent(t) {
          const e = this.geometries_;
          for (let i = 0, n = e.length; i < n; ++i)
            if (e[i].intersectsExtent(t)) return !0;
          return !1;
        }
        isEmpty() {
          return 0 === this.geometries_.length;
        }
        rotate(t, e) {
          const i = this.geometries_;
          for (let n = 0, s = i.length; n < s; ++n) i[n].rotate(t, e);
          this.changed();
        }
        scale(t, e, i) {
          i || (i = Mt(this.getExtent()));
          const n = this.geometries_;
          for (let s = 0, r = n.length; s < r; ++s) n[s].scale(t, e, i);
          this.changed();
        }
        setGeometries(t) {
          this.setGeometriesArray(gn(t));
        }
        setGeometriesArray(t) {
          this.unlistenGeometriesChange_(),
            (this.geometries_ = t),
            this.listenGeometriesChange_(),
            this.changed();
        }
        applyTransform(t) {
          const e = this.geometries_;
          for (let i = 0, n = e.length; i < n; ++i) e[i].applyTransform(t);
          this.changed();
        }
        translate(t, e) {
          const i = this.geometries_;
          for (let n = 0, s = i.length; n < s; ++n) i[n].translate(t, e);
          this.changed();
        }
        disposeInternal() {
          this.unlistenGeometriesChange_(), super.disposeInternal();
        }
      }
      function gn(t) {
        return t.map((t) => t.clone());
      }
      const fn = dn;
      const pn = class {
        constructor() {
          (this.dataProjection = void 0),
            (this.defaultFeatureProjection = void 0),
            (this.featureClass = O),
            (this.supportedMediaTypes = null);
        }
        getReadOptions(t, e) {
          if (e) {
            let i = e.dataProjection
              ? Ae(e.dataProjection)
              : this.readProjection(t);
            e.extent &&
              i &&
              "tile-pixels" === i.getUnits() &&
              ((i = Ae(i)), i.setWorldExtent(e.extent)),
              (e = {
                dataProjection: i,
                featureProjection: e.featureProjection,
              });
          }
          return this.adaptOptions(e);
        }
        adaptOptions(t) {
          return Object.assign(
            {
              dataProjection: this.dataProjection,
              featureProjection: this.defaultFeatureProjection,
              featureClass: this.featureClass,
            },
            t
          );
        }
        getType() {
          return R();
        }
        readFeature(t, e) {
          return R();
        }
        readFeatures(t, e) {
          return R();
        }
        readGeometry(t, e) {
          return R();
        }
        readProjection(t) {
          return R();
        }
        writeFeature(t, e) {
          return R();
        }
        writeFeatures(t, e) {
          return R();
        }
        writeGeometry(t, e) {
          return R();
        }
      };
      function mn(t, e, i) {
        const n = i ? Ae(i.featureProjection) : null,
          s = i ? Ae(i.dataProjection) : null;
        let r = t;
        if (
          n &&
          s &&
          !(function (t, e) {
            if (t === e) return !0;
            const i = t.getUnits() === e.getUnits();
            return (t.getCode() === e.getCode() || Ge(t, e) === Le) && i;
          })(n, s)
        ) {
          e && (r = t.clone());
          const i = e ? n : s,
            o = e ? s : n;
          "tile-pixels" === i.getUnits()
            ? r.transform(i, o)
            : r.applyTransform(Ze(i, o));
        }
        if (e && i && void 0 !== i.decimals) {
          const e = Math.pow(10, i.decimals),
            n = function (t) {
              for (let i = 0, n = t.length; i < n; ++i)
                t[i] = Math.round(t[i] * e) / e;
              return t;
            };
          r === t && (r = t.clone()), r.applyTransform(n);
        }
        return r;
      }
      const _n = {
        Point: Oi,
        LineString: Hi,
        Polygon: nn,
        MultiPoint: an,
        MultiLineString: hn,
        MultiPolygon: un,
      };
      function yn(t, e) {
        const i = t.geometry;
        if (!i) return [];
        if (Array.isArray(i))
          return i.map((e) => yn({ ...t, geometry: e })).flat();
        const n = "MultiPolygon" === i.type ? "Polygon" : i.type;
        if ("GeometryCollection" === n || "Circle" === n)
          throw new Error("Unsupported geometry type: " + n);
        const s = i.layout.length;
        return mn(
          new li(
            n,
            "Polygon" === n
              ? (function (t, e, i) {
                  return Array.isArray(e[0])
                    ? (Je(t, 0, e, i) || ti((t = t.slice()), 0, e, i), t)
                    : (Ke(t, 0, e, i) || Qe((t = t.slice()), 0, e, i), t);
                })(i.flatCoordinates, i.ends, s)
              : i.flatCoordinates,
            i.ends?.flat(),
            s,
            t.properties || {},
            t.id
          ).enableSimplifyTransformed(),
          !1,
          e
        );
      }
      function xn(t, e) {
        if (!t) return null;
        if (Array.isArray(t)) {
          const i = t.map((t) => xn(t, e));
          return new fn(i);
        }
        return mn(
          new (0, _n[t.type])(t.flatCoordinates, t.layout, t.ends),
          !1,
          e
        );
      }
      function vn(t) {
        if ("string" === typeof t) {
          const e = JSON.parse(t);
          return e || null;
        }
        return null !== t ? t : null;
      }
      const wn = class extends pn {
        constructor() {
          super();
        }
        getType() {
          return "json";
        }
        readFeature(t, e) {
          return this.readFeatureFromObject(vn(t), this.getReadOptions(t, e));
        }
        readFeatures(t, e) {
          return this.readFeaturesFromObject(vn(t), this.getReadOptions(t, e));
        }
        readFeatureFromObject(t, e) {
          return R();
        }
        readFeaturesFromObject(t, e) {
          return R();
        }
        readGeometry(t, e) {
          return this.readGeometryFromObject(vn(t), this.getReadOptions(t, e));
        }
        readGeometryFromObject(t, e) {
          return R();
        }
        readProjection(t) {
          return this.readProjectionFromObject(vn(t));
        }
        readProjectionFromObject(t) {
          return R();
        }
        writeFeature(t, e) {
          return JSON.stringify(this.writeFeatureObject(t, e));
        }
        writeFeatureObject(t, e) {
          return R();
        }
        writeFeatures(t, e) {
          return JSON.stringify(this.writeFeaturesObject(t, e));
        }
        writeFeaturesObject(t, e) {
          return R();
        }
        writeGeometry(t, e) {
          return JSON.stringify(this.writeGeometryObject(t, e));
        }
        writeGeometryObject(t, e) {
          return R();
        }
      };
      function Sn(t, e) {
        if (!t) return null;
        let i;
        switch (t.type) {
          case "Point":
            i = (function (t) {
              const e = t.coordinates;
              return {
                type: "Point",
                flatCoordinates: e,
                layout: Ei(e.length),
              };
            })(t);
            break;
          case "LineString":
            i = (function (t) {
              const e = t.coordinates,
                i = e.flat();
              return {
                type: "LineString",
                flatCoordinates: i,
                ends: [i.length],
                layout: Ei(e[0]?.length || 2),
              };
            })(t);
            break;
          case "Polygon":
            i = (function (t) {
              const e = t.coordinates,
                i = [],
                n = e[0]?.[0]?.length,
                s = Ti(i, 0, e, n);
              return {
                type: "Polygon",
                flatCoordinates: i,
                ends: s,
                layout: Ei(n),
              };
            })(t);
            break;
          case "MultiPoint":
            i = (function (t) {
              const e = t.coordinates;
              return {
                type: "MultiPoint",
                flatCoordinates: e.flat(),
                layout: Ei(e[0]?.length || 2),
              };
            })(t);
            break;
          case "MultiLineString":
            i = (function (t) {
              const e = t.coordinates,
                i = e[0]?.[0]?.length || 2,
                n = [],
                s = Ti(n, 0, e, i);
              return {
                type: "MultiLineString",
                flatCoordinates: n,
                ends: s,
                layout: Ei(i),
              };
            })(t);
            break;
          case "MultiPolygon":
            i = (function (t) {
              const e = t.coordinates,
                i = [],
                n = e[0]?.[0]?.[0].length || 2,
                s = Di(i, 0, e, n);
              return {
                type: "MultiPolygon",
                flatCoordinates: i,
                ends: s,
                layout: Ei(n),
              };
            })(t);
            break;
          case "GeometryCollection":
            i = (function (t, e) {
              const i = t.geometries.map(function (t) {
                return Sn(t, e);
              });
              return i;
            })(t);
            break;
          default:
            throw new Error("Unsupported GeoJSON type: " + t.type);
        }
        return i;
      }
      function Cn(t, e) {
        const i = (t = mn(t, !0, e)).getType();
        let n;
        switch (i) {
          case "Point":
            n = (function (t, e) {
              return { type: "Point", coordinates: t.getCoordinates() };
            })(t);
            break;
          case "LineString":
            n = (function (t, e) {
              return { type: "LineString", coordinates: t.getCoordinates() };
            })(t);
            break;
          case "Polygon":
            n = (function (t, e) {
              let i;
              e && (i = e.rightHanded);
              return { type: "Polygon", coordinates: t.getCoordinates(i) };
            })(t, e);
            break;
          case "MultiPoint":
            n = (function (t, e) {
              return { type: "MultiPoint", coordinates: t.getCoordinates() };
            })(t);
            break;
          case "MultiLineString":
            n = (function (t, e) {
              return {
                type: "MultiLineString",
                coordinates: t.getCoordinates(),
              };
            })(t);
            break;
          case "MultiPolygon":
            n = (function (t, e) {
              let i;
              e && (i = e.rightHanded);
              return { type: "MultiPolygon", coordinates: t.getCoordinates(i) };
            })(t, e);
            break;
          case "GeometryCollection":
            n = (function (t, e) {
              (e = Object.assign({}, e)), delete e.featureProjection;
              const i = t.getGeometriesArray().map(function (t) {
                return Cn(t, e);
              });
              return { type: "GeometryCollection", geometries: i };
            })(t, e);
            break;
          case "Circle":
            n = { type: "GeometryCollection", geometries: [] };
            break;
          default:
            throw new Error("Unsupported geometry type: " + i);
        }
        return n;
      }
      const bn = class extends wn {
        constructor(t) {
          (t = t || {}),
            super(),
            (this.dataProjection = Ae(
              t.dataProjection ? t.dataProjection : "EPSG:4326"
            )),
            t.featureProjection &&
              (this.defaultFeatureProjection = Ae(t.featureProjection)),
            t.featureClass && (this.featureClass = t.featureClass),
            (this.geometryName_ = t.geometryName),
            (this.extractGeometryName_ = t.extractGeometryName),
            (this.supportedMediaTypes = [
              "application/geo+json",
              "application/vnd.geo+json",
            ]);
        }
        readFeatureFromObject(t, e) {
          let i = null;
          i =
            "Feature" === t.type
              ? t
              : { type: "Feature", geometry: t, properties: null };
          const n = Sn(i.geometry, e);
          if (this.featureClass === li)
            return yn({ geometry: n, id: i.id, properties: i.properties }, e);
          const s = new O();
          return (
            this.geometryName_
              ? s.setGeometryName(this.geometryName_)
              : this.extractGeometryName_ &&
                i.geometry_name &&
                s.setGeometryName(i.geometry_name),
            s.setGeometry(xn(n, e)),
            "id" in i && s.setId(i.id),
            i.properties && s.setProperties(i.properties, !0),
            s
          );
        }
        readFeaturesFromObject(t, e) {
          let i = null;
          if ("FeatureCollection" === t.type) {
            i = [];
            const n = t.features;
            for (let t = 0, s = n.length; t < s; ++t) {
              const s = this.readFeatureFromObject(n[t], e);
              s && i.push(s);
            }
          } else i = [this.readFeatureFromObject(t, e)];
          return i.flat();
        }
        readGeometryFromObject(t, e) {
          return (function (t, e) {
            const i = Sn(t, e);
            return xn(i, e);
          })(t, e);
        }
        readProjectionFromObject(t) {
          const e = t.crs;
          let i;
          if (e)
            if ("name" == e.type) i = Ae(e.properties.name);
            else {
              if ("EPSG" !== e.type) throw new Error("Unknown SRS type");
              i = Ae("EPSG:" + e.properties.code);
            }
          else i = this.dataProjection;
          return i;
        }
        writeFeatureObject(t, e) {
          e = this.adaptOptions(e);
          const i = { type: "Feature", geometry: null, properties: null },
            n = t.getId();
          if ((void 0 !== n && (i.id = n), !t.hasProperties())) return i;
          const s = t.getProperties(),
            r = t.getGeometry();
          return (
            r && ((i.geometry = Cn(r, e)), delete s[t.getGeometryName()]),
            x(s) || (i.properties = s),
            i
          );
        }
        writeFeaturesObject(t, e) {
          e = this.adaptOptions(e);
          const i = [];
          for (let n = 0, s = t.length; n < s; ++n)
            i.push(this.writeFeatureObject(t[n], e));
          return { type: "FeatureCollection", features: i };
        }
        writeGeometryObject(t, e) {
          return Cn(t, this.adaptOptions(e));
        }
      };
      var kn = i(93402),
        Mn = i(48260),
        In = i(25609),
        En = i(98139);
      const Rn = "Left",
        Pn = "Right",
        Fn = "Up",
        Ln = "Down",
        Tn = {
          delta: 10,
          preventScrollOnSwipe: !1,
          rotationAngle: 0,
          trackMouse: !1,
          trackTouch: !0,
          swipeDuration: 1 / 0,
          touchEventOptions: { passive: !0 },
        },
        Dn = { first: !0, initial: [0, 0], start: 0, swiping: !1, xy: [0, 0] },
        An = "mousemove",
        On = "mouseup",
        jn = "touchend",
        Gn = "touchmove",
        Zn = "touchstart";
      function zn(t, e) {
        if (0 === e) return t;
        const i = (Math.PI / 180) * e;
        return [
          t[0] * Math.cos(i) + t[1] * Math.sin(i),
          t[1] * Math.cos(i) - t[0] * Math.sin(i),
        ];
      }
      function Bn(t, e) {
        const i = (e) => {
            const i = "touches" in e;
            (i && e.touches.length > 1) ||
              t((t, s) => {
                s.trackMouse &&
                  !i &&
                  (document.addEventListener(An, n),
                  document.addEventListener(On, r));
                const { clientX: o, clientY: a } = i ? e.touches[0] : e,
                  l = zn([o, a], s.rotationAngle);
                return (
                  s.onTouchStartOrOnMouseDown &&
                    s.onTouchStartOrOnMouseDown({ event: e }),
                  Object.assign(Object.assign(Object.assign({}, t), Dn), {
                    initial: l.slice(),
                    xy: l,
                    start: e.timeStamp || 0,
                  })
                );
              });
          },
          n = (e) => {
            t((t, i) => {
              const n = "touches" in e;
              if (n && e.touches.length > 1) return t;
              if (e.timeStamp - t.start > i.swipeDuration)
                return t.swiping
                  ? Object.assign(Object.assign({}, t), { swiping: !1 })
                  : t;
              const { clientX: s, clientY: r } = n ? e.touches[0] : e,
                [o, a] = zn([s, r], i.rotationAngle),
                l = o - t.xy[0],
                h = a - t.xy[1],
                c = Math.abs(l),
                u = Math.abs(h),
                d = (e.timeStamp || 0) - t.start,
                g = Math.sqrt(c * c + u * u) / (d || 1),
                f = [l / (d || 1), h / (d || 1)],
                p = (function (t, e, i, n) {
                  return t > e ? (i > 0 ? Pn : Rn) : n > 0 ? Ln : Fn;
                })(c, u, l, h),
                m =
                  "number" === typeof i.delta
                    ? i.delta
                    : i.delta[p.toLowerCase()] || Tn.delta;
              if (c < m && u < m && !t.swiping) return t;
              const _ = {
                absX: c,
                absY: u,
                deltaX: l,
                deltaY: h,
                dir: p,
                event: e,
                first: t.first,
                initial: t.initial,
                velocity: g,
                vxvy: f,
              };
              _.first && i.onSwipeStart && i.onSwipeStart(_),
                i.onSwiping && i.onSwiping(_);
              let y = !1;
              return (
                (i.onSwiping || i.onSwiped || i[`onSwiped${p}`]) && (y = !0),
                y &&
                  i.preventScrollOnSwipe &&
                  i.trackTouch &&
                  e.cancelable &&
                  e.preventDefault(),
                Object.assign(Object.assign({}, t), {
                  first: !1,
                  eventData: _,
                  swiping: !0,
                })
              );
            });
          },
          s = (e) => {
            t((t, i) => {
              let n;
              if (t.swiping && t.eventData) {
                if (e.timeStamp - t.start < i.swipeDuration) {
                  (n = Object.assign(Object.assign({}, t.eventData), {
                    event: e,
                  })),
                    i.onSwiped && i.onSwiped(n);
                  const s = i[`onSwiped${n.dir}`];
                  s && s(n);
                }
              } else i.onTap && i.onTap({ event: e });
              return (
                i.onTouchEndOrOnMouseUp &&
                  i.onTouchEndOrOnMouseUp({ event: e }),
                Object.assign(Object.assign(Object.assign({}, t), Dn), {
                  eventData: n,
                })
              );
            });
          },
          r = (t) => {
            document.removeEventListener(An, n),
              document.removeEventListener(On, r),
              s(t);
          },
          o = (t, e) => {
            let r = () => {};
            if (t && t.addEventListener) {
              const o = Object.assign(
                  Object.assign({}, Tn.touchEventOptions),
                  e.touchEventOptions
                ),
                a = [
                  [Zn, i, o],
                  [
                    Gn,
                    n,
                    Object.assign(
                      Object.assign({}, o),
                      e.preventScrollOnSwipe ? { passive: !1 } : {}
                    ),
                  ],
                  [jn, s, o],
                ];
              a.forEach(([e, i, n]) => t.addEventListener(e, i, n)),
                (r = () => a.forEach(([e, i]) => t.removeEventListener(e, i)));
            }
            return r;
          },
          a = {
            ref: (e) => {
              null !== e &&
                t((t, i) => {
                  if (t.el === e) return t;
                  const n = {};
                  return (
                    t.el &&
                      t.el !== e &&
                      t.cleanUpTouch &&
                      (t.cleanUpTouch(), (n.cleanUpTouch = void 0)),
                    i.trackTouch && e && (n.cleanUpTouch = o(e, i)),
                    Object.assign(
                      Object.assign(Object.assign({}, t), { el: e }),
                      n
                    )
                  );
                });
            },
          };
        return e.trackMouse && (a.onMouseDown = i), [a, o];
      }
      function Nn(t) {
        const { trackMouse: e } = t,
          i = s.useRef(Object.assign({}, Dn)),
          n = s.useRef(Object.assign({}, Tn)),
          r = s.useRef(Object.assign({}, n.current));
        let o;
        for (o in ((r.current = Object.assign({}, n.current)),
        (n.current = Object.assign(Object.assign({}, Tn), t)),
        Tn))
          void 0 === n.current[o] && (n.current[o] = Tn[o]);
        const [a, l] = s.useMemo(
          () =>
            Bn((t) => (i.current = t(i.current, n.current)), { trackMouse: e }),
          [e]
        );
        return (
          (i.current = (function (t, e, i, n) {
            return e.trackTouch && t.el
              ? t.cleanUpTouch
                ? e.preventScrollOnSwipe !== i.preventScrollOnSwipe ||
                  e.touchEventOptions.passive !== i.touchEventOptions.passive
                  ? (t.cleanUpTouch(),
                    Object.assign(Object.assign({}, t), {
                      cleanUpTouch: n(t.el, e),
                    }))
                  : t
                : Object.assign(Object.assign({}, t), {
                    cleanUpTouch: n(t.el, e),
                  })
              : (t.cleanUpTouch && t.cleanUpTouch(),
                Object.assign(Object.assign({}, t), { cleanUpTouch: void 0 }));
          })(i.current, n.current, r.current, l)),
          a
        );
      }
      const Wn = () =>
        n.jsx("div", {
          style: { textAlign: "center", padding: "20px" },
          children: n.jsx("h2", { children: "Loading..." }),
        });
      var Xn = i(33305),
        Yn = i(76971),
        Vn = i(5755),
        qn = i(99207),
        $n = i(7132);
      const Un = ({ stroke: t, type: e, lineDash: i, image: s }) => {
          if ("point" === e) {
            const t = `rgba(${s.r}, ${s.g}, ${s.b}, 1)`,
              e = s.radius;
            return n.jsx("svg", {
              width: "20",
              height: "20",
              viewBox: "0 0 20 20",
              children: n.jsx("circle", { cx: "10", cy: "10", r: e, fill: t }),
            });
          }
          if (!t) return null;
          const r = `rgba(${t.r}, ${t.g}, ${t.b}, ${t.a})`,
            o = {
              fill: "polygon" === e ? r : "none",
              stroke: "polygon" === e ? "rgba(53,53,53,1)" : r,
              strokeWidth: t.width || 2,
              strokeOpacity: t.opacity || 1,
              strokeDasharray: i ? "4,4" : "none",
            };
          switch (e) {
            case "line":
              return n.jsx("svg", {
                width: "30",
                height: "30",
                viewBox: "0 0 30 30",
                children: n.jsx("line", {
                  x1: "0",
                  y1: "15",
                  x2: "30",
                  y2: "15",
                  style: o,
                }),
              });
            case "polygon":
              return n.jsx("svg", {
                width: "25",
                height: "25",
                viewBox: "0 0 30 30",
                children: n.jsx("rect", {
                  x: "5",
                  y: "5",
                  width: "20",
                  height: "20",
                  style: o,
                }),
              });
            case "dash-square":
              return n.jsx("svg", {
                width: "30",
                height: "30",
                viewBox: "0 0 30 30",
                children: n.jsx("rect", {
                  x: "5",
                  y: "5",
                  width: "20",
                  height: "20",
                  style: { ...o, strokeDasharray: "4,4" },
                }),
              });
            default:
              return null;
          }
        },
        Hn = ({ thematics: t, onLayerClick: e, loadedLayers: i }) => {
          const o = (0, s.useRef)(!1);
          (0, s.useEffect)(() => {
            if (t.length > 0 && !o.current) {
              console.log("First call made"), (o.current = !0);
              for (const i of t)
                for (const t of i.layers) "pc_areas" === t.idLayer && e(t);
            }
          }, [t]);
          const a = (t) => {
            const e = t.type;
            if (!e) throw new Error("Layer type must be defined and valid.");
            return {
              stroke: t.stroke
                ? {
                    r: parseFloat(t.stroke.r),
                    g: parseFloat(t.stroke.g),
                    b: parseFloat(t.stroke.b),
                    a: parseFloat(t.stroke.a),
                    width: t.stroke.width,
                    opacity: t.stroke.opacity,
                  }
                : void 0,
              type: e,
              lineDash: void 0 !== t.lineDash ? t.lineDash > 0 : void 0,
              image: t.image,
            };
          };
          return n.jsx(kn.Z, {
            sx: { padding: 2 },
            children:
              t &&
              t.map((s, o) =>
                (0, n.jsxs)(
                  kn.Z,
                  {
                    sx: { marginBottom: 1 },
                    children: [
                      s.nom.length > 0 &&
                        (0, n.jsxs)(kn.Z, {
                          sx: {
                            display: "flex",
                            flexDirection: "row",
                            alignItems: "center",
                          },
                          children: [
                            n.jsx(Yn.Z, {
                              checked: !1,
                              sx: {
                                padding: 0,
                                color: "grey",
                                "&.Mui-checked": {
                                  color: $n.Z.palette.primary.main,
                                },
                              },
                              disableRipple: !0,
                            }),
                            (0, n.jsxs)(kn.Z, {
                              sx: { display: "flex", alignItems: "center" },
                              children: [
                                n.jsx(kn.Z, {
                                  sx: { marginRight: "5px", marginLeft: "5px" },
                                  children: Un(a(s.layers[0])),
                                }),
                                n.jsx(In.Z, {
                                  variant: "body1",
                                  children: s.nom,
                                }),
                              ],
                            }),
                          ],
                        }),
                      s.layers.map((t) => {
                        const o = i.some((e) => e.idLayer === t.idLayer);
                        return n.jsx(
                          r().Fragment,
                          {
                            children: (0, n.jsxs)(kn.Z, {
                              sx: {
                                display: "flex",
                                alignItems: "center",
                                marginTop: s.nom.length > 0 ? 1 : 0,
                                cursor: "pointer",
                                paddingLeft: s.nom.length > 0 ? 2 : 0,
                                borderRadius: 1,
                                "&:hover": { backgroundColor: Vn.Z[200] },
                              },
                              onClick: () => e(t),
                              children: [
                                n.jsx(Yn.Z, {
                                  checked: o,
                                  sx: {
                                    padding: 0,
                                    color: "grey",
                                    "&.Mui-checked": {
                                      color: $n.Z.palette.primary.main,
                                    },
                                  },
                                  disableRipple: !0,
                                }),
                                (0, n.jsxs)(kn.Z, {
                                  sx: { display: "flex", alignItems: "center" },
                                  children: [
                                    n.jsx(kn.Z, {
                                      sx: {
                                        marginRight: "5px",
                                        marginLeft: "5px",
                                      },
                                      children: Un(a(t)),
                                    }),
                                    n.jsx(In.Z, {
                                      variant: "body2",
                                      children: t.name,
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          },
                          t.idLayer
                        );
                      }),
                      o < t.length - 1 && n.jsx(qn.Z, { sx: { marginY: 1.2 } }),
                    ],
                  },
                  s.nom + s.layers.length + o
                )
              ),
          });
        },
        Kn = r().memo(Hn);
      class Jn extends Pi {
        constructor(t, e, i) {
          super(),
            void 0 !== i && void 0 === e
              ? this.setFlatCoordinates(i, t)
              : ((e = e || 0), this.setCenterAndRadius(t, e, i));
        }
        clone() {
          const t = new Jn(this.flatCoordinates.slice(), void 0, this.layout);
          return t.applyProperties(this), t;
        }
        closestPointXY(t, e, i, n) {
          const s = this.flatCoordinates,
            r = t - s[0],
            o = e - s[1],
            a = r * r + o * o;
          if (a < n) {
            if (0 === a) for (let t = 0; t < this.stride; ++t) i[t] = s[t];
            else {
              const t = this.getRadius() / Math.sqrt(a);
              (i[0] = s[0] + t * r), (i[1] = s[1] + t * o);
              for (let e = 2; e < this.stride; ++e) i[e] = s[e];
            }
            return (i.length = this.stride), a;
          }
          return n;
        }
        containsXY(t, e) {
          const i = this.flatCoordinates,
            n = t - i[0],
            s = e - i[1];
          return n * n + s * s <= this.getRadiusSquared_();
        }
        getCenter() {
          return this.flatCoordinates.slice(0, this.stride);
        }
        computeExtent(t) {
          const e = this.flatCoordinates,
            i = e[this.stride] - e[0];
          return ft(e[0] - i, e[1] - i, e[0] + i, e[1] + i, t);
        }
        getRadius() {
          return Math.sqrt(this.getRadiusSquared_());
        }
        getRadiusSquared_() {
          const t = this.flatCoordinates[this.stride] - this.flatCoordinates[0],
            e = this.flatCoordinates[this.stride + 1] - this.flatCoordinates[1];
          return t * t + e * e;
        }
        getType() {
          return "Circle";
        }
        intersectsExtent(t) {
          if (Lt(t, this.getExtent())) {
            const e = this.getCenter();
            return (
              (t[0] <= e[0] && t[2] >= e[0]) ||
              (t[1] <= e[1] && t[3] >= e[1]) ||
              Ct(t, this.intersectsCoordinate.bind(this))
            );
          }
          return !1;
        }
        setCenter(t) {
          const e = this.stride,
            i = this.flatCoordinates[e] - this.flatCoordinates[0],
            n = t.slice();
          n[e] = n[0] + i;
          for (let s = 1; s < e; ++s) n[e + s] = t[s];
          this.setFlatCoordinates(this.layout, n), this.changed();
        }
        setCenterAndRadius(t, e, i) {
          this.setLayout(i, t, 0),
            this.flatCoordinates || (this.flatCoordinates = []);
          const n = this.flatCoordinates;
          let s = Fi(n, 0, t, this.stride);
          n[s++] = n[0] + e;
          for (let r = 1, o = this.stride; r < o; ++r) n[s++] = n[r];
          (n.length = s), this.changed();
        }
        getCoordinates() {
          return null;
        }
        setCoordinates(t, e) {}
        setRadius(t) {
          (this.flatCoordinates[this.stride] = this.flatCoordinates[0] + t),
            this.changed();
        }
        rotate(t, e) {
          const i = this.getCenter(),
            n = this.getStride();
          this.setCenter(ri(i, 0, i.length, n, t, e, i)), this.changed();
        }
      }
      Jn.prototype.transform;
      const Qn = Jn,
        ts = "active";
      const es = class extends o {
        constructor(t, e, i) {
          super(t), (this.map = e), (this.frameState = void 0 !== i ? i : null);
        }
      };
      const is = class extends es {
          constructor(t, e, i, n, s, r) {
            super(t, e, s),
              (this.originalEvent = i),
              (this.pixel_ = null),
              (this.coordinate_ = null),
              (this.dragging = void 0 !== n && n),
              (this.activePointers = r);
          }
          get pixel() {
            return (
              this.pixel_ ||
                (this.pixel_ = this.map.getEventPixel(this.originalEvent)),
              this.pixel_
            );
          }
          set pixel(t) {
            this.pixel_ = t;
          }
          get coordinate() {
            return (
              this.coordinate_ ||
                (this.coordinate_ = this.map.getCoordinateFromPixel(
                  this.pixel
                )),
              this.coordinate_
            );
          }
          set coordinate(t) {
            this.coordinate_ = t;
          }
          preventDefault() {
            super.preventDefault(),
              "preventDefault" in this.originalEvent &&
                this.originalEvent.preventDefault();
          }
          stopPropagation() {
            super.stopPropagation(),
              "stopPropagation" in this.originalEvent &&
                this.originalEvent.stopPropagation();
          }
        },
        ns = "singleclick",
        ss = C,
        rs = "pointerdrag",
        os = "pointermove",
        as = "pointerdown",
        ls = "pointerup";
      const hs = class extends T {
        constructor(t) {
          super(),
            this.on,
            this.once,
            this.un,
            t && t.handleEvent && (this.handleEvent = t.handleEvent),
            (this.map_ = null),
            this.setActive(!0);
        }
        getActive() {
          return this.get(ts);
        }
        getMap() {
          return this.map_;
        }
        handleEvent(t) {
          return !0;
        }
        setActive(t) {
          this.set(ts, t);
        }
        setMap(t) {
          this.map_ = t;
        }
      };
      const cs = class extends hs {
          constructor(t) {
            super((t = t || {})),
              t.handleDownEvent && (this.handleDownEvent = t.handleDownEvent),
              t.handleDragEvent && (this.handleDragEvent = t.handleDragEvent),
              t.handleMoveEvent && (this.handleMoveEvent = t.handleMoveEvent),
              t.handleUpEvent && (this.handleUpEvent = t.handleUpEvent),
              t.stopDown && (this.stopDown = t.stopDown),
              (this.handlingDownUpSequence = !1),
              (this.targetPointers = []);
          }
          getPointerCount() {
            return this.targetPointers.length;
          }
          handleDownEvent(t) {
            return !1;
          }
          handleDragEvent(t) {}
          handleEvent(t) {
            if (!t.originalEvent) return !0;
            let e = !1;
            if ((this.updateTrackedPointers_(t), this.handlingDownUpSequence)) {
              if (t.type == rs)
                this.handleDragEvent(t), t.originalEvent.preventDefault();
              else if (t.type == ls) {
                const e = this.handleUpEvent(t);
                this.handlingDownUpSequence =
                  e && this.targetPointers.length > 0;
              }
            } else if (t.type == as) {
              const i = this.handleDownEvent(t);
              (this.handlingDownUpSequence = i), (e = this.stopDown(i));
            } else t.type == os && this.handleMoveEvent(t);
            return !e;
          }
          handleMoveEvent(t) {}
          handleUpEvent(t) {
            return !1;
          }
          stopDown(t) {
            return t;
          }
          updateTrackedPointers_(t) {
            t.activePointers && (this.targetPointers = t.activePointers);
          }
        },
        us = "opacity",
        ds = "visible",
        gs = "extent",
        fs = "zIndex",
        ps = "maxResolution",
        ms = "minResolution",
        _s = "maxZoom",
        ys = "minZoom",
        xs = "source",
        vs = "map";
      const ws = class extends T {
          constructor(t) {
            super(),
              this.on,
              this.once,
              this.un,
              (this.background_ = t.background);
            const e = Object.assign({}, t);
            "object" === typeof t.properties &&
              (delete e.properties, Object.assign(e, t.properties)),
              (e[us] = void 0 !== t.opacity ? t.opacity : 1),
              D("number" === typeof e[us], "Layer opacity must be a number"),
              (e[ds] = void 0 === t.visible || t.visible),
              (e[fs] = t.zIndex),
              (e[ps] = void 0 !== t.maxResolution ? t.maxResolution : 1 / 0),
              (e[ms] = void 0 !== t.minResolution ? t.minResolution : 0),
              (e[ys] = void 0 !== t.minZoom ? t.minZoom : -1 / 0),
              (e[_s] = void 0 !== t.maxZoom ? t.maxZoom : 1 / 0),
              (this.className_ =
                void 0 !== e.className ? e.className : "ol-layer"),
              delete e.className,
              this.setProperties(e),
              (this.state_ = null);
          }
          getBackground() {
            return this.background_;
          }
          getClassName() {
            return this.className_;
          }
          getLayerState(t) {
            const e = this.state_ || {
                layer: this,
                managed: void 0 === t || t,
              },
              i = this.getZIndex();
            return (
              (e.opacity = Nt(Math.round(100 * this.getOpacity()) / 100, 0, 1)),
              (e.visible = this.getVisible()),
              (e.extent = this.getExtent()),
              (e.zIndex = void 0 !== i || e.managed ? i : 1 / 0),
              (e.maxResolution = this.getMaxResolution()),
              (e.minResolution = Math.max(this.getMinResolution(), 0)),
              (e.minZoom = this.getMinZoom()),
              (e.maxZoom = this.getMaxZoom()),
              (this.state_ = e),
              e
            );
          }
          getLayersArray(t) {
            return R();
          }
          getLayerStatesArray(t) {
            return R();
          }
          getExtent() {
            return this.get(gs);
          }
          getMaxResolution() {
            return this.get(ps);
          }
          getMinResolution() {
            return this.get(ms);
          }
          getMinZoom() {
            return this.get(ys);
          }
          getMaxZoom() {
            return this.get(_s);
          }
          getOpacity() {
            return this.get(us);
          }
          getSourceState() {
            return R();
          }
          getVisible() {
            return this.get(ds);
          }
          getZIndex() {
            return this.get(fs);
          }
          setBackground(t) {
            (this.background_ = t), this.changed();
          }
          setExtent(t) {
            this.set(gs, t);
          }
          setMaxResolution(t) {
            this.set(ps, t);
          }
          setMinResolution(t) {
            this.set(ms, t);
          }
          setMaxZoom(t) {
            this.set(_s, t);
          }
          setMinZoom(t) {
            this.set(ys, t);
          }
          setOpacity(t) {
            D("number" === typeof t, "Layer opacity must be a number"),
              this.set(us, t);
          }
          setVisible(t) {
            this.set(ds, t);
          }
          setZIndex(t) {
            this.set(fs, t);
          }
          disposeInternal() {
            this.state_ && ((this.state_.layer = null), (this.state_ = null)),
              super.disposeInternal();
          }
        },
        Ss = "prerender",
        Cs = "postrender",
        bs = "precompose",
        ks = 0,
        Ms = 1,
        Is = {
          CENTER: "center",
          RESOLUTION: "resolution",
          ROTATION: "rotation",
        };
      function Es(t, e, i) {
        return function (n, s, r, o, a) {
          if (!n) return;
          if (!s && !e) return n;
          const l = e ? 0 : r[0] * s,
            h = e ? 0 : r[1] * s,
            c = a ? a[0] : 0,
            u = a ? a[1] : 0;
          let d = t[0] + l / 2 + c,
            g = t[2] - l / 2 + c,
            f = t[1] + h / 2 + u,
            p = t[3] - h / 2 + u;
          d > g && ((d = (g + d) / 2), (g = d)),
            f > p && ((f = (p + f) / 2), (p = f));
          let m = Nt(n[0], d, g),
            _ = Nt(n[1], f, p);
          if (o && i && s) {
            const t = 30 * s;
            (m +=
              -t * Math.log(1 + Math.max(0, d - n[0]) / t) +
              t * Math.log(1 + Math.max(0, n[0] - g) / t)),
              (_ +=
                -t * Math.log(1 + Math.max(0, f - n[1]) / t) +
                t * Math.log(1 + Math.max(0, n[1] - p) / t));
          }
          return [m, _];
        };
      }
      function Rs(t) {
        return t;
      }
      function Ps(t, e, i, n) {
        const s = Ft(e) / i[0],
          r = Et(e) / i[1];
        return n ? Math.min(t, Math.max(s, r)) : Math.min(t, Math.min(s, r));
      }
      function Fs(t, e, i) {
        let n = Math.min(t, e);
        return (
          (n *= Math.log(1 + 50 * Math.max(0, t / e - 1)) / 50 + 1),
          i &&
            ((n = Math.max(n, i)),
            (n /= Math.log(1 + 50 * Math.max(0, i / t - 1)) / 50 + 1)),
          Nt(n, i / 2, 2 * e)
        );
      }
      function Ls(t, e, i, n, s) {
        return (
          (i = void 0 === i || i),
          function (r, o, a, l) {
            if (void 0 !== r) {
              const o = n ? Ps(t, n, a, s) : t;
              return i && l ? Fs(r, o, e) : Nt(r, e, o);
            }
          }
        );
      }
      function Ts(t) {
        if (void 0 !== t) return 0;
      }
      function Ds(t) {
        if (void 0 !== t) return t;
      }
      function As(t) {
        return (
          1 -
          (function (t) {
            return Math.pow(t, 3);
          })(1 - t)
        );
      }
      function Os(t) {
        return 3 * t * t - 2 * t * t * t;
      }
      function js(t, e) {
        setTimeout(function () {
          t(e);
        }, 0);
      }
      function Gs(t) {
        return (
          !(
            t.sourceCenter &&
            t.targetCenter &&
            !be(t.sourceCenter, t.targetCenter)
          ) &&
          t.sourceResolution === t.targetResolution &&
          t.sourceRotation === t.targetRotation
        );
      }
      function Zs(t, e, i, n, s) {
        const r = Math.cos(-s);
        let o = Math.sin(-s),
          a = t[0] * r - t[1] * o,
          l = t[1] * r + t[0] * o;
        (a += (e[0] / 2 - i[0]) * n), (l += (i[1] - e[1] / 2) * n), (o = -o);
        return [a * r - l * o, l * r + a * o];
      }
      const zs = class extends T {
        constructor(t) {
          super(),
            this.on,
            this.once,
            this.un,
            (t = Object.assign({}, t)),
            (this.hints_ = [0, 0]),
            (this.animations_ = []),
            this.updateAnimationKey_,
            (this.projection_ = je(t.projection, "EPSG:3857")),
            (this.viewportSize_ = [100, 100]),
            (this.targetCenter_ = null),
            this.targetResolution_,
            this.targetRotation_,
            (this.nextCenter_ = null),
            this.nextResolution_,
            this.nextRotation_,
            (this.cancelAnchor_ = void 0),
            t.projection && Fe(),
            t.center && (t.center = Ye(t.center, this.projection_)),
            t.extent && (t.extent = qe(t.extent, this.projection_)),
            this.applyOptions_(t);
        }
        applyOptions_(t) {
          const e = Object.assign({}, t);
          for (const o in Is) delete e[o];
          this.setProperties(e, !0);
          const i = (function (t) {
            let e, i, n;
            const s = 28,
              r = 2;
            let o = void 0 !== t.minZoom ? t.minZoom : 0,
              a = void 0 !== t.maxZoom ? t.maxZoom : s;
            const l = void 0 !== t.zoomFactor ? t.zoomFactor : r,
              h = void 0 !== t.multiWorld && t.multiWorld,
              u =
                void 0 === t.smoothResolutionConstraint ||
                t.smoothResolutionConstraint,
              d = void 0 !== t.showFullExtent && t.showFullExtent,
              g = je(t.projection, "EPSG:3857"),
              f = g.getExtent();
            let p = t.constrainOnlyCenter,
              m = t.extent;
            h || m || !g.isGlobal() || ((p = !1), (m = f));
            if (void 0 !== t.resolutions) {
              const s = t.resolutions;
              (i = s[o]),
                (n = void 0 !== s[a] ? s[a] : s[s.length - 1]),
                (e = t.constrainResolution
                  ? (function (t, e, i, n) {
                      return (
                        (e = void 0 === e || e),
                        function (s, r, o, a) {
                          if (void 0 !== s) {
                            const l = t[0],
                              h = t[t.length - 1],
                              u = i ? Ps(l, i, o, n) : l;
                            if (a) return e ? Fs(s, u, h) : Nt(s, h, u);
                            const d = Math.min(u, s),
                              g = Math.floor(c(t, d, r));
                            return t[g] > u && g < t.length - 1
                              ? t[g + 1]
                              : t[g];
                          }
                        }
                      );
                    })(s, u, !p && m, d)
                  : Ls(i, n, u, !p && m, d));
            } else {
              const h =
                  (f
                    ? Math.max(Ft(f), Et(f))
                    : (360 * re.degrees) / g.getMetersPerUnit()) /
                  256 /
                  Math.pow(r, 0),
                c = h / Math.pow(r, s - 0);
              (i = t.maxResolution),
                void 0 !== i ? (o = 0) : (i = h / Math.pow(l, o)),
                (n = t.minResolution),
                void 0 === n &&
                  (n =
                    void 0 !== t.maxZoom
                      ? void 0 !== t.maxResolution
                        ? i / Math.pow(l, a)
                        : h / Math.pow(l, a)
                      : c),
                (a = o + Math.floor(Math.log(i / n) / Math.log(l))),
                (n = i / Math.pow(l, a - o)),
                (e = t.constrainResolution
                  ? (function (t, e, i, n, s, r) {
                      return (
                        (n = void 0 === n || n),
                        (i = void 0 !== i ? i : 0),
                        function (o, a, l, h) {
                          if (void 0 !== o) {
                            const c = s ? Ps(e, s, l, r) : e;
                            if (h) return n ? Fs(o, c, i) : Nt(o, i, c);
                            const u = 1e-9,
                              d = Math.ceil(Math.log(e / c) / Math.log(t) - u),
                              g = -a * (0.5 - u) + 0.5,
                              f = Math.min(c, o),
                              p = Math.floor(Math.log(e / f) / Math.log(t) + g),
                              m = Math.max(d, p);
                            return Nt(e / Math.pow(t, m), i, c);
                          }
                        }
                      );
                    })(l, i, n, u, !p && m, d)
                  : Ls(i, n, u, !p && m, d));
            }
            return {
              constraint: e,
              maxResolution: i,
              minResolution: n,
              minZoom: o,
              zoomFactor: l,
            };
          })(t);
          (this.maxResolution_ = i.maxResolution),
            (this.minResolution_ = i.minResolution),
            (this.zoomFactor_ = i.zoomFactor),
            (this.resolutions_ = t.resolutions),
            (this.padding_ = t.padding),
            (this.minZoom_ = i.minZoom);
          const n = (function (t) {
              if (void 0 !== t.extent) {
                const e =
                  void 0 === t.smoothExtentConstraint ||
                  t.smoothExtentConstraint;
                return Es(t.extent, t.constrainOnlyCenter, e);
              }
              const e = je(t.projection, "EPSG:3857");
              if (!0 !== t.multiWorld && e.isGlobal()) {
                const t = e.getExtent().slice();
                return (t[0] = -1 / 0), (t[2] = 1 / 0), Es(t, !1, !1);
              }
              return Rs;
            })(t),
            s = i.constraint,
            r = (function (t) {
              const e = void 0 === t.enableRotation || t.enableRotation;
              if (e) {
                const e = t.constrainRotation;
                return void 0 === e || !0 === e
                  ? (function (t) {
                      const e = void 0 === t ? Yt(5) : t;
                      return function (t, i) {
                        return i || void 0 === t ? t : Math.abs(t) <= e ? 0 : t;
                      };
                    })()
                  : !1 === e
                  ? Ds
                  : "number" === typeof e
                  ? (function (t) {
                      const e = (2 * Math.PI) / t;
                      return function (t, i) {
                        return i
                          ? t
                          : void 0 !== t
                          ? (t = Math.floor(t / e + 0.5) * e)
                          : void 0;
                      };
                    })(e)
                  : Ds;
              }
              return Ts;
            })(t);
          (this.constraints_ = { center: n, resolution: s, rotation: r }),
            this.setRotation(void 0 !== t.rotation ? t.rotation : 0),
            this.setCenterInternal(void 0 !== t.center ? t.center : null),
            void 0 !== t.resolution
              ? this.setResolution(t.resolution)
              : void 0 !== t.zoom && this.setZoom(t.zoom);
        }
        get padding() {
          return this.padding_;
        }
        set padding(t) {
          let e = this.padding_;
          this.padding_ = t;
          const i = this.getCenterInternal();
          if (i) {
            const n = t || [0, 0, 0, 0];
            e = e || [0, 0, 0, 0];
            const s = this.getResolution(),
              r = (s / 2) * (n[3] - e[3] + e[1] - n[1]),
              o = (s / 2) * (n[0] - e[0] + e[2] - n[2]);
            this.setCenterInternal([i[0] + r, i[1] - o]);
          }
        }
        getUpdatedOptions_(t) {
          const e = this.getProperties();
          return (
            void 0 !== e.resolution
              ? (e.resolution = this.getResolution())
              : (e.zoom = this.getZoom()),
            (e.center = this.getCenterInternal()),
            (e.rotation = this.getRotation()),
            Object.assign({}, e, t)
          );
        }
        animate(t) {
          this.isDef() && !this.getAnimating() && this.resolveConstraints(0);
          const e = new Array(arguments.length);
          for (let i = 0; i < e.length; ++i) {
            let t = arguments[i];
            t.center &&
              ((t = Object.assign({}, t)),
              (t.center = Ye(t.center, this.getProjection()))),
              t.anchor &&
                ((t = Object.assign({}, t)),
                (t.anchor = Ye(t.anchor, this.getProjection()))),
              (e[i] = t);
          }
          this.animateInternal.apply(this, e);
        }
        animateInternal(t) {
          let e,
            i = arguments.length;
          i > 1 &&
            "function" === typeof arguments[i - 1] &&
            ((e = arguments[i - 1]), --i);
          let n = 0;
          for (; n < i && !this.isDef(); ++n) {
            const t = arguments[n];
            t.center && this.setCenterInternal(t.center),
              void 0 !== t.zoom
                ? this.setZoom(t.zoom)
                : t.resolution && this.setResolution(t.resolution),
              void 0 !== t.rotation && this.setRotation(t.rotation);
          }
          if (n === i) return void (e && js(e, !0));
          let s = Date.now(),
            r = this.targetCenter_.slice(),
            o = this.targetResolution_,
            a = this.targetRotation_;
          const l = [];
          for (; n < i; ++n) {
            const t = arguments[n],
              i = {
                start: s,
                complete: !1,
                anchor: t.anchor,
                duration: void 0 !== t.duration ? t.duration : 1e3,
                easing: t.easing || Os,
                callback: e,
              };
            if (
              (t.center &&
                ((i.sourceCenter = r),
                (i.targetCenter = t.center.slice()),
                (r = i.targetCenter)),
              void 0 !== t.zoom
                ? ((i.sourceResolution = o),
                  (i.targetResolution = this.getResolutionForZoom(t.zoom)),
                  (o = i.targetResolution))
                : t.resolution &&
                  ((i.sourceResolution = o),
                  (i.targetResolution = t.resolution),
                  (o = i.targetResolution)),
              void 0 !== t.rotation)
            ) {
              i.sourceRotation = a;
              const e = Vt(t.rotation - a + Math.PI, 2 * Math.PI) - Math.PI;
              (i.targetRotation = a + e), (a = i.targetRotation);
            }
            Gs(i) ? (i.complete = !0) : (s += i.duration), l.push(i);
          }
          this.animations_.push(l),
            this.setHint(ks, 1),
            this.updateAnimations_();
        }
        getAnimating() {
          return this.hints_[ks] > 0;
        }
        getInteracting() {
          return this.hints_[Ms] > 0;
        }
        cancelAnimations() {
          let t;
          this.setHint(ks, -this.hints_[ks]);
          for (let e = 0, i = this.animations_.length; e < i; ++e) {
            const i = this.animations_[e];
            if ((i[0].callback && js(i[0].callback, !1), !t))
              for (let e = 0, n = i.length; e < n; ++e) {
                const n = i[e];
                if (!n.complete) {
                  t = n.anchor;
                  break;
                }
              }
          }
          (this.animations_.length = 0),
            (this.cancelAnchor_ = t),
            (this.nextCenter_ = null),
            (this.nextResolution_ = NaN),
            (this.nextRotation_ = NaN);
        }
        updateAnimations_() {
          if (
            (void 0 !== this.updateAnimationKey_ &&
              (cancelAnimationFrame(this.updateAnimationKey_),
              (this.updateAnimationKey_ = void 0)),
            !this.getAnimating())
          )
            return;
          const t = Date.now();
          let e = !1;
          for (let i = this.animations_.length - 1; i >= 0; --i) {
            const n = this.animations_[i];
            let s = !0;
            for (let i = 0, r = n.length; i < r; ++i) {
              const r = n[i];
              if (r.complete) continue;
              const o = t - r.start;
              let a = r.duration > 0 ? o / r.duration : 1;
              a >= 1 ? ((r.complete = !0), (a = 1)) : (s = !1);
              const l = r.easing(a);
              if (r.sourceCenter) {
                const t = r.sourceCenter[0],
                  e = r.sourceCenter[1],
                  i = r.targetCenter[0],
                  n = r.targetCenter[1];
                this.nextCenter_ = r.targetCenter;
                const s = t + l * (i - t),
                  o = e + l * (n - e);
                this.targetCenter_ = [s, o];
              }
              if (r.sourceResolution && r.targetResolution) {
                const t =
                  1 === l
                    ? r.targetResolution
                    : r.sourceResolution +
                      l * (r.targetResolution - r.sourceResolution);
                if (r.anchor) {
                  const e = this.getViewportSize_(this.getRotation()),
                    i = this.constraints_.resolution(t, 0, e, !0);
                  this.targetCenter_ = this.calculateCenterZoom(i, r.anchor);
                }
                (this.nextResolution_ = r.targetResolution),
                  (this.targetResolution_ = t),
                  this.applyTargetState_(!0);
              }
              if (void 0 !== r.sourceRotation && void 0 !== r.targetRotation) {
                const t =
                  1 === l
                    ? Vt(r.targetRotation + Math.PI, 2 * Math.PI) - Math.PI
                    : r.sourceRotation +
                      l * (r.targetRotation - r.sourceRotation);
                if (r.anchor) {
                  const e = this.constraints_.rotation(t, !0);
                  this.targetCenter_ = this.calculateCenterRotate(e, r.anchor);
                }
                (this.nextRotation_ = r.targetRotation),
                  (this.targetRotation_ = t);
              }
              if ((this.applyTargetState_(!0), (e = !0), !r.complete)) break;
            }
            if (s) {
              (this.animations_[i] = null),
                this.setHint(ks, -1),
                (this.nextCenter_ = null),
                (this.nextResolution_ = NaN),
                (this.nextRotation_ = NaN);
              const t = n[0].callback;
              t && js(t, !0);
            }
          }
          (this.animations_ = this.animations_.filter(Boolean)),
            e &&
              void 0 === this.updateAnimationKey_ &&
              (this.updateAnimationKey_ = requestAnimationFrame(
                this.updateAnimations_.bind(this)
              ));
        }
        calculateCenterRotate(t, e) {
          let i;
          const n = this.getCenterInternal();
          var s, r;
          return (
            void 0 !== n &&
              ((i = [n[0] - e[0], n[1] - e[1]]),
              (function (t, e) {
                const i = Math.cos(e),
                  n = Math.sin(e),
                  s = t[0] * i - t[1] * n,
                  r = t[1] * i + t[0] * n;
                (t[0] = s), (t[1] = r);
              })(i, t - this.getRotation()),
              (r = e),
              ((s = i)[0] += +r[0]),
              (s[1] += +r[1])),
            i
          );
        }
        calculateCenterZoom(t, e) {
          let i;
          const n = this.getCenterInternal(),
            s = this.getResolution();
          if (void 0 !== n && void 0 !== s) {
            i = [
              e[0] - (t * (e[0] - n[0])) / s,
              e[1] - (t * (e[1] - n[1])) / s,
            ];
          }
          return i;
        }
        getViewportSize_(t) {
          const e = this.viewportSize_;
          if (t) {
            const i = e[0],
              n = e[1];
            return [
              Math.abs(i * Math.cos(t)) + Math.abs(n * Math.sin(t)),
              Math.abs(i * Math.sin(t)) + Math.abs(n * Math.cos(t)),
            ];
          }
          return e;
        }
        setViewportSize(t) {
          (this.viewportSize_ = Array.isArray(t) ? t.slice() : [100, 100]),
            this.getAnimating() || this.resolveConstraints(0);
        }
        getCenter() {
          const t = this.getCenterInternal();
          return t ? Xe(t, this.getProjection()) : t;
        }
        getCenterInternal() {
          return this.get(Is.CENTER);
        }
        getConstraints() {
          return this.constraints_;
        }
        getConstrainResolution() {
          return this.get("constrainResolution");
        }
        getHints(t) {
          return void 0 !== t
            ? ((t[0] = this.hints_[0]), (t[1] = this.hints_[1]), t)
            : this.hints_.slice();
        }
        calculateExtent(t) {
          return Ve(this.calculateExtentInternal(t), this.getProjection());
        }
        calculateExtentInternal(t) {
          t = t || this.getViewportSizeMinusPadding_();
          const e = this.getCenterInternal();
          D(e, "The view center is not defined");
          const i = this.getResolution();
          D(void 0 !== i, "The view resolution is not defined");
          const n = this.getRotation();
          return (
            D(void 0 !== n, "The view rotation is not defined"), It(e, i, n, t)
          );
        }
        getMaxResolution() {
          return this.maxResolution_;
        }
        getMinResolution() {
          return this.minResolution_;
        }
        getMaxZoom() {
          return this.getZoomForResolution(this.minResolution_);
        }
        setMaxZoom(t) {
          this.applyOptions_(this.getUpdatedOptions_({ maxZoom: t }));
        }
        getMinZoom() {
          return this.getZoomForResolution(this.maxResolution_);
        }
        setMinZoom(t) {
          this.applyOptions_(this.getUpdatedOptions_({ minZoom: t }));
        }
        setConstrainResolution(t) {
          this.applyOptions_(
            this.getUpdatedOptions_({ constrainResolution: t })
          );
        }
        getProjection() {
          return this.projection_;
        }
        getResolution() {
          return this.get(Is.RESOLUTION);
        }
        getResolutions() {
          return this.resolutions_;
        }
        getResolutionForExtent(t, e) {
          return this.getResolutionForExtentInternal(
            qe(t, this.getProjection()),
            e
          );
        }
        getResolutionForExtentInternal(t, e) {
          e = e || this.getViewportSizeMinusPadding_();
          const i = Ft(t) / e[0],
            n = Et(t) / e[1];
          return Math.max(i, n);
        }
        getResolutionForValueFunction(t) {
          t = t || 2;
          const e = this.getConstrainedResolution(this.maxResolution_),
            i = this.minResolution_,
            n = Math.log(e / i) / Math.log(t);
          return function (i) {
            return e / Math.pow(t, i * n);
          };
        }
        getRotation() {
          return this.get(Is.ROTATION);
        }
        getValueForResolutionFunction(t) {
          const e = Math.log(t || 2),
            i = this.getConstrainedResolution(this.maxResolution_),
            n = this.minResolution_,
            s = Math.log(i / n) / e;
          return function (t) {
            return Math.log(i / t) / e / s;
          };
        }
        getViewportSizeMinusPadding_(t) {
          let e = this.getViewportSize_(t);
          const i = this.padding_;
          return i && (e = [e[0] - i[1] - i[3], e[1] - i[0] - i[2]]), e;
        }
        getState() {
          const t = this.getProjection(),
            e = this.getResolution(),
            i = this.getRotation();
          let n = this.getCenterInternal();
          const s = this.padding_;
          if (s) {
            const t = this.getViewportSizeMinusPadding_();
            n = Zs(
              n,
              this.getViewportSize_(),
              [t[0] / 2 + s[3], t[1] / 2 + s[0]],
              e,
              i
            );
          }
          return {
            center: n.slice(0),
            projection: void 0 !== t ? t : null,
            resolution: e,
            nextCenter: this.nextCenter_,
            nextResolution: this.nextResolution_,
            nextRotation: this.nextRotation_,
            rotation: i,
            zoom: this.getZoom(),
          };
        }
        getViewStateAndExtent() {
          return { viewState: this.getState(), extent: this.calculateExtent() };
        }
        getZoom() {
          let t;
          const e = this.getResolution();
          return void 0 !== e && (t = this.getZoomForResolution(e)), t;
        }
        getZoomForResolution(t) {
          let e,
            i,
            n = this.minZoom_ || 0;
          if (this.resolutions_) {
            const s = c(this.resolutions_, t, 1);
            (n = s),
              (e = this.resolutions_[s]),
              (i =
                s == this.resolutions_.length - 1
                  ? 2
                  : e / this.resolutions_[s + 1]);
          } else (e = this.maxResolution_), (i = this.zoomFactor_);
          return n + Math.log(e / t) / Math.log(i);
        }
        getResolutionForZoom(t) {
          if (this.resolutions_?.length) {
            if (1 === this.resolutions_.length) return this.resolutions_[0];
            const e = Nt(Math.floor(t), 0, this.resolutions_.length - 2),
              i = this.resolutions_[e] / this.resolutions_[e + 1];
            return this.resolutions_[e] / Math.pow(i, Nt(t - e, 0, 1));
          }
          return (
            this.maxResolution_ / Math.pow(this.zoomFactor_, t - this.minZoom_)
          );
        }
        fit(t, e) {
          let i;
          if (
            (D(
              Array.isArray(t) || "function" === typeof t.getSimplifiedGeometry,
              "Invalid extent or geometry provided as `geometry`"
            ),
            Array.isArray(t))
          ) {
            D(!Tt(t), "Cannot fit empty extent provided as `geometry`");
            i = sn(qe(t, this.getProjection()));
          } else if ("Circle" === t.getType()) {
            const e = qe(t.getExtent(), this.getProjection());
            (i = sn(e)), i.rotate(this.getRotation(), Mt(e));
          } else {
            const e = We();
            i = e ? t.clone().transform(e, this.getProjection()) : t;
          }
          this.fitInternal(i, e);
        }
        rotatedExtentForGeometry(t) {
          const e = this.getRotation(),
            i = Math.cos(e),
            n = Math.sin(-e),
            s = t.getFlatCoordinates(),
            r = t.getStride();
          let o = 1 / 0,
            a = 1 / 0,
            l = -1 / 0,
            h = -1 / 0;
          for (let c = 0, u = s.length; c < u; c += r) {
            const t = s[c] * i - s[c + 1] * n,
              e = s[c] * n + s[c + 1] * i;
            (o = Math.min(o, t)),
              (a = Math.min(a, e)),
              (l = Math.max(l, t)),
              (h = Math.max(h, e));
          }
          return [o, a, l, h];
        }
        fitInternal(t, e) {
          let i = (e = e || {}).size;
          i || (i = this.getViewportSizeMinusPadding_());
          const n = void 0 !== e.padding ? e.padding : [0, 0, 0, 0],
            s = void 0 !== e.nearest && e.nearest;
          let r;
          r =
            void 0 !== e.minResolution
              ? e.minResolution
              : void 0 !== e.maxZoom
              ? this.getResolutionForZoom(e.maxZoom)
              : 0;
          const o = this.rotatedExtentForGeometry(t);
          let a = this.getResolutionForExtentInternal(o, [
            i[0] - n[1] - n[3],
            i[1] - n[0] - n[2],
          ]);
          (a = isNaN(a) ? r : Math.max(a, r)),
            (a = this.getConstrainedResolution(a, s ? 0 : 1));
          const l = this.getRotation(),
            h = Math.sin(l),
            c = Math.cos(l),
            u = Mt(o);
          (u[0] += ((n[1] - n[3]) / 2) * a), (u[1] += ((n[0] - n[2]) / 2) * a);
          const d = u[0] * c - u[1] * h,
            g = u[1] * c + u[0] * h,
            f = this.getConstrainedCenter([d, g], a),
            p = e.callback ? e.callback : m;
          void 0 !== e.duration
            ? this.animateInternal(
                {
                  resolution: a,
                  center: f,
                  duration: e.duration,
                  easing: e.easing,
                },
                p
              )
            : ((this.targetResolution_ = a),
              (this.targetCenter_ = f),
              this.applyTargetState_(!1, !0),
              js(p, !0));
        }
        centerOn(t, e, i) {
          this.centerOnInternal(Ye(t, this.getProjection()), e, i);
        }
        centerOnInternal(t, e, i) {
          this.setCenterInternal(
            Zs(t, e, i, this.getResolution(), this.getRotation())
          );
        }
        calculateCenterShift(t, e, i, n) {
          let s;
          const r = this.padding_;
          if (r && t) {
            const o = this.getViewportSizeMinusPadding_(-i),
              a = Zs(t, n, [o[0] / 2 + r[3], o[1] / 2 + r[0]], e, i);
            s = [t[0] - a[0], t[1] - a[1]];
          }
          return s;
        }
        isDef() {
          return !!this.getCenterInternal() && void 0 !== this.getResolution();
        }
        adjustCenter(t) {
          const e = Xe(this.targetCenter_, this.getProjection());
          this.setCenter([e[0] + t[0], e[1] + t[1]]);
        }
        adjustCenterInternal(t) {
          const e = this.targetCenter_;
          this.setCenterInternal([e[0] + t[0], e[1] + t[1]]);
        }
        adjustResolution(t, e) {
          (e = e && Ye(e, this.getProjection())),
            this.adjustResolutionInternal(t, e);
        }
        adjustResolutionInternal(t, e) {
          const i = this.getAnimating() || this.getInteracting(),
            n = this.getViewportSize_(this.getRotation()),
            s = this.constraints_.resolution(
              this.targetResolution_ * t,
              0,
              n,
              i
            );
          e && (this.targetCenter_ = this.calculateCenterZoom(s, e)),
            (this.targetResolution_ *= t),
            this.applyTargetState_();
        }
        adjustZoom(t, e) {
          this.adjustResolution(Math.pow(this.zoomFactor_, -t), e);
        }
        adjustRotation(t, e) {
          e && (e = Ye(e, this.getProjection())),
            this.adjustRotationInternal(t, e);
        }
        adjustRotationInternal(t, e) {
          const i = this.getAnimating() || this.getInteracting(),
            n = this.constraints_.rotation(this.targetRotation_ + t, i);
          e && (this.targetCenter_ = this.calculateCenterRotate(n, e)),
            (this.targetRotation_ += t),
            this.applyTargetState_();
        }
        setCenter(t) {
          this.setCenterInternal(t ? Ye(t, this.getProjection()) : t);
        }
        setCenterInternal(t) {
          (this.targetCenter_ = t), this.applyTargetState_();
        }
        setHint(t, e) {
          return (this.hints_[t] += e), this.changed(), this.hints_[t];
        }
        setResolution(t) {
          (this.targetResolution_ = t), this.applyTargetState_();
        }
        setRotation(t) {
          (this.targetRotation_ = t), this.applyTargetState_();
        }
        setZoom(t) {
          this.setResolution(this.getResolutionForZoom(t));
        }
        applyTargetState_(t, e) {
          const i = this.getAnimating() || this.getInteracting() || e,
            n = this.constraints_.rotation(this.targetRotation_, i),
            s = this.getViewportSize_(n),
            r = this.constraints_.resolution(this.targetResolution_, 0, s, i),
            o = this.constraints_.center(
              this.targetCenter_,
              r,
              s,
              i,
              this.calculateCenterShift(this.targetCenter_, r, n, s)
            );
          this.get(Is.ROTATION) !== n && this.set(Is.ROTATION, n),
            this.get(Is.RESOLUTION) !== r &&
              (this.set(Is.RESOLUTION, r),
              this.set("zoom", this.getZoom(), !0)),
            (o && this.get(Is.CENTER) && be(this.get(Is.CENTER), o)) ||
              this.set(Is.CENTER, o),
            this.getAnimating() && !t && this.cancelAnimations(),
            (this.cancelAnchor_ = void 0);
        }
        resolveConstraints(t, e, i) {
          t = void 0 !== t ? t : 200;
          const n = e || 0,
            s = this.constraints_.rotation(this.targetRotation_),
            r = this.getViewportSize_(s),
            o = this.constraints_.resolution(this.targetResolution_, n, r),
            a = this.constraints_.center(
              this.targetCenter_,
              o,
              r,
              !1,
              this.calculateCenterShift(this.targetCenter_, o, s, r)
            );
          if (0 === t && !this.cancelAnchor_)
            return (
              (this.targetResolution_ = o),
              (this.targetRotation_ = s),
              (this.targetCenter_ = a),
              void this.applyTargetState_()
            );
          (i = i || (0 === t ? this.cancelAnchor_ : void 0)),
            (this.cancelAnchor_ = void 0),
            (this.getResolution() === o &&
              this.getRotation() === s &&
              this.getCenterInternal() &&
              be(this.getCenterInternal(), a)) ||
              (this.getAnimating() && this.cancelAnimations(),
              this.animateInternal({
                rotation: s,
                center: a,
                resolution: o,
                duration: t,
                easing: As,
                anchor: i,
              }));
        }
        beginInteraction() {
          this.resolveConstraints(0), this.setHint(Ms, 1);
        }
        endInteraction(t, e, i) {
          (i = i && Ye(i, this.getProjection())),
            this.endInteractionInternal(t, e, i);
        }
        endInteractionInternal(t, e, i) {
          this.getInteracting() &&
            (this.setHint(Ms, -1), this.resolveConstraints(t, e, i));
        }
        getConstrainedCenter(t, e) {
          const i = this.getViewportSize_(this.getRotation());
          return this.constraints_.center(t, e || this.getResolution(), i);
        }
        getConstrainedZoom(t, e) {
          const i = this.getResolutionForZoom(t);
          return this.getZoomForResolution(this.getConstrainedResolution(i, e));
        }
        getConstrainedResolution(t, e) {
          e = e || 0;
          const i = this.getViewportSize_(this.getRotation());
          return this.constraints_.resolution(t, e, i);
        }
      };
      const Bs = class extends ws {
          constructor(t) {
            const e = Object.assign({}, t);
            delete e.source,
              super(e),
              this.on,
              this.once,
              this.un,
              (this.mapPrecomposeKey_ = null),
              (this.mapRenderKey_ = null),
              (this.sourceChangeKey_ = null),
              (this.renderer_ = null),
              (this.sourceReady_ = !1),
              (this.rendered = !1),
              t.render && (this.render = t.render),
              t.map && this.setMap(t.map),
              this.addChangeListener(xs, this.handleSourcePropertyChange_);
            const i = t.source ? t.source : null;
            this.setSource(i);
          }
          getLayersArray(t) {
            return (t = t || []).push(this), t;
          }
          getLayerStatesArray(t) {
            return (t = t || []).push(this.getLayerState()), t;
          }
          getSource() {
            return this.get(xs) || null;
          }
          getRenderSource() {
            return this.getSource();
          }
          getSourceState() {
            const t = this.getSource();
            return t ? t.getState() : "undefined";
          }
          handleSourceChange_() {
            this.changed(),
              this.sourceReady_ ||
                "ready" !== this.getSource().getState() ||
                ((this.sourceReady_ = !0), this.dispatchEvent("sourceready"));
          }
          handleSourcePropertyChange_() {
            this.sourceChangeKey_ &&
              (M(this.sourceChangeKey_), (this.sourceChangeKey_ = null)),
              (this.sourceReady_ = !1);
            const t = this.getSource();
            t &&
              ((this.sourceChangeKey_ = b(
                t,
                w,
                this.handleSourceChange_,
                this
              )),
              "ready" === t.getState() &&
                ((this.sourceReady_ = !0),
                setTimeout(() => {
                  this.dispatchEvent("sourceready");
                }, 0))),
              this.changed();
          }
          getFeatures(t) {
            return this.renderer_
              ? this.renderer_.getFeatures(t)
              : Promise.resolve([]);
          }
          getData(t) {
            return this.renderer_ && this.rendered
              ? this.renderer_.getData(t)
              : null;
          }
          isVisible(t) {
            let e;
            const i = this.getMapInternal();
            let n;
            !t && i && (t = i.getView()),
              (e =
                t instanceof zs
                  ? { viewState: t.getState(), extent: t.calculateExtent() }
                  : t),
              !e.layerStatesArray &&
                i &&
                (e.layerStatesArray = i.getLayerGroup().getLayerStatesArray()),
              (n = e.layerStatesArray
                ? e.layerStatesArray.find((t) => t.layer === this)
                : this.getLayerState());
            const s = this.getExtent();
            return (
              (function (t, e) {
                if (!t.visible) return !1;
                const i = e.resolution;
                if (i < t.minResolution || i >= t.maxResolution) return !1;
                const n = e.zoom;
                return n > t.minZoom && n <= t.maxZoom;
              })(n, e.viewState) &&
              (!s || Lt(s, e.extent))
            );
          }
          getAttributions(t) {
            if (!this.isVisible(t)) return [];
            const e = this.getSource()?.getAttributions();
            if (!e) return [];
            let i = e(t instanceof zs ? t.getViewStateAndExtent() : t);
            return Array.isArray(i) || (i = [i]), i;
          }
          render(t, e) {
            const i = this.getRenderer();
            return i.prepareFrame(t)
              ? ((this.rendered = !0), i.renderFrame(t, e))
              : null;
          }
          unrender() {
            this.rendered = !1;
          }
          getDeclutter() {}
          renderDeclutter(t, e) {}
          renderDeferred(t) {
            const e = this.getRenderer();
            e && e.renderDeferred(t);
          }
          setMapInternal(t) {
            t || this.unrender(), this.set(vs, t);
          }
          getMapInternal() {
            return this.get(vs);
          }
          setMap(t) {
            this.mapPrecomposeKey_ &&
              (M(this.mapPrecomposeKey_), (this.mapPrecomposeKey_ = null)),
              t || this.changed(),
              this.mapRenderKey_ &&
                (M(this.mapRenderKey_), (this.mapRenderKey_ = null)),
              t &&
                ((this.mapPrecomposeKey_ = b(
                  t,
                  bs,
                  this.handlePrecompose_,
                  this
                )),
                (this.mapRenderKey_ = b(this, w, t.render, t)),
                this.changed());
          }
          handlePrecompose_(t) {
            const e = t.frameState.layerStatesArray,
              i = this.getLayerState(!1);
            D(
              !e.some((t) => t.layer === i.layer),
              "A layer can only be added to the map once. Use either `layer.setMap()` or `map.addLayer()`, not both."
            ),
              e.push(i);
          }
          setSource(t) {
            this.set(xs, t);
          }
          getRenderer() {
            return (
              this.renderer_ || (this.renderer_ = this.createRenderer()),
              this.renderer_
            );
          }
          hasRenderer() {
            return !!this.renderer_;
          }
          createRenderer() {
            return null;
          }
          disposeInternal() {
            this.renderer_ && (this.renderer_.dispose(), delete this.renderer_),
              this.setSource(null),
              super.disposeInternal();
          }
        },
        Ns = { IDLE: 0, LOADING: 1, LOADED: 2, ERROR: 3, EMPTY: 4 };
      function Ws(t, e) {
        return Array.isArray(t)
          ? t
          : (void 0 === e ? (e = [t, t]) : ((e[0] = t), (e[1] = t)), e);
      }
      class Xs {
        constructor(t) {
          (this.opacity_ = t.opacity),
            (this.rotateWithView_ = t.rotateWithView),
            (this.rotation_ = t.rotation),
            (this.scale_ = t.scale),
            (this.scaleArray_ = Ws(t.scale)),
            (this.displacement_ = t.displacement),
            (this.declutterMode_ = t.declutterMode);
        }
        clone() {
          const t = this.getScale();
          return new Xs({
            opacity: this.getOpacity(),
            scale: Array.isArray(t) ? t.slice() : t,
            rotation: this.getRotation(),
            rotateWithView: this.getRotateWithView(),
            displacement: this.getDisplacement().slice(),
            declutterMode: this.getDeclutterMode(),
          });
        }
        getOpacity() {
          return this.opacity_;
        }
        getRotateWithView() {
          return this.rotateWithView_;
        }
        getRotation() {
          return this.rotation_;
        }
        getScale() {
          return this.scale_;
        }
        getScaleArray() {
          return this.scaleArray_;
        }
        getDisplacement() {
          return this.displacement_;
        }
        getDeclutterMode() {
          return this.declutterMode_;
        }
        getAnchor() {
          return R();
        }
        getImage(t) {
          return R();
        }
        getHitDetectionImage() {
          return R();
        }
        getPixelRatio(t) {
          return 1;
        }
        getImageState() {
          return R();
        }
        getImageSize() {
          return R();
        }
        getOrigin() {
          return R();
        }
        getSize() {
          return R();
        }
        setDisplacement(t) {
          this.displacement_ = t;
        }
        setOpacity(t) {
          this.opacity_ = t;
        }
        setRotateWithView(t) {
          this.rotateWithView_ = t;
        }
        setRotation(t) {
          this.rotation_ = t;
        }
        setScale(t) {
          (this.scale_ = t), (this.scaleArray_ = Ws(t));
        }
        listenImageChange(t) {
          R();
        }
        load() {
          R();
        }
        unlistenImageChange(t) {
          R();
        }
        ready() {
          return Promise.resolve();
        }
      }
      const Ys = Xs,
        Vs = {
          name: "rgb",
          min: [0, 0, 0],
          max: [255, 255, 255],
          channel: ["red", "green", "blue"],
          alias: ["RGB"],
        };
      var qs = {
        name: "xyz",
        min: [0, 0, 0],
        channel: ["X", "Y", "Z"],
        alias: ["XYZ", "ciexyz", "cie1931"],
        whitepoint: {
          2: {
            A: [109.85, 100, 35.585],
            C: [98.074, 100, 118.232],
            D50: [96.422, 100, 82.521],
            D55: [95.682, 100, 92.149],
            D65: [95.045592705167, 100, 108.9057750759878],
            D75: [94.972, 100, 122.638],
            F2: [99.187, 100, 67.395],
            F7: [95.044, 100, 108.755],
            F11: [100.966, 100, 64.37],
            E: [100, 100, 100],
          },
          10: {
            A: [111.144, 100, 35.2],
            C: [97.285, 100, 116.145],
            D50: [96.72, 100, 81.427],
            D55: [95.799, 100, 90.926],
            D65: [94.811, 100, 107.304],
            D75: [94.416, 100, 120.641],
            F2: [103.28, 100, 69.026],
            F7: [95.792, 100, 107.687],
            F11: [103.866, 100, 65.627],
            E: [100, 100, 100],
          },
        },
      };
      (qs.max = qs.whitepoint[2].D65),
        (qs.rgb = function (t, e) {
          e = e || qs.whitepoint[2].E;
          var i,
            n,
            s,
            r = t[0] / e[0],
            o = t[1] / e[1],
            a = t[2] / e[2];
          return (
            (n =
              -0.96924363628087 * r +
              1.87596750150772 * o +
              0.041555057407175 * a),
            (s =
              0.055630079696993 * r +
              -0.20397695888897 * o +
              1.056971514242878 * a),
            (i =
              (i =
                3.240969941904521 * r +
                -1.537383177570093 * o +
                -0.498610760293 * a) > 0.0031308
                ? 1.055 * Math.pow(i, 1 / 2.4) - 0.055
                : (i *= 12.92)),
            (n =
              n > 0.0031308
                ? 1.055 * Math.pow(n, 1 / 2.4) - 0.055
                : (n *= 12.92)),
            (s =
              s > 0.0031308
                ? 1.055 * Math.pow(s, 1 / 2.4) - 0.055
                : (s *= 12.92)),
            [
              255 * (i = Math.min(Math.max(0, i), 1)),
              255 * (n = Math.min(Math.max(0, n), 1)),
              255 * (s = Math.min(Math.max(0, s), 1)),
            ]
          );
        }),
        (Vs.xyz = function (t, e) {
          var i = t[0] / 255,
            n = t[1] / 255,
            s = t[2] / 255,
            r =
              0.21263900587151 *
                (i =
                  i > 0.04045
                    ? Math.pow((i + 0.055) / 1.055, 2.4)
                    : i / 12.92) +
              0.71516867876775 *
                (n =
                  n > 0.04045
                    ? Math.pow((n + 0.055) / 1.055, 2.4)
                    : n / 12.92) +
              0.072192315360733 *
                (s =
                  s > 0.04045 ? Math.pow((s + 0.055) / 1.055, 2.4) : s / 12.92),
            o =
              0.019330818715591 * i +
              0.11919477979462 * n +
              0.95053215224966 * s;
          return [
            (0.41239079926595 * i +
              0.35758433938387 * n +
              0.18048078840183 * s) *
              (e = e || qs.whitepoint[2].E)[0],
            r * e[1],
            o * e[2],
          ];
        });
      const $s = qs,
        Us = {
          name: "luv",
          min: [0, -134, -140],
          max: [100, 224, 122],
          channel: ["lightness", "u", "v"],
          alias: ["LUV", "cieluv", "cie1976"],
          xyz: function (t, e, i) {
            var n, s, r, o, a, l, h, c, u;
            if (((r = t[0]), (o = t[1]), (a = t[2]), 0 === r)) return [0, 0, 0];
            return (
              (e = e || "D65"),
              (i = i || 2),
              (n =
                o / (13 * r) +
                  (4 * (h = $s.whitepoint[i][e][0])) /
                    (h +
                      15 * (c = $s.whitepoint[i][e][1]) +
                      3 * (u = $s.whitepoint[i][e][2])) || 0),
              (s = a / (13 * r) + (9 * c) / (h + 15 * c + 3 * u) || 0),
              [
                (9 *
                  (l =
                    r > 8
                      ? c * Math.pow((r + 16) / 116, 3)
                      : c * r * 0.0011070564598794539) *
                  n) /
                  (4 * s) || 0,
                l,
                (l * (12 - 3 * n - 20 * s)) / (4 * s) || 0,
              ]
            );
          },
        };
      $s.luv = function (t, e, i) {
        var n, s, r, o, a, l, h, c, u, d, g;
        (e = e || "D65"),
          (i = i || 2),
          (d =
            (4 * (h = $s.whitepoint[i][e][0])) /
            (h +
              15 * (c = $s.whitepoint[i][e][1]) +
              3 * (u = $s.whitepoint[i][e][2]))),
          (g = (9 * c) / (h + 15 * c + 3 * u)),
          (n = (4 * (o = t[0])) / (o + 15 * (a = t[1]) + 3 * (l = t[2])) || 0),
          (s = (9 * a) / (o + 15 * a + 3 * l) || 0);
        var f = a / c;
        return [
          (r =
            f <= 0.008856451679035631
              ? 903.2962962962961 * f
              : 116 * Math.pow(f, 1 / 3) - 16),
          13 * r * (n - d),
          13 * r * (s - g),
        ];
      };
      var Hs = {
        name: "lchuv",
        channel: ["lightness", "chroma", "hue"],
        alias: ["LCHuv", "cielchuv"],
        min: [0, 0, 0],
        max: [100, 100, 360],
        luv: function (t) {
          var e,
            i = t[0],
            n = t[1];
          return (
            (e = (t[2] / 360) * 2 * Math.PI),
            [i, n * Math.cos(e), n * Math.sin(e)]
          );
        },
        xyz: function (t) {
          return Us.xyz(Hs.luv(t));
        },
      };
      const Ks = Hs;
      (Us.lchuv = function (t) {
        var e = t[0],
          i = t[1],
          n = t[2],
          s = Math.sqrt(i * i + n * n),
          r = (360 * Math.atan2(n, i)) / 2 / Math.PI;
        return r < 0 && (r += 360), [e, s, r];
      }),
        ($s.lchuv = function (t) {
          return Us.lchuv($s.luv(t));
        });
      const Js = {
          aliceblue: [240, 248, 255],
          antiquewhite: [250, 235, 215],
          aqua: [0, 255, 255],
          aquamarine: [127, 255, 212],
          azure: [240, 255, 255],
          beige: [245, 245, 220],
          bisque: [255, 228, 196],
          black: [0, 0, 0],
          blanchedalmond: [255, 235, 205],
          blue: [0, 0, 255],
          blueviolet: [138, 43, 226],
          brown: [165, 42, 42],
          burlywood: [222, 184, 135],
          cadetblue: [95, 158, 160],
          chartreuse: [127, 255, 0],
          chocolate: [210, 105, 30],
          coral: [255, 127, 80],
          cornflowerblue: [100, 149, 237],
          cornsilk: [255, 248, 220],
          crimson: [220, 20, 60],
          cyan: [0, 255, 255],
          darkblue: [0, 0, 139],
          darkcyan: [0, 139, 139],
          darkgoldenrod: [184, 134, 11],
          darkgray: [169, 169, 169],
          darkgreen: [0, 100, 0],
          darkgrey: [169, 169, 169],
          darkkhaki: [189, 183, 107],
          darkmagenta: [139, 0, 139],
          darkolivegreen: [85, 107, 47],
          darkorange: [255, 140, 0],
          darkorchid: [153, 50, 204],
          darkred: [139, 0, 0],
          darksalmon: [233, 150, 122],
          darkseagreen: [143, 188, 143],
          darkslateblue: [72, 61, 139],
          darkslategray: [47, 79, 79],
          darkslategrey: [47, 79, 79],
          darkturquoise: [0, 206, 209],
          darkviolet: [148, 0, 211],
          deeppink: [255, 20, 147],
          deepskyblue: [0, 191, 255],
          dimgray: [105, 105, 105],
          dimgrey: [105, 105, 105],
          dodgerblue: [30, 144, 255],
          firebrick: [178, 34, 34],
          floralwhite: [255, 250, 240],
          forestgreen: [34, 139, 34],
          fuchsia: [255, 0, 255],
          gainsboro: [220, 220, 220],
          ghostwhite: [248, 248, 255],
          gold: [255, 215, 0],
          goldenrod: [218, 165, 32],
          gray: [128, 128, 128],
          green: [0, 128, 0],
          greenyellow: [173, 255, 47],
          grey: [128, 128, 128],
          honeydew: [240, 255, 240],
          hotpink: [255, 105, 180],
          indianred: [205, 92, 92],
          indigo: [75, 0, 130],
          ivory: [255, 255, 240],
          khaki: [240, 230, 140],
          lavender: [230, 230, 250],
          lavenderblush: [255, 240, 245],
          lawngreen: [124, 252, 0],
          lemonchiffon: [255, 250, 205],
          lightblue: [173, 216, 230],
          lightcoral: [240, 128, 128],
          lightcyan: [224, 255, 255],
          lightgoldenrodyellow: [250, 250, 210],
          lightgray: [211, 211, 211],
          lightgreen: [144, 238, 144],
          lightgrey: [211, 211, 211],
          lightpink: [255, 182, 193],
          lightsalmon: [255, 160, 122],
          lightseagreen: [32, 178, 170],
          lightskyblue: [135, 206, 250],
          lightslategray: [119, 136, 153],
          lightslategrey: [119, 136, 153],
          lightsteelblue: [176, 196, 222],
          lightyellow: [255, 255, 224],
          lime: [0, 255, 0],
          limegreen: [50, 205, 50],
          linen: [250, 240, 230],
          magenta: [255, 0, 255],
          maroon: [128, 0, 0],
          mediumaquamarine: [102, 205, 170],
          mediumblue: [0, 0, 205],
          mediumorchid: [186, 85, 211],
          mediumpurple: [147, 112, 219],
          mediumseagreen: [60, 179, 113],
          mediumslateblue: [123, 104, 238],
          mediumspringgreen: [0, 250, 154],
          mediumturquoise: [72, 209, 204],
          mediumvioletred: [199, 21, 133],
          midnightblue: [25, 25, 112],
          mintcream: [245, 255, 250],
          mistyrose: [255, 228, 225],
          moccasin: [255, 228, 181],
          navajowhite: [255, 222, 173],
          navy: [0, 0, 128],
          oldlace: [253, 245, 230],
          olive: [128, 128, 0],
          olivedrab: [107, 142, 35],
          orange: [255, 165, 0],
          orangered: [255, 69, 0],
          orchid: [218, 112, 214],
          palegoldenrod: [238, 232, 170],
          palegreen: [152, 251, 152],
          paleturquoise: [175, 238, 238],
          palevioletred: [219, 112, 147],
          papayawhip: [255, 239, 213],
          peachpuff: [255, 218, 185],
          peru: [205, 133, 63],
          pink: [255, 192, 203],
          plum: [221, 160, 221],
          powderblue: [176, 224, 230],
          purple: [128, 0, 128],
          rebeccapurple: [102, 51, 153],
          red: [255, 0, 0],
          rosybrown: [188, 143, 143],
          royalblue: [65, 105, 225],
          saddlebrown: [139, 69, 19],
          salmon: [250, 128, 114],
          sandybrown: [244, 164, 96],
          seagreen: [46, 139, 87],
          seashell: [255, 245, 238],
          sienna: [160, 82, 45],
          silver: [192, 192, 192],
          skyblue: [135, 206, 235],
          slateblue: [106, 90, 205],
          slategray: [112, 128, 144],
          slategrey: [112, 128, 144],
          snow: [255, 250, 250],
          springgreen: [0, 255, 127],
          steelblue: [70, 130, 180],
          tan: [210, 180, 140],
          teal: [0, 128, 128],
          thistle: [216, 191, 216],
          tomato: [255, 99, 71],
          turquoise: [64, 224, 208],
          violet: [238, 130, 238],
          wheat: [245, 222, 179],
          white: [255, 255, 255],
          whitesmoke: [245, 245, 245],
          yellow: [255, 255, 0],
          yellowgreen: [154, 205, 50],
        },
        Qs = function (t) {
          var e,
            i,
            n = [],
            s = 1;
          if ("number" === typeof t)
            return {
              space: "rgb",
              values: [t >>> 16, (65280 & t) >>> 8, 255 & t],
              alpha: 1,
            };
          if ("number" === typeof t)
            return {
              space: "rgb",
              values: [t >>> 16, (65280 & t) >>> 8, 255 & t],
              alpha: 1,
            };
          if (((t = String(t).toLowerCase()), Js[t]))
            (n = Js[t].slice()), (i = "rgb");
          else if ("transparent" === t) (s = 0), (i = "rgb"), (n = [0, 0, 0]);
          else if ("#" === t[0]) {
            var r = t.slice(1),
              o = r.length;
            (s = 1),
              o <= 4
                ? ((n = [
                    parseInt(r[0] + r[0], 16),
                    parseInt(r[1] + r[1], 16),
                    parseInt(r[2] + r[2], 16),
                  ]),
                  4 === o && (s = parseInt(r[3] + r[3], 16) / 255))
                : ((n = [
                    parseInt(r[0] + r[1], 16),
                    parseInt(r[2] + r[3], 16),
                    parseInt(r[4] + r[5], 16),
                  ]),
                  8 === o && (s = parseInt(r[6] + r[7], 16) / 255)),
              n[0] || (n[0] = 0),
              n[1] || (n[1] = 0),
              n[2] || (n[2] = 0),
              (i = "rgb");
          } else if (
            (e =
              /^((?:rgba?|hs[lvb]a?|hwba?|cmyk?|xy[zy]|gray|lab|lchu?v?|[ly]uv|lms|oklch|oklab|color))\s*\(([^\)]*)\)/.exec(
                t
              ))
          ) {
            var a = e[1],
              l =
                "cmyk" === (i = a.replace(/a$/, "")) ? 4 : "gray" === i ? 1 : 3;
            (n = e[2].trim().split(/\s*[,\/]\s*|\s+/)),
              "color" === i && (i = n.shift()),
              (s =
                (n = n.map(function (t, e) {
                  if ("%" === t[t.length - 1])
                    return (
                      (t = parseFloat(t) / 100),
                      3 === e
                        ? t
                        : "rgb" === i
                        ? 255 * t
                        : "h" === i[0]
                        ? 100 * t
                        : "l" !== i[0] || e
                        ? "lab" === i
                          ? 125 * t
                          : "lch" === i
                          ? e < 2
                            ? 150 * t
                            : 360 * t
                          : "o" !== i[0] || e
                          ? "oklab" === i
                            ? 0.4 * t
                            : "oklch" === i
                            ? e < 2
                              ? 0.4 * t
                              : 360 * t
                            : t
                          : t
                        : 100 * t
                    );
                  if ("h" === i[e] || (2 === e && "h" === i[i.length - 1])) {
                    if (void 0 !== tr[t]) return tr[t];
                    if (t.endsWith("deg")) return parseFloat(t);
                    if (t.endsWith("turn")) return 360 * parseFloat(t);
                    if (t.endsWith("grad")) return (360 * parseFloat(t)) / 400;
                    if (t.endsWith("rad"))
                      return (180 * parseFloat(t)) / Math.PI;
                  }
                  return "none" === t ? 0 : parseFloat(t);
                })).length > l
                  ? n.pop()
                  : 1);
          } else
            /[0-9](?:\s|\/|,)/.test(t) &&
              ((n = t.match(/([0-9]+)/g).map(function (t) {
                return parseFloat(t);
              })),
              (i =
                t
                  .match(/([a-z])/gi)
                  ?.join("")
                  ?.toLowerCase() || "rgb"));
          return { space: i, values: n, alpha: s };
        };
      var tr = {
        red: 0,
        orange: 60,
        yellow: 120,
        green: 180,
        blue: 240,
        purple: 300,
      };
      const er = {
        name: "hsl",
        min: [0, 0, 0],
        max: [360, 100, 100],
        channel: ["hue", "saturation", "lightness"],
        alias: ["HSL"],
        rgb: function (t) {
          var e,
            i,
            n,
            s,
            r,
            o = t[0] / 360,
            a = t[1] / 100,
            l = t[2] / 100,
            h = 0;
          if (0 === a) return [(r = 255 * l), r, r];
          for (
            e = 2 * l - (i = l < 0.5 ? l * (1 + a) : l + a - l * a),
              s = [0, 0, 0];
            h < 3;

          )
            (n = o + (1 / 3) * -(h - 1)) < 0 ? n++ : n > 1 && n--,
              (r =
                6 * n < 1
                  ? e + 6 * (i - e) * n
                  : 2 * n < 1
                  ? i
                  : 3 * n < 2
                  ? e + (i - e) * (2 / 3 - n) * 6
                  : e),
              (s[h++] = 255 * r);
          return s;
        },
      };
      Vs.hsl = function (t) {
        var e,
          i,
          n = t[0] / 255,
          s = t[1] / 255,
          r = t[2] / 255,
          o = Math.min(n, s, r),
          a = Math.max(n, s, r),
          l = a - o;
        return (
          a === o
            ? (e = 0)
            : n === a
            ? (e = (s - r) / l)
            : s === a
            ? (e = 2 + (r - n) / l)
            : r === a && (e = 4 + (n - s) / l),
          (e = Math.min(60 * e, 360)) < 0 && (e += 360),
          (i = (o + a) / 2),
          [
            e,
            100 * (a === o ? 0 : i <= 0.5 ? l / (a + o) : l / (2 - a - o)),
            100 * i,
          ]
        );
      };
      const ir = [NaN, NaN, NaN, 0];
      const nr = 1024,
        sr = {};
      let rr = 0;
      function or(t) {
        if (4 === t.length) return t;
        const e = t.slice();
        return (e[3] = 1), e;
      }
      function ar(t) {
        const e = $s.lchuv(Vs.xyz(t));
        return (e[3] = t[3]), e;
      }
      function lr(t) {
        if ("none" === t) return ir;
        if (sr.hasOwnProperty(t)) return sr[t];
        if (rr >= nr) {
          let t = 0;
          for (const e in sr) 0 === (3 & t++) && (delete sr[e], --rr);
        }
        const e = (function (t) {
          var e;
          Array.isArray(t) && t.raw && (t = String.raw(...arguments)),
            t instanceof Number && (t = +t);
          var i = Qs(t);
          if (!i.space) return [];
          const n = "h" === i.space[0] ? er.min : Vs.min,
            s = "h" === i.space[0] ? er.max : Vs.max;
          return (
            ((e = Array(3))[0] = Math.min(Math.max(i.values[0], n[0]), s[0])),
            (e[1] = Math.min(Math.max(i.values[1], n[1]), s[1])),
            (e[2] = Math.min(Math.max(i.values[2], n[2]), s[2])),
            "h" === i.space[0] && (e = er.rgb(e)),
            e.push(Math.min(Math.max(i.alpha, 0), 1)),
            e
          );
        })(t);
        if (4 !== e.length)
          throw new Error('failed to parse "' + t + '" as color');
        for (const i of e)
          if (isNaN(i)) throw new Error('failed to parse "' + t + '" as color');
        return cr(e), (sr[t] = e), ++rr, e;
      }
      function hr(t) {
        return Array.isArray(t) ? t : lr(t);
      }
      function cr(t) {
        return (
          (t[0] = Nt((t[0] + 0.5) | 0, 0, 255)),
          (t[1] = Nt((t[1] + 0.5) | 0, 0, 255)),
          (t[2] = Nt((t[2] + 0.5) | 0, 0, 255)),
          (t[3] = Nt(t[3], 0, 1)),
          t
        );
      }
      function ur(t) {
        let e = t[0];
        e != (0 | e) && (e = (e + 0.5) | 0);
        let i = t[1];
        i != (0 | i) && (i = (i + 0.5) | 0);
        let n = t[2];
        n != (0 | n) && (n = (n + 0.5) | 0);
        return (
          "rgba(" +
          e +
          "," +
          i +
          "," +
          n +
          "," +
          (void 0 === t[3] ? 1 : Math.round(1e3 * t[3]) / 1e3) +
          ")"
        );
      }
      const dr =
          "undefined" !== typeof navigator &&
          "undefined" !== typeof navigator.userAgent
            ? navigator.userAgent.toLowerCase()
            : "",
        gr =
          (dr.includes("firefox"),
          dr.includes("safari") &&
            !dr.includes("chrom") &&
            (dr.includes("version/15.4") ||
              /cpu (os|iphone os) 15_4 like mac os x/.test(dr)),
          dr.includes("webkit") && dr.includes("edge"),
          dr.includes("macintosh"),
          "undefined" !== typeof devicePixelRatio && devicePixelRatio,
          "undefined" !== typeof WorkerGlobalScope &&
            "undefined" !== typeof OffscreenCanvas &&
            self instanceof WorkerGlobalScope),
        fr = "undefined" !== typeof Image && Image.prototype.decode;
      !(function () {
        let t = !1;
        try {
          const e = Object.defineProperty({}, "passive", {
            get: function () {
              t = !0;
            },
          });
          window.addEventListener("_", null, e),
            window.removeEventListener("_", null, e);
        } catch (e) {}
      })();
      function pr(t, e, i, n) {
        let s;
        return (
          (s =
            i && i.length
              ? i.shift()
              : gr
              ? new OffscreenCanvas(t || 300, e || 300)
              : document.createElement("canvas")),
          t && (s.width = t),
          e && (s.height = e),
          s.getContext("2d", n)
        );
      }
      let mr;
      function _r() {
        return mr || (mr = pr(1, 1)), mr;
      }
      function yr(t, e) {
        return (
          e && (t.src = e),
          t.src && fr
            ? new Promise((e, i) =>
                t
                  .decode()
                  .then(() => e(t))
                  .catch((n) => (t.complete && t.width ? e(t) : i(n)))
              )
            : (function (t, e) {
                return new Promise((i, n) => {
                  function s() {
                    o(), i(t);
                  }
                  function r() {
                    o(), n(new Error("Image load error"));
                  }
                  function o() {
                    t.removeEventListener("load", s),
                      t.removeEventListener("error", r);
                  }
                  t.addEventListener("load", s),
                    t.addEventListener("error", r),
                    e && (t.src = e);
                });
              })(t)
        );
      }
      class xr {
        constructor() {
          (this.cache_ = {}),
            (this.patternCache_ = {}),
            (this.cacheSize_ = 0),
            (this.maxCacheSize_ = 32);
        }
        clear() {
          (this.cache_ = {}), (this.patternCache_ = {}), (this.cacheSize_ = 0);
        }
        canExpireCache() {
          return this.cacheSize_ > this.maxCacheSize_;
        }
        expire() {
          if (this.canExpireCache()) {
            let t = 0;
            for (const e in this.cache_) {
              const i = this.cache_[e];
              0 !== (3 & t++) ||
                i.hasListener() ||
                (delete this.cache_[e],
                delete this.patternCache_[e],
                --this.cacheSize_);
            }
          }
        }
        get(t, e, i) {
          const n = vr(t, e, i);
          return n in this.cache_ ? this.cache_[n] : null;
        }
        getPattern(t, e, i) {
          const n = vr(t, e, i);
          return n in this.patternCache_ ? this.patternCache_[n] : null;
        }
        set(t, e, i, n, s) {
          const r = vr(t, e, i),
            o = r in this.cache_;
          (this.cache_[r] = n),
            s &&
              (n.getImageState() === Ns.IDLE && n.load(),
              n.getImageState() === Ns.LOADING
                ? n.ready().then(() => {
                    this.patternCache_[r] = _r().createPattern(
                      n.getImage(1),
                      "repeat"
                    );
                  })
                : (this.patternCache_[r] = _r().createPattern(
                    n.getImage(1),
                    "repeat"
                  ))),
            o || ++this.cacheSize_;
        }
        setSize(t) {
          (this.maxCacheSize_ = t), this.expire();
        }
      }
      function vr(t, e, i) {
        return e + ":" + t + ":" + (i ? hr(i) : "null");
      }
      const wr = new xr();
      let Sr = null;
      class Cr extends v {
        constructor(t, e, i, n, s) {
          super(),
            (this.hitDetectionImage_ = null),
            (this.image_ = t),
            (this.crossOrigin_ = i),
            (this.canvas_ = {}),
            (this.color_ = s),
            (this.imageState_ = void 0 === n ? Ns.IDLE : n),
            (this.size_ =
              t && t.width && t.height ? [t.width, t.height] : null),
            (this.src_ = e),
            this.tainted_,
            (this.ready_ = null);
        }
        initializeImage_() {
          (this.image_ = new Image()),
            null !== this.crossOrigin_ &&
              (this.image_.crossOrigin = this.crossOrigin_);
        }
        isTainted_() {
          if (void 0 === this.tainted_ && this.imageState_ === Ns.LOADED) {
            Sr || (Sr = pr(1, 1, void 0, { willReadFrequently: !0 })),
              Sr.drawImage(this.image_, 0, 0);
            try {
              Sr.getImageData(0, 0, 1, 1), (this.tainted_ = !1);
            } catch (t) {
              (Sr = null), (this.tainted_ = !0);
            }
          }
          return !0 === this.tainted_;
        }
        dispatchChangeEvent_() {
          this.dispatchEvent(w);
        }
        handleImageError_() {
          (this.imageState_ = Ns.ERROR), this.dispatchChangeEvent_();
        }
        handleImageLoad_() {
          (this.imageState_ = Ns.LOADED),
            (this.size_ = [this.image_.width, this.image_.height]),
            this.dispatchChangeEvent_();
        }
        getImage(t) {
          return (
            this.image_ || this.initializeImage_(),
            this.replaceColor_(t),
            this.canvas_[t] ? this.canvas_[t] : this.image_
          );
        }
        getPixelRatio(t) {
          return this.replaceColor_(t), this.canvas_[t] ? t : 1;
        }
        getImageState() {
          return this.imageState_;
        }
        getHitDetectionImage() {
          if (
            (this.image_ || this.initializeImage_(), !this.hitDetectionImage_)
          )
            if (this.isTainted_()) {
              const t = this.size_[0],
                e = this.size_[1],
                i = pr(t, e);
              i.fillRect(0, 0, t, e), (this.hitDetectionImage_ = i.canvas);
            } else this.hitDetectionImage_ = this.image_;
          return this.hitDetectionImage_;
        }
        getSize() {
          return this.size_;
        }
        getSrc() {
          return this.src_;
        }
        load() {
          if (this.imageState_ === Ns.IDLE) {
            this.image_ || this.initializeImage_(),
              (this.imageState_ = Ns.LOADING);
            try {
              void 0 !== this.src_ && (this.image_.src = this.src_);
            } catch (t) {
              this.handleImageError_();
            }
            this.image_ instanceof HTMLImageElement &&
              yr(this.image_, this.src_)
                .then((t) => {
                  (this.image_ = t), this.handleImageLoad_();
                })
                .catch(this.handleImageError_.bind(this));
          }
        }
        replaceColor_(t) {
          if (!this.color_ || this.canvas_[t] || this.imageState_ !== Ns.LOADED)
            return;
          const e = this.image_,
            i = pr(Math.ceil(e.width * t), Math.ceil(e.height * t)),
            n = i.canvas;
          var s;
          i.scale(t, t),
            i.drawImage(e, 0, 0),
            (i.globalCompositeOperation = "multiply"),
            (i.fillStyle = "string" === typeof (s = this.color_) ? s : ur(s)),
            i.fillRect(0, 0, n.width / t, n.height / t),
            (i.globalCompositeOperation = "destination-in"),
            i.drawImage(e, 0, 0),
            (this.canvas_[t] = n);
        }
        ready() {
          return (
            this.ready_ ||
              (this.ready_ = new Promise((t) => {
                if (
                  this.imageState_ === Ns.LOADED ||
                  this.imageState_ === Ns.ERROR
                )
                  t();
                else {
                  const e = () => {
                    (this.imageState_ !== Ns.LOADED &&
                      this.imageState_ !== Ns.ERROR) ||
                      (this.removeEventListener(w, e), t());
                  };
                  this.addEventListener(w, e);
                }
              })),
            this.ready_
          );
        }
      }
      function br(t, e, i, n, s, r) {
        let o = void 0 === e ? void 0 : wr.get(e, i, s);
        return (
          o ||
            ((o = new Cr(t, t && "src" in t ? t.src || void 0 : e, i, n, s)),
            wr.set(e, i, s, o, r)),
          r && o && !wr.getPattern(e, i, s) && wr.set(e, i, s, o, r),
          o
        );
      }
      function kr(t) {
        return t
          ? Array.isArray(t)
            ? ur(t)
            : "object" === typeof t && "src" in t
            ? (function (t) {
                if (!t.offset || !t.size)
                  return wr.getPattern(t.src, "anonymous", t.color);
                const e = t.src + ":" + t.offset,
                  i = wr.getPattern(e, void 0, t.color);
                if (i) return i;
                const n = wr.get(t.src, "anonymous", null);
                if (n.getImageState() !== Ns.LOADED) return null;
                const s = pr(t.size[0], t.size[1]);
                return (
                  s.drawImage(
                    n.getImage(1),
                    t.offset[0],
                    t.offset[1],
                    t.size[0],
                    t.size[1],
                    0,
                    0,
                    t.size[0],
                    t.size[1]
                  ),
                  br(s.canvas, e, void 0, Ns.LOADED, t.color, !0),
                  wr.getPattern(e, void 0, t.color)
                );
              })(t)
            : t
          : null;
      }
      const Mr = new RegExp(
          [
            "^\\s*(?=(?:(?:[-a-z]+\\s*){0,2}(italic|oblique))?)",
            "(?=(?:(?:[-a-z]+\\s*){0,2}(small-caps))?)",
            "(?=(?:(?:[-a-z]+\\s*){0,2}(bold(?:er)?|lighter|[1-9]00 ))?)",
            "(?:(?:normal|\\1|\\2|\\3)\\s*){0,3}((?:xx?-)?",
            "(?:small|large)|medium|smaller|larger|[\\.\\d]+(?:\\%|in|[cem]m|ex|p[ctx]))",
            "(?:\\s*\\/\\s*(normal|[\\.\\d]+(?:\\%|in|[cem]m|ex|p[ctx])?))",
            "?\\s*([-,\\\"\\'\\sa-z]+?)\\s*$",
          ].join(""),
          "i"
        ),
        Ir = ["style", "variant", "weight", "size", "lineHeight", "family"],
        Er = function (t) {
          const e = t.match(Mr);
          if (!e) return null;
          const i = {
            lineHeight: "normal",
            size: "1.2em",
            style: "normal",
            weight: "normal",
            variant: "normal",
          };
          for (let n = 0, s = Ir.length; n < s; ++n) {
            const t = e[n + 1];
            void 0 !== t && (i[Ir[n]] = t);
          }
          return (i.families = i.family.split(/,\s?/)), i;
        },
        Rr = "10px sans-serif",
        Pr = "#000",
        Fr = "round",
        Lr = [],
        Tr = "round",
        Dr = "#000",
        Ar = "center",
        Or = "middle",
        jr = [0, 0, 0, 0],
        Gr = new T();
      let Zr,
        zr = null;
      const Br = {},
        Nr = (function () {
          const t = "32px ",
            e = ["monospace", "serif"],
            i = e.length,
            n = "wmytzilWMYTZIL@#/&?$%10\uf013";
          let s, r;
          function o(s, o, a) {
            let l = !0;
            for (let h = 0; h < i; ++h) {
              const i = e[h];
              if (((r = Yr(s + " " + o + " " + t + i, n)), a != i)) {
                const e = Yr(s + " " + o + " " + t + a + "," + i, n);
                l = l && e != r;
              }
            }
            return !!l;
          }
          function a() {
            let t = !0;
            const e = Gr.getKeys();
            for (let i = 0, n = e.length; i < n; ++i) {
              const n = e[i];
              if (Gr.get(n) < 100) {
                const [e, i, s] = n.split("\n");
                o(e, i, s)
                  ? (y(Br), (zr = null), (Zr = void 0), Gr.set(n, 100))
                  : (Gr.set(n, Gr.get(n) + 1, !0), (t = !1));
              }
            }
            t && (clearInterval(s), (s = void 0));
          }
          return function (t) {
            const e = Er(t);
            if (!e) return;
            const i = e.families;
            for (let n = 0, r = i.length; n < r; ++n) {
              const t = i[n],
                r = e.style + "\n" + e.weight + "\n" + t;
              void 0 === Gr.get(r) &&
                (Gr.set(r, 100, !0),
                o(e.style, e.weight, t) ||
                  (Gr.set(r, 0, !0), void 0 === s && (s = setInterval(a, 32))));
            }
          };
        })(),
        Wr = (function () {
          let t;
          return function (e) {
            let i = Br[e];
            if (void 0 == i) {
              if (gr) {
                const t = Er(e),
                  n = Xr(e, "\u017dg");
                i =
                  (isNaN(Number(t.lineHeight)) ? 1.2 : Number(t.lineHeight)) *
                  (n.actualBoundingBoxAscent + n.actualBoundingBoxDescent);
              } else
                t ||
                  ((t = document.createElement("div")),
                  (t.innerHTML = "M"),
                  (t.style.minHeight = "0"),
                  (t.style.maxHeight = "none"),
                  (t.style.height = "auto"),
                  (t.style.padding = "0"),
                  (t.style.border = "none"),
                  (t.style.position = "absolute"),
                  (t.style.display = "block"),
                  (t.style.left = "-99999px")),
                  (t.style.font = e),
                  document.body.appendChild(t),
                  (i = t.offsetHeight),
                  document.body.removeChild(t);
              Br[e] = i;
            }
            return i;
          };
        })();
      function Xr(t, e) {
        return (
          zr || (zr = pr(1, 1)),
          t != Zr && ((zr.font = t), (Zr = zr.font)),
          zr.measureText(e)
        );
      }
      function Yr(t, e) {
        return Xr(t, e).width;
      }
      function Vr(t, e, i) {
        if (e in i) return i[e];
        const n = e.split("\n").reduce((e, i) => Math.max(e, Yr(t, i)), 0);
        return (i[e] = n), n;
      }
      function qr(t, e, i, n, s, r, o, a, l, h, c) {
        t.save(),
          1 !== i &&
            (void 0 === t.globalAlpha
              ? (t.globalAlpha = (t) => (t.globalAlpha *= i))
              : (t.globalAlpha *= i)),
          e && t.transform.apply(t, e),
          n.contextInstructions
            ? (t.translate(l, h),
              t.scale(c[0], c[1]),
              (function (t, e) {
                const i = t.contextInstructions;
                for (let n = 0, s = i.length; n < s; n += 2)
                  Array.isArray(i[n + 1])
                    ? e[i[n]].apply(e, i[n + 1])
                    : (e[i[n]] = i[n + 1]);
              })(n, t))
            : c[0] < 0 || c[1] < 0
            ? (t.translate(l, h),
              t.scale(c[0], c[1]),
              t.drawImage(n, s, r, o, a, 0, 0, o, a))
            : t.drawImage(n, s, r, o, a, l, h, o * c[0], a * c[1]),
          t.restore();
      }
      class $r extends Ys {
        constructor(t) {
          super({
            opacity: 1,
            rotateWithView: void 0 !== t.rotateWithView && t.rotateWithView,
            rotation: void 0 !== t.rotation ? t.rotation : 0,
            scale: void 0 !== t.scale ? t.scale : 1,
            displacement: void 0 !== t.displacement ? t.displacement : [0, 0],
            declutterMode: t.declutterMode,
          }),
            this.canvases_,
            (this.hitDetectionCanvas_ = null),
            (this.fill_ = void 0 !== t.fill ? t.fill : null),
            (this.origin_ = [0, 0]),
            (this.points_ = t.points),
            (this.radius = t.radius),
            (this.radius2_ = t.radius2),
            (this.angle_ = void 0 !== t.angle ? t.angle : 0),
            (this.stroke_ = void 0 !== t.stroke ? t.stroke : null),
            this.size_,
            this.renderOptions_,
            (this.imageState_ =
              this.fill_ && this.fill_.loading() ? Ns.LOADING : Ns.LOADED),
            this.imageState_ === Ns.LOADING &&
              this.ready().then(() => (this.imageState_ = Ns.LOADED)),
            this.render();
        }
        clone() {
          const t = this.getScale(),
            e = new $r({
              fill: this.getFill() ? this.getFill().clone() : void 0,
              points: this.getPoints(),
              radius: this.getRadius(),
              radius2: this.getRadius2(),
              angle: this.getAngle(),
              stroke: this.getStroke() ? this.getStroke().clone() : void 0,
              rotation: this.getRotation(),
              rotateWithView: this.getRotateWithView(),
              scale: Array.isArray(t) ? t.slice() : t,
              displacement: this.getDisplacement().slice(),
              declutterMode: this.getDeclutterMode(),
            });
          return e.setOpacity(this.getOpacity()), e;
        }
        getAnchor() {
          const t = this.size_,
            e = this.getDisplacement(),
            i = this.getScaleArray();
          return [t[0] / 2 - e[0] / i[0], t[1] / 2 + e[1] / i[1]];
        }
        getAngle() {
          return this.angle_;
        }
        getFill() {
          return this.fill_;
        }
        setFill(t) {
          (this.fill_ = t), this.render();
        }
        getHitDetectionImage() {
          return (
            this.hitDetectionCanvas_ ||
              (this.hitDetectionCanvas_ = this.createHitDetectionCanvas_(
                this.renderOptions_
              )),
            this.hitDetectionCanvas_
          );
        }
        getImage(t) {
          let e = this.canvases_[t];
          if (!e) {
            const i = this.renderOptions_,
              n = pr(i.size * t, i.size * t);
            this.draw_(i, n, t), (e = n.canvas), (this.canvases_[t] = e);
          }
          return e;
        }
        getPixelRatio(t) {
          return t;
        }
        getImageSize() {
          return this.size_;
        }
        getImageState() {
          return this.imageState_;
        }
        getOrigin() {
          return this.origin_;
        }
        getPoints() {
          return this.points_;
        }
        getRadius() {
          return this.radius;
        }
        getRadius2() {
          return this.radius2_;
        }
        getSize() {
          return this.size_;
        }
        getStroke() {
          return this.stroke_;
        }
        setStroke(t) {
          (this.stroke_ = t), this.render();
        }
        listenImageChange(t) {}
        load() {}
        unlistenImageChange(t) {}
        calculateLineJoinSize_(t, e, i) {
          if (
            0 === e ||
            this.points_ === 1 / 0 ||
            ("bevel" !== t && "miter" !== t)
          )
            return e;
          let n = this.radius,
            s = void 0 === this.radius2_ ? n : this.radius2_;
          if (n < s) {
            const t = n;
            (n = s), (s = t);
          }
          const r = void 0 === this.radius2_ ? this.points_ : 2 * this.points_,
            o = (2 * Math.PI) / r,
            a = s * Math.sin(o),
            l = n - Math.sqrt(s * s - a * a),
            h = Math.sqrt(a * a + l * l),
            c = h / a;
          if ("miter" === t && c <= i) return c * e;
          const u = e / 2 / c,
            d = (e / 2) * (l / h),
            g = Math.sqrt((n + u) * (n + u) + d * d) - n;
          if (void 0 === this.radius2_ || "bevel" === t) return 2 * g;
          const f = n * Math.sin(o),
            p = s - Math.sqrt(n * n - f * f),
            m = Math.sqrt(f * f + p * p) / f;
          if (m <= i) {
            const t = (m * e) / 2 - s - n;
            return 2 * Math.max(g, t);
          }
          return 2 * g;
        }
        createRenderOptions() {
          let t,
            e = Fr,
            i = Tr,
            n = 0,
            s = null,
            r = 0,
            o = 0;
          this.stroke_ &&
            ((t = kr(this.stroke_.getColor() ?? Dr)),
            (o = this.stroke_.getWidth() ?? 1),
            (s = this.stroke_.getLineDash()),
            (r = this.stroke_.getLineDashOffset() ?? 0),
            (i = this.stroke_.getLineJoin() ?? Tr),
            (e = this.stroke_.getLineCap() ?? Fr),
            (n = this.stroke_.getMiterLimit() ?? 10));
          const a = this.calculateLineJoinSize_(i, o, n),
            l = Math.max(this.radius, this.radius2_ || 0);
          return {
            strokeStyle: t,
            strokeWidth: o,
            size: Math.ceil(2 * l + a),
            lineCap: e,
            lineDash: s,
            lineDashOffset: r,
            lineJoin: i,
            miterLimit: n,
          };
        }
        render() {
          this.renderOptions_ = this.createRenderOptions();
          const t = this.renderOptions_.size;
          (this.canvases_ = {}),
            (this.hitDetectionCanvas_ = null),
            (this.size_ = [t, t]);
        }
        draw_(t, e, i) {
          if (
            (e.scale(i, i),
            e.translate(t.size / 2, t.size / 2),
            this.createPath_(e),
            this.fill_)
          ) {
            let t = this.fill_.getColor();
            null === t && (t = Pr), (e.fillStyle = kr(t)), e.fill();
          }
          t.strokeStyle &&
            ((e.strokeStyle = t.strokeStyle),
            (e.lineWidth = t.strokeWidth),
            t.lineDash &&
              (e.setLineDash(t.lineDash),
              (e.lineDashOffset = t.lineDashOffset)),
            (e.lineCap = t.lineCap),
            (e.lineJoin = t.lineJoin),
            (e.miterLimit = t.miterLimit),
            e.stroke());
        }
        createHitDetectionCanvas_(t) {
          let e;
          if (this.fill_) {
            let i = this.fill_.getColor(),
              n = 0;
            "string" === typeof i && (i = hr(i)),
              null === i
                ? (n = 1)
                : Array.isArray(i) && (n = 4 === i.length ? i[3] : 1),
              0 === n &&
                ((e = pr(t.size, t.size)), this.drawHitDetectionCanvas_(t, e));
          }
          return e ? e.canvas : this.getImage(1);
        }
        createPath_(t) {
          let e = this.points_;
          const i = this.radius;
          if (e === 1 / 0) t.arc(0, 0, i, 0, 2 * Math.PI);
          else {
            const n = void 0 === this.radius2_ ? i : this.radius2_;
            void 0 !== this.radius2_ && (e *= 2);
            const s = this.angle_ - Math.PI / 2,
              r = (2 * Math.PI) / e;
            for (let o = 0; o < e; o++) {
              const e = s + o * r,
                a = o % 2 === 0 ? i : n;
              t.lineTo(a * Math.cos(e), a * Math.sin(e));
            }
            t.closePath();
          }
        }
        drawHitDetectionCanvas_(t, e) {
          e.translate(t.size / 2, t.size / 2),
            this.createPath_(e),
            (e.fillStyle = Pr),
            e.fill(),
            t.strokeStyle &&
              ((e.strokeStyle = t.strokeStyle),
              (e.lineWidth = t.strokeWidth),
              t.lineDash &&
                (e.setLineDash(t.lineDash),
                (e.lineDashOffset = t.lineDashOffset)),
              (e.lineJoin = t.lineJoin),
              (e.miterLimit = t.miterLimit),
              e.stroke());
        }
        ready() {
          return this.fill_ ? this.fill_.ready() : Promise.resolve();
        }
      }
      const Ur = $r;
      class Hr extends Ur {
        constructor(t) {
          super({
            points: 1 / 0,
            fill: (t = t || { radius: 5 }).fill,
            radius: t.radius,
            stroke: t.stroke,
            scale: void 0 !== t.scale ? t.scale : 1,
            rotation: void 0 !== t.rotation ? t.rotation : 0,
            rotateWithView: void 0 !== t.rotateWithView && t.rotateWithView,
            displacement: void 0 !== t.displacement ? t.displacement : [0, 0],
            declutterMode: t.declutterMode,
          });
        }
        clone() {
          const t = this.getScale(),
            e = new Hr({
              fill: this.getFill() ? this.getFill().clone() : void 0,
              stroke: this.getStroke() ? this.getStroke().clone() : void 0,
              radius: this.getRadius(),
              scale: Array.isArray(t) ? t.slice() : t,
              rotation: this.getRotation(),
              rotateWithView: this.getRotateWithView(),
              displacement: this.getDisplacement().slice(),
              declutterMode: this.getDeclutterMode(),
            });
          return e.setOpacity(this.getOpacity()), e;
        }
        setRadius(t) {
          (this.radius = t), this.render();
        }
      }
      const Kr = Hr;
      class Jr {
        constructor(t) {
          (t = t || {}),
            (this.patternImage_ = null),
            (this.color_ = null),
            void 0 !== t.color && this.setColor(t.color);
        }
        clone() {
          const t = this.getColor();
          return new Jr({ color: Array.isArray(t) ? t.slice() : t || void 0 });
        }
        getColor() {
          return this.color_;
        }
        setColor(t) {
          if (null !== t && "object" === typeof t && "src" in t) {
            const e = br(
              null,
              t.src,
              "anonymous",
              void 0,
              t.offset ? null : t.color ? t.color : null,
              !(t.offset && t.size)
            );
            e.ready().then(() => {
              this.patternImage_ = null;
            }),
              e.getImageState() === Ns.IDLE && e.load(),
              e.getImageState() === Ns.LOADING && (this.patternImage_ = e);
          }
          this.color_ = t;
        }
        loading() {
          return !!this.patternImage_;
        }
        ready() {
          return this.patternImage_
            ? this.patternImage_.ready()
            : Promise.resolve();
        }
      }
      const Qr = Jr;
      class to {
        constructor(t) {
          (t = t || {}),
            (this.color_ = void 0 !== t.color ? t.color : null),
            (this.lineCap_ = t.lineCap),
            (this.lineDash_ = void 0 !== t.lineDash ? t.lineDash : null),
            (this.lineDashOffset_ = t.lineDashOffset),
            (this.lineJoin_ = t.lineJoin),
            (this.miterLimit_ = t.miterLimit),
            (this.width_ = t.width);
        }
        clone() {
          const t = this.getColor();
          return new to({
            color: Array.isArray(t) ? t.slice() : t || void 0,
            lineCap: this.getLineCap(),
            lineDash: this.getLineDash() ? this.getLineDash().slice() : void 0,
            lineDashOffset: this.getLineDashOffset(),
            lineJoin: this.getLineJoin(),
            miterLimit: this.getMiterLimit(),
            width: this.getWidth(),
          });
        }
        getColor() {
          return this.color_;
        }
        getLineCap() {
          return this.lineCap_;
        }
        getLineDash() {
          return this.lineDash_;
        }
        getLineDashOffset() {
          return this.lineDashOffset_;
        }
        getLineJoin() {
          return this.lineJoin_;
        }
        getMiterLimit() {
          return this.miterLimit_;
        }
        getWidth() {
          return this.width_;
        }
        setColor(t) {
          this.color_ = t;
        }
        setLineCap(t) {
          this.lineCap_ = t;
        }
        setLineDash(t) {
          this.lineDash_ = t;
        }
        setLineDashOffset(t) {
          this.lineDashOffset_ = t;
        }
        setLineJoin(t) {
          this.lineJoin_ = t;
        }
        setMiterLimit(t) {
          this.miterLimit_ = t;
        }
        setWidth(t) {
          this.width_ = t;
        }
      }
      const eo = to;
      class io {
        constructor(t) {
          (t = t || {}),
            (this.geometry_ = null),
            (this.geometryFunction_ = oo),
            void 0 !== t.geometry && this.setGeometry(t.geometry),
            (this.fill_ = void 0 !== t.fill ? t.fill : null),
            (this.image_ = void 0 !== t.image ? t.image : null),
            (this.renderer_ = void 0 !== t.renderer ? t.renderer : null),
            (this.hitDetectionRenderer_ =
              void 0 !== t.hitDetectionRenderer
                ? t.hitDetectionRenderer
                : null),
            (this.stroke_ = void 0 !== t.stroke ? t.stroke : null),
            (this.text_ = void 0 !== t.text ? t.text : null),
            (this.zIndex_ = t.zIndex);
        }
        clone() {
          let t = this.getGeometry();
          return (
            t && "object" === typeof t && (t = t.clone()),
            new io({
              geometry: t ?? void 0,
              fill: this.getFill() ? this.getFill().clone() : void 0,
              image: this.getImage() ? this.getImage().clone() : void 0,
              renderer: this.getRenderer() ?? void 0,
              stroke: this.getStroke() ? this.getStroke().clone() : void 0,
              text: this.getText() ? this.getText().clone() : void 0,
              zIndex: this.getZIndex(),
            })
          );
        }
        getRenderer() {
          return this.renderer_;
        }
        setRenderer(t) {
          this.renderer_ = t;
        }
        setHitDetectionRenderer(t) {
          this.hitDetectionRenderer_ = t;
        }
        getHitDetectionRenderer() {
          return this.hitDetectionRenderer_;
        }
        getGeometry() {
          return this.geometry_;
        }
        getGeometryFunction() {
          return this.geometryFunction_;
        }
        getFill() {
          return this.fill_;
        }
        setFill(t) {
          this.fill_ = t;
        }
        getImage() {
          return this.image_;
        }
        setImage(t) {
          this.image_ = t;
        }
        getStroke() {
          return this.stroke_;
        }
        setStroke(t) {
          this.stroke_ = t;
        }
        getText() {
          return this.text_;
        }
        setText(t) {
          this.text_ = t;
        }
        getZIndex() {
          return this.zIndex_;
        }
        setGeometry(t) {
          "function" === typeof t
            ? (this.geometryFunction_ = t)
            : "string" === typeof t
            ? (this.geometryFunction_ = function (e) {
                return e.get(t);
              })
            : t
            ? void 0 !== t &&
              (this.geometryFunction_ = function () {
                return t;
              })
            : (this.geometryFunction_ = oo),
            (this.geometry_ = t);
        }
        setZIndex(t) {
          this.zIndex_ = t;
        }
      }
      let no = null;
      function so(t, e) {
        if (!no) {
          const t = new Qr({ color: "rgba(255,255,255,0.4)" }),
            e = new eo({ color: "#3399CC", width: 1.25 });
          no = [
            new io({
              image: new Kr({ fill: t, stroke: e, radius: 5 }),
              fill: t,
              stroke: e,
            }),
          ];
        }
        return no;
      }
      function ro() {
        const t = {},
          e = [255, 255, 255, 1],
          i = [0, 153, 255, 1];
        return (
          (t.Polygon = [
            new io({ fill: new Qr({ color: [255, 255, 255, 0.5] }) }),
          ]),
          (t.MultiPolygon = t.Polygon),
          (t.LineString = [
            new io({ stroke: new eo({ color: e, width: 5 }) }),
            new io({ stroke: new eo({ color: i, width: 3 }) }),
          ]),
          (t.MultiLineString = t.LineString),
          (t.Circle = t.Polygon.concat(t.LineString)),
          (t.Point = [
            new io({
              image: new Kr({
                radius: 6,
                fill: new Qr({ color: i }),
                stroke: new eo({ color: e, width: 1.5 }),
              }),
              zIndex: 1 / 0,
            }),
          ]),
          (t.MultiPoint = t.Point),
          (t.GeometryCollection = t.Polygon.concat(t.LineString, t.Point)),
          t
        );
      }
      function oo(t) {
        return t.getGeometry();
      }
      const ao = io;
      function lo(t, e, i, n) {
        return void 0 !== i && void 0 !== n
          ? [i / t, n / e]
          : void 0 !== i
          ? i / t
          : void 0 !== n
          ? n / e
          : 1;
      }
      class ho extends Ys {
        constructor(t) {
          const e = void 0 !== (t = t || {}).opacity ? t.opacity : 1,
            i = void 0 !== t.rotation ? t.rotation : 0,
            n = void 0 !== t.scale ? t.scale : 1,
            s = void 0 !== t.rotateWithView && t.rotateWithView;
          super({
            opacity: e,
            rotation: i,
            scale: n,
            displacement: void 0 !== t.displacement ? t.displacement : [0, 0],
            rotateWithView: s,
            declutterMode: t.declutterMode,
          }),
            (this.anchor_ = void 0 !== t.anchor ? t.anchor : [0.5, 0.5]),
            (this.normalizedAnchor_ = null),
            (this.anchorOrigin_ =
              void 0 !== t.anchorOrigin ? t.anchorOrigin : "top-left"),
            (this.anchorXUnits_ =
              void 0 !== t.anchorXUnits ? t.anchorXUnits : "fraction"),
            (this.anchorYUnits_ =
              void 0 !== t.anchorYUnits ? t.anchorYUnits : "fraction"),
            (this.crossOrigin_ =
              void 0 !== t.crossOrigin ? t.crossOrigin : null);
          const r = void 0 !== t.img ? t.img : null;
          let o,
            a = t.src;
          if (
            (D(
              !(void 0 !== a && r),
              "`image` and `src` cannot be provided at the same time"
            ),
            (void 0 !== a && 0 !== a.length) || !r || (a = r.src || F(r)),
            D(
              void 0 !== a && a.length > 0,
              "A defined and non-empty `src` or `image` must be provided"
            ),
            D(
              !(
                (void 0 !== t.width || void 0 !== t.height) &&
                void 0 !== t.scale
              ),
              "`width` or `height` cannot be provided together with `scale`"
            ),
            void 0 !== t.src
              ? (o = Ns.IDLE)
              : void 0 !== r &&
                (o =
                  "complete" in r
                    ? r.complete
                      ? r.src
                        ? Ns.LOADED
                        : Ns.IDLE
                      : Ns.LOADING
                    : Ns.LOADED),
            (this.color_ = void 0 !== t.color ? hr(t.color) : null),
            (this.iconImage_ = br(r, a, this.crossOrigin_, o, this.color_)),
            (this.offset_ = void 0 !== t.offset ? t.offset : [0, 0]),
            (this.offsetOrigin_ =
              void 0 !== t.offsetOrigin ? t.offsetOrigin : "top-left"),
            (this.origin_ = null),
            (this.size_ = void 0 !== t.size ? t.size : null),
            this.initialOptions_,
            void 0 !== t.width || void 0 !== t.height)
          ) {
            let e, i;
            if (t.size) [e, i] = t.size;
            else {
              const n = this.getImage(1);
              if (n.width && n.height) (e = n.width), (i = n.height);
              else if (n instanceof HTMLImageElement) {
                this.initialOptions_ = t;
                const e = () => {
                  if ((this.unlistenImageChange(e), !this.initialOptions_))
                    return;
                  const i = this.iconImage_.getSize();
                  this.setScale(lo(i[0], i[1], t.width, t.height));
                };
                return void this.listenImageChange(e);
              }
            }
            void 0 !== e && this.setScale(lo(e, i, t.width, t.height));
          }
        }
        clone() {
          let t, e, i;
          return (
            this.initialOptions_
              ? ((e = this.initialOptions_.width),
                (i = this.initialOptions_.height))
              : ((t = this.getScale()), (t = Array.isArray(t) ? t.slice() : t)),
            new ho({
              anchor: this.anchor_.slice(),
              anchorOrigin: this.anchorOrigin_,
              anchorXUnits: this.anchorXUnits_,
              anchorYUnits: this.anchorYUnits_,
              color:
                this.color_ && this.color_.slice
                  ? this.color_.slice()
                  : this.color_ || void 0,
              crossOrigin: this.crossOrigin_,
              offset: this.offset_.slice(),
              offsetOrigin: this.offsetOrigin_,
              opacity: this.getOpacity(),
              rotateWithView: this.getRotateWithView(),
              rotation: this.getRotation(),
              scale: t,
              width: e,
              height: i,
              size: null !== this.size_ ? this.size_.slice() : void 0,
              src: this.getSrc(),
              displacement: this.getDisplacement().slice(),
              declutterMode: this.getDeclutterMode(),
            })
          );
        }
        getAnchor() {
          let t = this.normalizedAnchor_;
          if (!t) {
            t = this.anchor_;
            const e = this.getSize();
            if (
              "fraction" == this.anchorXUnits_ ||
              "fraction" == this.anchorYUnits_
            ) {
              if (!e) return null;
              (t = this.anchor_.slice()),
                "fraction" == this.anchorXUnits_ && (t[0] *= e[0]),
                "fraction" == this.anchorYUnits_ && (t[1] *= e[1]);
            }
            if ("top-left" != this.anchorOrigin_) {
              if (!e) return null;
              t === this.anchor_ && (t = this.anchor_.slice()),
                ("top-right" != this.anchorOrigin_ &&
                  "bottom-right" != this.anchorOrigin_) ||
                  (t[0] = -t[0] + e[0]),
                ("bottom-left" != this.anchorOrigin_ &&
                  "bottom-right" != this.anchorOrigin_) ||
                  (t[1] = -t[1] + e[1]);
            }
            this.normalizedAnchor_ = t;
          }
          const e = this.getDisplacement(),
            i = this.getScaleArray();
          return [t[0] - e[0] / i[0], t[1] + e[1] / i[1]];
        }
        setAnchor(t) {
          (this.anchor_ = t), (this.normalizedAnchor_ = null);
        }
        getColor() {
          return this.color_;
        }
        getImage(t) {
          return this.iconImage_.getImage(t);
        }
        getPixelRatio(t) {
          return this.iconImage_.getPixelRatio(t);
        }
        getImageSize() {
          return this.iconImage_.getSize();
        }
        getImageState() {
          return this.iconImage_.getImageState();
        }
        getHitDetectionImage() {
          return this.iconImage_.getHitDetectionImage();
        }
        getOrigin() {
          if (this.origin_) return this.origin_;
          let t = this.offset_;
          if ("top-left" != this.offsetOrigin_) {
            const e = this.getSize(),
              i = this.iconImage_.getSize();
            if (!e || !i) return null;
            (t = t.slice()),
              ("top-right" != this.offsetOrigin_ &&
                "bottom-right" != this.offsetOrigin_) ||
                (t[0] = i[0] - e[0] - t[0]),
              ("bottom-left" != this.offsetOrigin_ &&
                "bottom-right" != this.offsetOrigin_) ||
                (t[1] = i[1] - e[1] - t[1]);
          }
          return (this.origin_ = t), this.origin_;
        }
        getSrc() {
          return this.iconImage_.getSrc();
        }
        getSize() {
          return this.size_ ? this.size_ : this.iconImage_.getSize();
        }
        getWidth() {
          const t = this.getScaleArray();
          return this.size_
            ? this.size_[0] * t[0]
            : this.iconImage_.getImageState() == Ns.LOADED
            ? this.iconImage_.getSize()[0] * t[0]
            : void 0;
        }
        getHeight() {
          const t = this.getScaleArray();
          return this.size_
            ? this.size_[1] * t[1]
            : this.iconImage_.getImageState() == Ns.LOADED
            ? this.iconImage_.getSize()[1] * t[1]
            : void 0;
        }
        setScale(t) {
          delete this.initialOptions_, super.setScale(t);
        }
        listenImageChange(t) {
          this.iconImage_.addEventListener(w, t);
        }
        load() {
          this.iconImage_.load();
        }
        unlistenImageChange(t) {
          this.iconImage_.removeEventListener(w, t);
        }
        ready() {
          return this.iconImage_.ready();
        }
      }
      const co = ho;
      class uo {
        constructor(t) {
          (t = t || {}),
            (this.font_ = t.font),
            (this.rotation_ = t.rotation),
            (this.rotateWithView_ = t.rotateWithView),
            (this.scale_ = t.scale),
            (this.scaleArray_ = Ws(void 0 !== t.scale ? t.scale : 1)),
            (this.text_ = t.text),
            (this.textAlign_ = t.textAlign),
            (this.justify_ = t.justify),
            (this.repeat_ = t.repeat),
            (this.textBaseline_ = t.textBaseline),
            (this.fill_ =
              void 0 !== t.fill ? t.fill : new Qr({ color: "#333" })),
            (this.maxAngle_ = void 0 !== t.maxAngle ? t.maxAngle : Math.PI / 4),
            (this.placement_ = void 0 !== t.placement ? t.placement : "point"),
            (this.overflow_ = !!t.overflow),
            (this.stroke_ = void 0 !== t.stroke ? t.stroke : null),
            (this.offsetX_ = void 0 !== t.offsetX ? t.offsetX : 0),
            (this.offsetY_ = void 0 !== t.offsetY ? t.offsetY : 0),
            (this.backgroundFill_ = t.backgroundFill ? t.backgroundFill : null),
            (this.backgroundStroke_ = t.backgroundStroke
              ? t.backgroundStroke
              : null),
            (this.padding_ = void 0 === t.padding ? null : t.padding),
            (this.declutterMode_ = t.declutterMode);
        }
        clone() {
          const t = this.getScale();
          return new uo({
            font: this.getFont(),
            placement: this.getPlacement(),
            repeat: this.getRepeat(),
            maxAngle: this.getMaxAngle(),
            overflow: this.getOverflow(),
            rotation: this.getRotation(),
            rotateWithView: this.getRotateWithView(),
            scale: Array.isArray(t) ? t.slice() : t,
            text: this.getText(),
            textAlign: this.getTextAlign(),
            justify: this.getJustify(),
            textBaseline: this.getTextBaseline(),
            fill: this.getFill() ? this.getFill().clone() : void 0,
            stroke: this.getStroke() ? this.getStroke().clone() : void 0,
            offsetX: this.getOffsetX(),
            offsetY: this.getOffsetY(),
            backgroundFill: this.getBackgroundFill()
              ? this.getBackgroundFill().clone()
              : void 0,
            backgroundStroke: this.getBackgroundStroke()
              ? this.getBackgroundStroke().clone()
              : void 0,
            padding: this.getPadding() || void 0,
            declutterMode: this.getDeclutterMode(),
          });
        }
        getOverflow() {
          return this.overflow_;
        }
        getFont() {
          return this.font_;
        }
        getMaxAngle() {
          return this.maxAngle_;
        }
        getPlacement() {
          return this.placement_;
        }
        getRepeat() {
          return this.repeat_;
        }
        getOffsetX() {
          return this.offsetX_;
        }
        getOffsetY() {
          return this.offsetY_;
        }
        getFill() {
          return this.fill_;
        }
        getRotateWithView() {
          return this.rotateWithView_;
        }
        getRotation() {
          return this.rotation_;
        }
        getScale() {
          return this.scale_;
        }
        getScaleArray() {
          return this.scaleArray_;
        }
        getStroke() {
          return this.stroke_;
        }
        getText() {
          return this.text_;
        }
        getTextAlign() {
          return this.textAlign_;
        }
        getJustify() {
          return this.justify_;
        }
        getTextBaseline() {
          return this.textBaseline_;
        }
        getBackgroundFill() {
          return this.backgroundFill_;
        }
        getBackgroundStroke() {
          return this.backgroundStroke_;
        }
        getPadding() {
          return this.padding_;
        }
        getDeclutterMode() {
          return this.declutterMode_;
        }
        setOverflow(t) {
          this.overflow_ = t;
        }
        setFont(t) {
          this.font_ = t;
        }
        setMaxAngle(t) {
          this.maxAngle_ = t;
        }
        setOffsetX(t) {
          this.offsetX_ = t;
        }
        setOffsetY(t) {
          this.offsetY_ = t;
        }
        setPlacement(t) {
          this.placement_ = t;
        }
        setRepeat(t) {
          this.repeat_ = t;
        }
        setRotateWithView(t) {
          this.rotateWithView_ = t;
        }
        setFill(t) {
          this.fill_ = t;
        }
        setRotation(t) {
          this.rotation_ = t;
        }
        setScale(t) {
          (this.scale_ = t), (this.scaleArray_ = Ws(void 0 !== t ? t : 1));
        }
        setStroke(t) {
          this.stroke_ = t;
        }
        setText(t) {
          this.text_ = t;
        }
        setTextAlign(t) {
          this.textAlign_ = t;
        }
        setJustify(t) {
          this.justify_ = t;
        }
        setTextBaseline(t) {
          this.textBaseline_ = t;
        }
        setBackgroundFill(t) {
          this.backgroundFill_ = t;
        }
        setBackgroundStroke(t) {
          this.backgroundStroke_ = t;
        }
        setPadding(t) {
          this.padding_ = t;
        }
      }
      const go = uo;
      let fo = 0;
      const po = 1 << fo++,
        mo = 1 << fo++,
        _o = 1 << fo++,
        yo = 1 << fo++,
        xo = 1 << fo++,
        vo = 1 << fo++,
        wo = Math.pow(2, 6) - 1,
        So = {
          [po]: "boolean",
          [mo]: "number",
          [_o]: "string",
          [yo]: "color",
          [xo]: "number[]",
          [vo]: "size",
        },
        Co = Object.keys(So).map(Number).sort(h);
      function bo(t) {
        const e = [];
        for (const i of Co) ko(t, i) && e.push(So[i]);
        return 0 === e.length
          ? "untyped"
          : e.length < 3
          ? e.join(" or ")
          : e.slice(0, -1).join(", ") + ", or " + e[e.length - 1];
      }
      function ko(t, e) {
        return (t & e) === e;
      }
      function Mo(t, e) {
        return t === e;
      }
      class Io {
        constructor(t, e) {
          if (
            !(function (t) {
              return t in So;
            })(t)
          )
            throw new Error(
              `literal expressions must have a specific type, got ${bo(t)}`
            );
          (this.type = t), (this.value = e);
        }
      }
      class Eo {
        constructor(t, e, ...i) {
          (this.type = t), (this.operator = e), (this.args = i);
        }
      }
      function Ro() {
        return {
          variables: new Set(),
          properties: new Set(),
          featureId: !1,
          geometryType: !1,
        };
      }
      function Po(t, e, i) {
        switch (typeof t) {
          case "boolean":
            if (Mo(e, _o)) return new Io(_o, t ? "true" : "false");
            if (!ko(e, po))
              throw new Error(`got a boolean, but expected ${bo(e)}`);
            return new Io(po, t);
          case "number":
            if (Mo(e, vo)) return new Io(vo, Ws(t));
            if (Mo(e, po)) return new Io(po, !!t);
            if (Mo(e, _o)) return new Io(_o, t.toString());
            if (!ko(e, mo))
              throw new Error(`got a number, but expected ${bo(e)}`);
            return new Io(mo, t);
          case "string":
            if (Mo(e, yo)) return new Io(yo, lr(t));
            if (Mo(e, po)) return new Io(po, !!t);
            if (!ko(e, _o))
              throw new Error(`got a string, but expected ${bo(e)}`);
            return new Io(_o, t);
        }
        if (!Array.isArray(t))
          throw new Error("expression must be an array or a primitive value");
        if (0 === t.length) throw new Error("empty expression");
        if ("string" === typeof t[0])
          return (function (t, e, i) {
            const n = t[0],
              s = Lo[n];
            if (!s) throw new Error(`unknown operator: ${n}`);
            return s(t, e, i);
          })(t, e, i);
        for (const n of t)
          if ("number" !== typeof n)
            throw new Error("expected an array of numbers");
        if (Mo(e, vo)) {
          if (2 !== t.length)
            throw new Error(
              `expected an array of two values for a size, got ${t.length}`
            );
          return new Io(vo, t);
        }
        if (Mo(e, yo)) {
          if (3 === t.length) return new Io(yo, [...t, 1]);
          if (4 === t.length) return new Io(yo, t);
          throw new Error(
            `expected an array of 3 or 4 values for a color, got ${t.length}`
          );
        }
        if (!ko(e, xo))
          throw new Error(`got an array of numbers, but expected ${bo(e)}`);
        return new Io(xo, t);
      }
      const Fo = {
          Get: "get",
          Var: "var",
          Concat: "concat",
          GeometryType: "geometry-type",
          LineMetric: "line-metric",
          Any: "any",
          All: "all",
          Not: "!",
          Resolution: "resolution",
          Zoom: "zoom",
          Time: "time",
          Equal: "==",
          NotEqual: "!=",
          GreaterThan: ">",
          GreaterThanOrEqualTo: ">=",
          LessThan: "<",
          LessThanOrEqualTo: "<=",
          Multiply: "*",
          Divide: "/",
          Add: "+",
          Subtract: "-",
          Clamp: "clamp",
          Mod: "%",
          Pow: "^",
          Abs: "abs",
          Floor: "floor",
          Ceil: "ceil",
          Round: "round",
          Sin: "sin",
          Cos: "cos",
          Atan: "atan",
          Sqrt: "sqrt",
          Match: "match",
          Between: "between",
          Interpolate: "interpolate",
          Coalesce: "coalesce",
          Case: "case",
          In: "in",
          Number: "number",
          String: "string",
          Array: "array",
          Color: "color",
          Id: "id",
          Band: "band",
          Palette: "palette",
          ToString: "to-string",
          Has: "has",
        },
        Lo = {
          [Fo.Get]: Zo(Ao(1, 1 / 0), To),
          [Fo.Var]: Zo(Ao(1, 1), function (t, e, i) {
            const n = t[1];
            if ("string" !== typeof n)
              throw new Error("expected a string argument for var operation");
            return i.variables.add(n), [new Io(_o, n)];
          }),
          [Fo.Has]: Zo(Ao(1, 1 / 0), To),
          [Fo.Id]: Zo(function (t, e, i) {
            i.featureId = !0;
          }, Do),
          [Fo.Concat]: Zo(Ao(2, 1 / 0), jo(_o)),
          [Fo.GeometryType]: Zo(function (t, e, i) {
            i.geometryType = !0;
          }, Do),
          [Fo.LineMetric]: Zo(Do),
          [Fo.Resolution]: Zo(Do),
          [Fo.Zoom]: Zo(Do),
          [Fo.Time]: Zo(Do),
          [Fo.Any]: Zo(Ao(2, 1 / 0), jo(po)),
          [Fo.All]: Zo(Ao(2, 1 / 0), jo(po)),
          [Fo.Not]: Zo(Ao(1, 1), jo(po)),
          [Fo.Equal]: Zo(Ao(2, 2), jo(wo)),
          [Fo.NotEqual]: Zo(Ao(2, 2), jo(wo)),
          [Fo.GreaterThan]: Zo(Ao(2, 2), jo(mo)),
          [Fo.GreaterThanOrEqualTo]: Zo(Ao(2, 2), jo(mo)),
          [Fo.LessThan]: Zo(Ao(2, 2), jo(mo)),
          [Fo.LessThanOrEqualTo]: Zo(Ao(2, 2), jo(mo)),
          [Fo.Multiply]: Zo(Ao(2, 1 / 0), Oo),
          [Fo.Coalesce]: Zo(Ao(2, 1 / 0), Oo),
          [Fo.Divide]: Zo(Ao(2, 2), jo(mo)),
          [Fo.Add]: Zo(Ao(2, 1 / 0), jo(mo)),
          [Fo.Subtract]: Zo(Ao(2, 2), jo(mo)),
          [Fo.Clamp]: Zo(Ao(3, 3), jo(mo)),
          [Fo.Mod]: Zo(Ao(2, 2), jo(mo)),
          [Fo.Pow]: Zo(Ao(2, 2), jo(mo)),
          [Fo.Abs]: Zo(Ao(1, 1), jo(mo)),
          [Fo.Floor]: Zo(Ao(1, 1), jo(mo)),
          [Fo.Ceil]: Zo(Ao(1, 1), jo(mo)),
          [Fo.Round]: Zo(Ao(1, 1), jo(mo)),
          [Fo.Sin]: Zo(Ao(1, 1), jo(mo)),
          [Fo.Cos]: Zo(Ao(1, 1), jo(mo)),
          [Fo.Atan]: Zo(Ao(1, 2), jo(mo)),
          [Fo.Sqrt]: Zo(Ao(1, 1), jo(mo)),
          [Fo.Match]: Zo(Ao(4, 1 / 0), Go, function (t, e, i) {
            const n = t.length - 1,
              s = _o | mo | po,
              r = Po(t[1], s, i),
              o = Po(t[t.length - 1], e, i),
              a = new Array(n - 2);
            for (let h = 0; h < n - 2; h += 2) {
              try {
                const e = Po(t[h + 2], r.type, i);
                a[h] = e;
              } catch (l) {
                throw new Error(
                  `failed to parse argument ${h + 1} of match expression: ${
                    l.message
                  }`
                );
              }
              try {
                const e = Po(t[h + 3], o.type, i);
                a[h + 1] = e;
              } catch (l) {
                throw new Error(
                  `failed to parse argument ${h + 2} of match expression: ${
                    l.message
                  }`
                );
              }
            }
            return [r, ...a, o];
          }),
          [Fo.Between]: Zo(Ao(3, 3), jo(mo)),
          [Fo.Interpolate]: Zo(Ao(6, 1 / 0), Go, function (t, e, i) {
            const n = t[1];
            let s;
            switch (n[0]) {
              case "linear":
                s = 1;
                break;
              case "exponential":
                const t = n[1];
                if ("number" !== typeof t || t <= 0)
                  throw new Error(
                    `expected a number base for exponential interpolation, got ${JSON.stringify(
                      t
                    )} instead`
                  );
                s = t;
                break;
              default:
                throw new Error(
                  `invalid interpolation type: ${JSON.stringify(n)}`
                );
            }
            const r = new Io(mo, s);
            let o;
            try {
              o = Po(t[2], mo, i);
            } catch (l) {
              throw new Error(
                `failed to parse argument 1 in interpolate expression: ${l.message}`
              );
            }
            const a = new Array(t.length - 3);
            for (let h = 0; h < a.length; h += 2) {
              try {
                const e = Po(t[h + 3], mo, i);
                a[h] = e;
              } catch (l) {
                throw new Error(
                  `failed to parse argument ${
                    h + 2
                  } for interpolate expression: ${l.message}`
                );
              }
              try {
                const n = Po(t[h + 4], e, i);
                a[h + 1] = n;
              } catch (l) {
                throw new Error(
                  `failed to parse argument ${
                    h + 3
                  } for interpolate expression: ${l.message}`
                );
              }
            }
            return [r, o, ...a];
          }),
          [Fo.Case]: Zo(
            Ao(3, 1 / 0),
            function (t, e, i) {
              const n = t[0],
                s = t.length - 1;
              if (s % 2 === 0)
                throw new Error(
                  `expected an odd number of arguments for ${n}, got ${s} instead`
                );
            },
            function (t, e, i) {
              const n = Po(t[t.length - 1], e, i),
                s = new Array(t.length - 1);
              for (let o = 0; o < s.length - 1; o += 2) {
                try {
                  const e = Po(t[o + 1], po, i);
                  s[o] = e;
                } catch (r) {
                  throw new Error(
                    `failed to parse argument ${o} of case expression: ${r.message}`
                  );
                }
                try {
                  const e = Po(t[o + 2], n.type, i);
                  s[o + 1] = e;
                } catch (r) {
                  throw new Error(
                    `failed to parse argument ${o + 1} of case expression: ${
                      r.message
                    }`
                  );
                }
              }
              return (s[s.length - 1] = n), s;
            }
          ),
          [Fo.In]: Zo(Ao(2, 2), function (t, e, i) {
            let n,
              s = t[2];
            if (!Array.isArray(s))
              throw new Error(
                'the second argument for the "in" operator must be an array'
              );
            if ("string" === typeof s[0]) {
              if ("literal" !== s[0])
                throw new Error(
                  'for the "in" operator, a string array should be wrapped in a "literal" operator to disambiguate from expressions'
                );
              if (!Array.isArray(s[1]))
                throw new Error(
                  'failed to parse "in" expression: the literal operator must be followed by an array'
                );
              (s = s[1]), (n = _o);
            } else n = mo;
            const r = new Array(s.length);
            for (let a = 0; a < r.length; a++)
              try {
                const t = Po(s[a], n, i);
                r[a] = t;
              } catch (o) {
                throw new Error(
                  `failed to parse haystack item ${a} for "in" expression: ${o.message}`
                );
              }
            return [Po(t[1], n, i), ...r];
          }),
          [Fo.Number]: Zo(Ao(1, 1 / 0), jo(wo)),
          [Fo.String]: Zo(Ao(1, 1 / 0), jo(wo)),
          [Fo.Array]: Zo(Ao(1, 1 / 0), jo(mo)),
          [Fo.Color]: Zo(Ao(1, 4), jo(mo)),
          [Fo.Band]: Zo(Ao(1, 3), jo(mo)),
          [Fo.Palette]: Zo(Ao(2, 2), function (t, e, i) {
            let n;
            try {
              n = Po(t[1], mo, i);
            } catch (o) {
              throw new Error(
                `failed to parse first argument in palette expression: ${o.message}`
              );
            }
            const s = t[2];
            if (!Array.isArray(s))
              throw new Error(
                "the second argument of palette must be an array"
              );
            const r = new Array(s.length);
            for (let a = 0; a < r.length; a++) {
              let t;
              try {
                t = Po(s[a], yo, i);
              } catch (o) {
                throw new Error(
                  `failed to parse color at index ${a} in palette expression: ${o.message}`
                );
              }
              if (!(t instanceof Io))
                throw new Error(
                  `the palette color at index ${a} must be a literal value`
                );
              r[a] = t;
            }
            return [n, ...r];
          }),
          [Fo.ToString]: Zo(Ao(1, 1), jo(po | mo | _o | yo)),
        };
      function To(t, e, i) {
        const n = t.length - 1,
          s = new Array(n);
        for (let r = 0; r < n; ++r) {
          const e = t[r + 1];
          switch (typeof e) {
            case "number":
              s[r] = new Io(mo, e);
              break;
            case "string":
              s[r] = new Io(_o, e);
              break;
            default:
              throw new Error(
                `expected a string key or numeric array index for a get operation, got ${e}`
              );
          }
          0 === r && i.properties.add(String(e));
        }
        return s;
      }
      function Do(t, e, i) {
        const n = t[0];
        if (1 !== t.length)
          throw new Error(`expected no arguments for ${n} operation`);
        return [];
      }
      function Ao(t, e) {
        return function (i, n, s) {
          const r = i[0],
            o = i.length - 1;
          if (t === e) {
            if (o !== t) {
              throw new Error(
                `expected ${t} argument${1 === t ? "" : "s"} for ${r}, got ${o}`
              );
            }
          } else if (o < t || o > e) {
            throw new Error(
              `expected ${
                e === 1 / 0 ? `${t} or more` : `${t} to ${e}`
              } arguments for ${r}, got ${o}`
            );
          }
        };
      }
      function Oo(t, e, i) {
        const n = t.length - 1,
          s = new Array(n);
        for (let r = 0; r < n; ++r) {
          const n = Po(t[r + 1], e, i);
          s[r] = n;
        }
        return s;
      }
      function jo(t) {
        return function (e, i, n) {
          const s = e.length - 1,
            r = new Array(s);
          for (let o = 0; o < s; ++o) {
            const i = Po(e[o + 1], t, n);
            r[o] = i;
          }
          return r;
        };
      }
      function Go(t, e, i) {
        const n = t[0],
          s = t.length - 1;
        if (s % 2 === 1)
          throw new Error(
            `expected an even number of arguments for operation ${n}, got ${s} instead`
          );
      }
      function Zo(...t) {
        return function (e, i, n) {
          const s = e[0];
          let r;
          for (let o = 0; o < t.length; o++) {
            const s = t[o](e, i, n);
            if (o == t.length - 1) {
              if (!s)
                throw new Error(
                  "expected last argument validator to return the parsed args"
                );
              r = s;
            }
          }
          return new Eo(i, s, ...r);
        };
      }
      function zo(t) {
        if (!t) return "";
        const e = t.getType();
        switch (e) {
          case "Point":
          case "LineString":
          case "Polygon":
            return e;
          case "MultiPoint":
          case "MultiLineString":
          case "MultiPolygon":
            return e.substring(5);
          case "Circle":
            return "Polygon";
          case "GeometryCollection":
            return zo(t.getGeometries()[0]);
          default:
            return "";
        }
      }
      function Bo(t, e, i) {
        return No(Po(t, e, i), i);
      }
      function No(t, e) {
        if (t instanceof Io) {
          if (t.type === yo && "string" === typeof t.value) {
            const e = lr(t.value);
            return function () {
              return e;
            };
          }
          return function () {
            return t.value;
          };
        }
        const i = t.operator;
        switch (i) {
          case Fo.Number:
          case Fo.String:
          case Fo.Coalesce:
            return (function (t, e) {
              const i = t.operator,
                n = t.args.length,
                s = new Array(n);
              for (let r = 0; r < n; ++r) s[r] = No(t.args[r], e);
              switch (i) {
                case Fo.Coalesce:
                  return (t) => {
                    for (let e = 0; e < n; ++e) {
                      const i = s[e](t);
                      if ("undefined" !== typeof i && null !== i) return i;
                    }
                    throw new Error(
                      "Expected one of the values to be non-null"
                    );
                  };
                case Fo.Number:
                case Fo.String:
                  return (t) => {
                    for (let e = 0; e < n; ++e) {
                      const n = s[e](t);
                      if (typeof n === i) return n;
                    }
                    throw new Error(`Expected one of the values to be a ${i}`);
                  };
                default:
                  throw new Error(`Unsupported assertion operator ${i}`);
              }
            })(t, e);
          case Fo.Get:
          case Fo.Var:
          case Fo.Has:
            return (function (t, e) {
              const i = t.args[0],
                n = i.value;
              switch (t.operator) {
                case Fo.Get:
                  return (e) => {
                    const i = t.args;
                    let s = e.properties[n];
                    for (let t = 1, n = i.length; t < n; ++t) {
                      s = s[i[t].value];
                    }
                    return s;
                  };
                case Fo.Var:
                  return (t) => t.variables[n];
                case Fo.Has:
                  return (e) => {
                    const i = t.args;
                    if (!(n in e.properties)) return !1;
                    let s = e.properties[n];
                    for (let t = 1, n = i.length; t < n; ++t) {
                      const e = i[t].value;
                      if (!s || !Object.hasOwn(s, e)) return !1;
                      s = s[e];
                    }
                    return !0;
                  };
                default:
                  throw new Error(
                    `Unsupported accessor operator ${t.operator}`
                  );
              }
            })(t);
          case Fo.Id:
            return (t) => t.featureId;
          case Fo.GeometryType:
            return (t) => t.geometryType;
          case Fo.Concat: {
            const i = t.args.map((t) => No(t, e));
            return (t) => "".concat(...i.map((e) => e(t).toString()));
          }
          case Fo.Resolution:
            return (t) => t.resolution;
          case Fo.Any:
          case Fo.All:
          case Fo.Between:
          case Fo.In:
          case Fo.Not:
            return (function (t, e) {
              const i = t.operator,
                n = t.args.length,
                s = new Array(n);
              for (let r = 0; r < n; ++r) s[r] = No(t.args[r], e);
              switch (i) {
                case Fo.Any:
                  return (t) => {
                    for (let e = 0; e < n; ++e) if (s[e](t)) return !0;
                    return !1;
                  };
                case Fo.All:
                  return (t) => {
                    for (let e = 0; e < n; ++e) if (!s[e](t)) return !1;
                    return !0;
                  };
                case Fo.Between:
                  return (t) => {
                    const e = s[0](t),
                      i = s[1](t),
                      n = s[2](t);
                    return e >= i && e <= n;
                  };
                case Fo.In:
                  return (t) => {
                    const e = s[0](t);
                    for (let i = 1; i < n; ++i) if (e === s[i](t)) return !0;
                    return !1;
                  };
                case Fo.Not:
                  return (t) => !s[0](t);
                default:
                  throw new Error(`Unsupported logical operator ${i}`);
              }
            })(t, e);
          case Fo.Equal:
          case Fo.NotEqual:
          case Fo.LessThan:
          case Fo.LessThanOrEqualTo:
          case Fo.GreaterThan:
          case Fo.GreaterThanOrEqualTo:
            return (function (t, e) {
              const i = t.operator,
                n = No(t.args[0], e),
                s = No(t.args[1], e);
              switch (i) {
                case Fo.Equal:
                  return (t) => n(t) === s(t);
                case Fo.NotEqual:
                  return (t) => n(t) !== s(t);
                case Fo.LessThan:
                  return (t) => n(t) < s(t);
                case Fo.LessThanOrEqualTo:
                  return (t) => n(t) <= s(t);
                case Fo.GreaterThan:
                  return (t) => n(t) > s(t);
                case Fo.GreaterThanOrEqualTo:
                  return (t) => n(t) >= s(t);
                default:
                  throw new Error(`Unsupported comparison operator ${i}`);
              }
            })(t, e);
          case Fo.Multiply:
          case Fo.Divide:
          case Fo.Add:
          case Fo.Subtract:
          case Fo.Clamp:
          case Fo.Mod:
          case Fo.Pow:
          case Fo.Abs:
          case Fo.Floor:
          case Fo.Ceil:
          case Fo.Round:
          case Fo.Sin:
          case Fo.Cos:
          case Fo.Atan:
          case Fo.Sqrt:
            return (function (t, e) {
              const i = t.operator,
                n = t.args.length,
                s = new Array(n);
              for (let r = 0; r < n; ++r) s[r] = No(t.args[r], e);
              switch (i) {
                case Fo.Multiply:
                  return (t) => {
                    let e = 1;
                    for (let i = 0; i < n; ++i) e *= s[i](t);
                    return e;
                  };
                case Fo.Divide:
                  return (t) => s[0](t) / s[1](t);
                case Fo.Add:
                  return (t) => {
                    let e = 0;
                    for (let i = 0; i < n; ++i) e += s[i](t);
                    return e;
                  };
                case Fo.Subtract:
                  return (t) => s[0](t) - s[1](t);
                case Fo.Clamp:
                  return (t) => {
                    const e = s[0](t),
                      i = s[1](t);
                    if (e < i) return i;
                    const n = s[2](t);
                    return e > n ? n : e;
                  };
                case Fo.Mod:
                  return (t) => s[0](t) % s[1](t);
                case Fo.Pow:
                  return (t) => Math.pow(s[0](t), s[1](t));
                case Fo.Abs:
                  return (t) => Math.abs(s[0](t));
                case Fo.Floor:
                  return (t) => Math.floor(s[0](t));
                case Fo.Ceil:
                  return (t) => Math.ceil(s[0](t));
                case Fo.Round:
                  return (t) => Math.round(s[0](t));
                case Fo.Sin:
                  return (t) => Math.sin(s[0](t));
                case Fo.Cos:
                  return (t) => Math.cos(s[0](t));
                case Fo.Atan:
                  return 2 === n
                    ? (t) => Math.atan2(s[0](t), s[1](t))
                    : (t) => Math.atan(s[0](t));
                case Fo.Sqrt:
                  return (t) => Math.sqrt(s[0](t));
                default:
                  throw new Error(`Unsupported numeric operator ${i}`);
              }
            })(t, e);
          case Fo.Case:
            return (function (t, e) {
              const i = t.args.length,
                n = new Array(i);
              for (let s = 0; s < i; ++s) n[s] = No(t.args[s], e);
              return (t) => {
                for (let e = 0; e < i - 1; e += 2) {
                  if (n[e](t)) return n[e + 1](t);
                }
                return n[i - 1](t);
              };
            })(t, e);
          case Fo.Match:
            return (function (t, e) {
              const i = t.args.length,
                n = new Array(i);
              for (let s = 0; s < i; ++s) n[s] = No(t.args[s], e);
              return (t) => {
                const e = n[0](t);
                for (let s = 1; s < i; s += 2)
                  if (e === n[s](t)) return n[s + 1](t);
                return n[i - 1](t);
              };
            })(t, e);
          case Fo.Interpolate:
            return (function (t, e) {
              const i = t.args.length,
                n = new Array(i);
              for (let s = 0; s < i; ++s) n[s] = No(t.args[s], e);
              return (t) => {
                const e = n[0](t),
                  s = n[1](t);
                let r, o;
                for (let a = 2; a < i; a += 2) {
                  const i = n[a](t);
                  let l = n[a + 1](t);
                  const h = Array.isArray(l);
                  if ((h && (l = or(l)), i >= s))
                    return 2 === a
                      ? l
                      : h
                      ? Xo(e, s, r, o, i, l)
                      : Wo(e, s, r, o, i, l);
                  (r = i), (o = l);
                }
                return o;
              };
            })(t, e);
          case Fo.ToString:
            return (function (t, e) {
              const i = t.operator,
                n = t.args.length,
                s = new Array(n);
              for (let r = 0; r < n; ++r) s[r] = No(t.args[r], e);
              if (i === Fo.ToString)
                return (e) => {
                  const i = s[0](e);
                  return t.args[0].type === yo ? ur(i) : i.toString();
                };
              throw new Error(`Unsupported convert operator ${i}`);
            })(t, e);
          default:
            throw new Error(`Unsupported operator ${i}`);
        }
      }
      function Wo(t, e, i, n, s, r) {
        const o = s - i;
        if (0 === o) return n;
        const a = e - i;
        return (
          n +
          (1 === t ? a / o : (Math.pow(t, a) - 1) / (Math.pow(t, o) - 1)) *
            (r - n)
        );
      }
      function Xo(t, e, i, n, s, r) {
        if (0 === s - i) return n;
        const o = ar(n),
          a = ar(r);
        let l = a[2] - o[2];
        l > 180 ? (l -= 360) : l < -180 && (l += 360);
        return cr(
          (function (t) {
            const e = $s.rgb(Ks.xyz(t));
            return (e[3] = t[3]), e;
          })([
            Wo(t, e, i, o[0], s, a[0]),
            Wo(t, e, i, o[1], s, a[1]),
            o[2] + Wo(t, e, i, 0, s, l),
            Wo(t, e, i, n[3], s, r[3]),
          ])
        );
      }
      function Yo(t) {
        return !0;
      }
      function Vo(t) {
        const e = Ro(),
          i = (function (t, e) {
            const i = t.length,
              n = new Array(i);
            for (let s = 0; s < i; ++s) {
              const i = t[s],
                r = "filter" in i ? Bo(i.filter, po, e) : Yo;
              let o;
              if (Array.isArray(i.style)) {
                const t = i.style.length;
                o = new Array(t);
                for (let n = 0; n < t; ++n) o[n] = $o(i.style[n], e);
              } else o = [$o(i.style, e)];
              n[s] = { filter: r, styles: o };
            }
            return function (e) {
              const s = [];
              let r = !1;
              for (let o = 0; o < i; ++o) {
                if ((0, n[o].filter)(e) && (!t[o].else || !r)) {
                  r = !0;
                  for (const t of n[o].styles) {
                    const i = t(e);
                    i && s.push(i);
                  }
                }
              }
              return s;
            };
          })(t, e),
          n = {
            variables: {},
            properties: {},
            resolution: NaN,
            featureId: null,
            geometryType: "",
          };
        return function (t, s) {
          if (
            ((n.properties = t.getPropertiesInternal()),
            (n.resolution = s),
            e.featureId)
          ) {
            const e = t.getId();
            n.featureId = void 0 !== e ? e : null;
          }
          return e.geometryType && (n.geometryType = zo(t.getGeometry())), i(n);
        };
      }
      function qo(t) {
        const e = Ro(),
          i = t.length,
          n = new Array(i);
        for (let o = 0; o < i; ++o) n[o] = $o(t[o], e);
        const s = {
            variables: {},
            properties: {},
            resolution: NaN,
            featureId: null,
            geometryType: "",
          },
          r = new Array(i);
        return function (t, o) {
          if (
            ((s.properties = t.getPropertiesInternal()),
            (s.resolution = o),
            e.featureId)
          ) {
            const e = t.getId();
            s.featureId = void 0 !== e ? e : null;
          }
          let a = 0;
          for (let e = 0; e < i; ++e) {
            const t = n[e](s);
            t && ((r[a] = t), (a += 1));
          }
          return (r.length = a), r;
        };
      }
      function $o(t, e) {
        const i = Uo(t, "", e),
          n = Ho(t, "", e),
          s = (function (t, e) {
            const i = "text-",
              n = Jo(t, i + "value", e);
            if (!n) return null;
            const s = Uo(t, i, e),
              r = Uo(t, i + "background-", e),
              o = Ho(t, i, e),
              a = Ho(t, i + "background-", e),
              l = Jo(t, i + "font", e),
              h = Ko(t, i + "max-angle", e),
              c = Ko(t, i + "offset-x", e),
              u = Ko(t, i + "offset-y", e),
              d = Qo(t, i + "overflow", e),
              g = Jo(t, i + "placement", e),
              f = Ko(t, i + "repeat", e),
              p = sa(t, i + "scale", e),
              m = Qo(t, i + "rotate-with-view", e),
              _ = Ko(t, i + "rotation", e),
              y = Jo(t, i + "align", e),
              x = Jo(t, i + "justify", e),
              v = Jo(t, i + "baseline", e),
              w = ea(t, i + "padding", e),
              S = la(t, i + "declutter-mode"),
              C = new go({ declutterMode: S });
            return function (t) {
              if (
                (C.setText(n(t)),
                s && C.setFill(s(t)),
                r && C.setBackgroundFill(r(t)),
                o && C.setStroke(o(t)),
                a && C.setBackgroundStroke(a(t)),
                l && C.setFont(l(t)),
                h && C.setMaxAngle(h(t)),
                c && C.setOffsetX(c(t)),
                u && C.setOffsetY(u(t)),
                d && C.setOverflow(d(t)),
                g)
              ) {
                const e = g(t);
                if ("point" !== e && "line" !== e)
                  throw new Error("Expected point or line for text-placement");
                C.setPlacement(e);
              }
              if (
                (f && C.setRepeat(f(t)),
                p && C.setScale(p(t)),
                m && C.setRotateWithView(m(t)),
                _ && C.setRotation(_(t)),
                y)
              ) {
                const e = y(t);
                if (
                  "left" !== e &&
                  "center" !== e &&
                  "right" !== e &&
                  "end" !== e &&
                  "start" !== e
                )
                  throw new Error(
                    "Expected left, right, center, start, or end for text-align"
                  );
                C.setTextAlign(e);
              }
              if (x) {
                const e = x(t);
                if ("left" !== e && "right" !== e && "center" !== e)
                  throw new Error(
                    "Expected left, right, or center for text-justify"
                  );
                C.setJustify(e);
              }
              if (v) {
                const e = v(t);
                if (
                  "bottom" !== e &&
                  "top" !== e &&
                  "middle" !== e &&
                  "alphabetic" !== e &&
                  "hanging" !== e
                )
                  throw new Error(
                    "Expected bottom, top, middle, alphabetic, or hanging for text-baseline"
                  );
                C.setTextBaseline(e);
              }
              return w && C.setPadding(w(t)), C;
            };
          })(t, e),
          r = (function (t, e) {
            if ("icon-src" in t)
              return (function (t, e) {
                const i = "icon-",
                  n = i + "src",
                  s = ca(t[n], n),
                  r = ia(t, i + "anchor", e),
                  o = sa(t, i + "scale", e),
                  a = Ko(t, i + "opacity", e),
                  l = ia(t, i + "displacement", e),
                  h = Ko(t, i + "rotation", e),
                  c = Qo(t, i + "rotate-with-view", e),
                  u = oa(t, i + "anchor-origin"),
                  d = aa(t, i + "anchor-x-units"),
                  g = aa(t, i + "anchor-y-units"),
                  f = (function (t, e) {
                    const i = t[e];
                    if (void 0 === i) return;
                    return da(i, e);
                  })(t, i + "color"),
                  p = (function (t, e) {
                    const i = t[e];
                    if (void 0 === i) return;
                    if ("string" !== typeof i)
                      throw new Error(`Expected a string for ${e}`);
                    return i;
                  })(t, i + "cross-origin"),
                  m = (function (t, e) {
                    const i = t[e];
                    if (void 0 === i) return;
                    return ha(i, e);
                  })(t, i + "offset"),
                  _ = oa(t, i + "offset-origin"),
                  y = ra(t, i + "width"),
                  x = ra(t, i + "height"),
                  v = (function (t, e) {
                    const i = t[e];
                    if (void 0 === i) return;
                    if ("number" === typeof i) return Ws(i);
                    if (!Array.isArray(i))
                      throw new Error(
                        `Expected a number or size array for ${e}`
                      );
                    if (
                      2 !== i.length ||
                      "number" !== typeof i[0] ||
                      "number" !== typeof i[1]
                    )
                      throw new Error(
                        `Expected a number or size array for ${e}`
                      );
                    return i;
                  })(t, i + "size"),
                  w = la(t, i + "declutter-mode"),
                  S = new co({
                    src: s,
                    anchorOrigin: u,
                    anchorXUnits: d,
                    anchorYUnits: g,
                    color: f,
                    crossOrigin: p,
                    offset: m,
                    offsetOrigin: _,
                    height: x,
                    width: y,
                    size: v,
                    declutterMode: w,
                  });
                return function (t) {
                  return (
                    a && S.setOpacity(a(t)),
                    l && S.setDisplacement(l(t)),
                    h && S.setRotation(h(t)),
                    c && S.setRotateWithView(c(t)),
                    o && S.setScale(o(t)),
                    r && S.setAnchor(r(t)),
                    S
                  );
                };
              })(t, e);
            if ("shape-points" in t)
              return (function (t, e) {
                const i = "shape-",
                  n = i + "points",
                  s = i + "radius",
                  r = ua(t[n], n),
                  o = ua(t[s], s),
                  a = Uo(t, i, e),
                  l = Ho(t, i, e),
                  h = sa(t, i + "scale", e),
                  c = ia(t, i + "displacement", e),
                  u = Ko(t, i + "rotation", e),
                  d = Qo(t, i + "rotate-with-view", e),
                  g = ra(t, i + "radius2"),
                  f = ra(t, i + "angle"),
                  p = la(t, i + "declutter-mode"),
                  m = new Ur({
                    points: r,
                    radius: o,
                    radius2: g,
                    angle: f,
                    declutterMode: p,
                  });
                return function (t) {
                  return (
                    a && m.setFill(a(t)),
                    l && m.setStroke(l(t)),
                    c && m.setDisplacement(c(t)),
                    u && m.setRotation(u(t)),
                    d && m.setRotateWithView(d(t)),
                    h && m.setScale(h(t)),
                    m
                  );
                };
              })(t, e);
            if ("circle-radius" in t)
              return (function (t, e) {
                const i = "circle-",
                  n = Uo(t, i, e),
                  s = Ho(t, i, e),
                  r = Ko(t, i + "radius", e),
                  o = sa(t, i + "scale", e),
                  a = ia(t, i + "displacement", e),
                  l = Ko(t, i + "rotation", e),
                  h = Qo(t, i + "rotate-with-view", e),
                  c = la(t, i + "declutter-mode"),
                  u = new Kr({ radius: 5, declutterMode: c });
                return function (t) {
                  return (
                    r && u.setRadius(r(t)),
                    n && u.setFill(n(t)),
                    s && u.setStroke(s(t)),
                    a && u.setDisplacement(a(t)),
                    l && u.setRotation(l(t)),
                    h && u.setRotateWithView(h(t)),
                    o && u.setScale(o(t)),
                    u
                  );
                };
              })(t, e);
            return null;
          })(t, e),
          o = Ko(t, "z-index", e);
        if (!i && !n && !s && !r && !x(t))
          throw new Error(
            "No fill, stroke, point, or text symbolizer properties in style: " +
              JSON.stringify(t)
          );
        const a = new ao();
        return function (t) {
          let e = !0;
          if (i) {
            const n = i(t);
            n && (e = !1), a.setFill(n);
          }
          if (n) {
            const i = n(t);
            i && (e = !1), a.setStroke(i);
          }
          if (s) {
            const i = s(t);
            i && (e = !1), a.setText(i);
          }
          if (r) {
            const i = r(t);
            i && (e = !1), a.setImage(i);
          }
          return o && a.setZIndex(o(t)), e ? null : a;
        };
      }
      function Uo(t, e, i) {
        let n;
        if (e + "fill-pattern-src" in t)
          n = (function (t, e, i) {
            const n = Jo(t, e + "pattern-src", i),
              s = na(t, e + "pattern-offset", i),
              r = na(t, e + "pattern-size", i),
              o = ta(t, e + "color", i);
            return function (t) {
              return {
                src: n(t),
                offset: s && s(t),
                size: r && r(t),
                color: o && o(t),
              };
            };
          })(t, e + "fill-", i);
        else {
          if ("none" === t[e + "fill-color"]) return (t) => null;
          n = ta(t, e + "fill-color", i);
        }
        if (!n) return null;
        const s = new Qr();
        return function (t) {
          const e = n(t);
          return e === ir ? null : (s.setColor(e), s);
        };
      }
      function Ho(t, e, i) {
        const n = Ko(t, e + "stroke-width", i),
          s = ta(t, e + "stroke-color", i);
        if (!n && !s) return null;
        const r = Jo(t, e + "stroke-line-cap", i),
          o = Jo(t, e + "stroke-line-join", i),
          a = ea(t, e + "stroke-line-dash", i),
          l = Ko(t, e + "stroke-line-dash-offset", i),
          h = Ko(t, e + "stroke-miter-limit", i),
          c = new eo();
        return function (t) {
          if (s) {
            const e = s(t);
            if (e === ir) return null;
            c.setColor(e);
          }
          if ((n && c.setWidth(n(t)), r)) {
            const e = r(t);
            if ("butt" !== e && "round" !== e && "square" !== e)
              throw new Error("Expected butt, round, or square line cap");
            c.setLineCap(e);
          }
          if (o) {
            const e = o(t);
            if ("bevel" !== e && "round" !== e && "miter" !== e)
              throw new Error("Expected bevel, round, or miter line join");
            c.setLineJoin(e);
          }
          return (
            a && c.setLineDash(a(t)),
            l && c.setLineDashOffset(l(t)),
            h && c.setMiterLimit(h(t)),
            c
          );
        };
      }
      function Ko(t, e, i) {
        if (!(e in t)) return;
        const n = Bo(t[e], mo, i);
        return function (t) {
          return ua(n(t), e);
        };
      }
      function Jo(t, e, i) {
        if (!(e in t)) return null;
        const n = Bo(t[e], _o, i);
        return function (t) {
          return ca(n(t), e);
        };
      }
      function Qo(t, e, i) {
        if (!(e in t)) return null;
        const n = Bo(t[e], po, i);
        return function (t) {
          const i = n(t);
          if ("boolean" !== typeof i)
            throw new Error(`Expected a boolean for ${e}`);
          return i;
        };
      }
      function ta(t, e, i) {
        if (!(e in t)) return null;
        const n = Bo(t[e], yo, i);
        return function (t) {
          return da(n(t), e);
        };
      }
      function ea(t, e, i) {
        if (!(e in t)) return null;
        const n = Bo(t[e], xo, i);
        return function (t) {
          return ha(n(t), e);
        };
      }
      function ia(t, e, i) {
        if (!(e in t)) return null;
        const n = Bo(t[e], xo, i);
        return function (t) {
          const i = ha(n(t), e);
          if (2 !== i.length) throw new Error(`Expected two numbers for ${e}`);
          return i;
        };
      }
      function na(t, e, i) {
        if (!(e in t)) return null;
        const n = Bo(t[e], xo, i);
        return function (t) {
          return ga(n(t), e);
        };
      }
      function sa(t, e, i) {
        if (!(e in t)) return null;
        const n = Bo(t[e], xo | mo, i);
        return function (t) {
          return (function (t, e) {
            if ("number" === typeof t) return t;
            return ga(t, e);
          })(n(t), e);
        };
      }
      function ra(t, e) {
        const i = t[e];
        if (void 0 !== i) {
          if ("number" !== typeof i)
            throw new Error(`Expected a number for ${e}`);
          return i;
        }
      }
      function oa(t, e) {
        const i = t[e];
        if (void 0 !== i) {
          if (
            "bottom-left" !== i &&
            "bottom-right" !== i &&
            "top-left" !== i &&
            "top-right" !== i
          )
            throw new Error(
              `Expected bottom-left, bottom-right, top-left, or top-right for ${e}`
            );
          return i;
        }
      }
      function aa(t, e) {
        const i = t[e];
        if (void 0 !== i) {
          if ("pixels" !== i && "fraction" !== i)
            throw new Error(`Expected pixels or fraction for ${e}`);
          return i;
        }
      }
      function la(t, e) {
        const i = t[e];
        if (void 0 !== i) {
          if ("string" !== typeof i)
            throw new Error(`Expected a string for ${e}`);
          if ("declutter" !== i && "obstacle" !== i && "none" !== i)
            throw new Error(`Expected declutter, obstacle, or none for ${e}`);
          return i;
        }
      }
      function ha(t, e) {
        if (!Array.isArray(t)) throw new Error(`Expected an array for ${e}`);
        const i = t.length;
        for (let n = 0; n < i; ++n)
          if ("number" !== typeof t[n])
            throw new Error(`Expected an array of numbers for ${e}`);
        return t;
      }
      function ca(t, e) {
        if ("string" !== typeof t)
          throw new Error(`Expected a string for ${e}`);
        return t;
      }
      function ua(t, e) {
        if ("number" !== typeof t)
          throw new Error(`Expected a number for ${e}`);
        return t;
      }
      function da(t, e) {
        if ("string" === typeof t) return t;
        const i = ha(t, e),
          n = i.length;
        if (n < 3 || n > 4)
          throw new Error(`Expected a color with 3 or 4 values for ${e}`);
        return i;
      }
      function ga(t, e) {
        const i = ha(t, e);
        if (2 !== i.length)
          throw new Error(`Expected an array of two numbers for ${e}`);
        return i;
      }
      const fa = "renderOrder";
      const pa = class extends Bs {
          constructor(t) {
            t = t || {};
            const e = Object.assign({}, t);
            delete e.style,
              delete e.renderBuffer,
              delete e.updateWhileAnimating,
              delete e.updateWhileInteracting,
              super(e),
              (this.declutter_ = t.declutter ? String(t.declutter) : void 0),
              (this.renderBuffer_ =
                void 0 !== t.renderBuffer ? t.renderBuffer : 100),
              (this.style_ = null),
              (this.styleFunction_ = void 0),
              this.setStyle(t.style),
              (this.updateWhileAnimating_ =
                void 0 !== t.updateWhileAnimating && t.updateWhileAnimating),
              (this.updateWhileInteracting_ =
                void 0 !== t.updateWhileInteracting &&
                t.updateWhileInteracting);
          }
          getDeclutter() {
            return this.declutter_;
          }
          getFeatures(t) {
            return super.getFeatures(t);
          }
          getRenderBuffer() {
            return this.renderBuffer_;
          }
          getRenderOrder() {
            return this.get(fa);
          }
          getStyle() {
            return this.style_;
          }
          getStyleFunction() {
            return this.styleFunction_;
          }
          getUpdateWhileAnimating() {
            return this.updateWhileAnimating_;
          }
          getUpdateWhileInteracting() {
            return this.updateWhileInteracting_;
          }
          renderDeclutter(t, e) {
            const i = this.getDeclutter();
            i in t.declutter === !1 && (t.declutter[i] = new Y(9)),
              this.getRenderer().renderDeclutter(t, e);
          }
          setRenderOrder(t) {
            this.set(fa, t);
          }
          setStyle(t) {
            this.style_ = void 0 === t ? so : t;
            const e = (function (t) {
              if (void 0 === t) return so;
              if (!t) return null;
              if ("function" === typeof t) return t;
              if (t instanceof ao) return t;
              if (!Array.isArray(t)) return qo([t]);
              if (0 === t.length) return [];
              const e = t.length,
                i = t[0];
              if (i instanceof ao) {
                const i = new Array(e);
                for (let n = 0; n < e; ++n) {
                  const e = t[n];
                  if (!(e instanceof ao))
                    throw new Error("Expected a list of style instances");
                  i[n] = e;
                }
                return i;
              }
              if ("style" in i) {
                const i = new Array(e);
                for (let n = 0; n < e; ++n) {
                  const e = t[n];
                  if (!("style" in e))
                    throw new Error(
                      "Expected a list of rules with a style property"
                    );
                  i[n] = e;
                }
                return Vo(i);
              }
              const n = t;
              return qo(n);
            })(t);
            (this.styleFunction_ =
              null === t
                ? void 0
                : (function (t) {
                    let e;
                    if ("function" === typeof t) e = t;
                    else {
                      let i;
                      Array.isArray(t)
                        ? (i = t)
                        : (D(
                            "function" === typeof t.getZIndex,
                            "Expected an `Style` or an array of `Style`"
                          ),
                          (i = [t])),
                        (e = function () {
                          return i;
                        });
                    }
                    return e;
                  })(e)),
              this.changed();
          }
        },
        ma = {
          BEGIN_GEOMETRY: 0,
          BEGIN_PATH: 1,
          CIRCLE: 2,
          CLOSE_PATH: 3,
          CUSTOM: 4,
          DRAW_CHARS: 5,
          DRAW_IMAGE: 6,
          END_GEOMETRY: 7,
          FILL: 8,
          MOVE_TO_LINE_TO: 9,
          SET_FILL_STYLE: 10,
          SET_STROKE_STYLE: 11,
          STROKE: 12,
        },
        _a = [ma.FILL],
        ya = [ma.STROKE],
        xa = [ma.BEGIN_PATH],
        va = [ma.CLOSE_PATH],
        wa = ma;
      const Sa = class {
        drawCustom(t, e, i, n, s) {}
        drawGeometry(t) {}
        setStyle(t) {}
        drawCircle(t, e, i) {}
        drawFeature(t, e, i) {}
        drawGeometryCollection(t, e, i) {}
        drawLineString(t, e, i) {}
        drawMultiLineString(t, e, i) {}
        drawMultiPoint(t, e, i) {}
        drawMultiPolygon(t, e, i) {}
        drawPoint(t, e, i) {}
        drawPolygon(t, e, i) {}
        drawText(t, e, i) {}
        setFillStrokeStyle(t, e) {}
        setImageStyle(t, e) {}
        setTextStyle(t, e) {}
      };
      const Ca = class extends Sa {
        constructor(t, e, i, n) {
          super(),
            (this.tolerance = t),
            (this.maxExtent = e),
            (this.pixelRatio = n),
            (this.maxLineWidth = 0),
            (this.resolution = i),
            (this.beginGeometryInstruction1_ = null),
            (this.beginGeometryInstruction2_ = null),
            (this.bufferedMaxExtent_ = null),
            (this.instructions = []),
            (this.coordinates = []),
            (this.tmpCoordinate_ = []),
            (this.hitDetectionInstructions = []),
            (this.state = {});
        }
        applyPixelRatio(t) {
          const e = this.pixelRatio;
          return 1 == e
            ? t
            : t.map(function (t) {
                return t * e;
              });
        }
        appendFlatPointCoordinates(t, e) {
          const i = this.getBufferedMaxExtent(),
            n = this.tmpCoordinate_,
            s = this.coordinates;
          let r = s.length;
          for (let o = 0, a = t.length; o < a; o += e)
            (n[0] = t[o]),
              (n[1] = t[o + 1]),
              ht(i, n) && ((s[r++] = n[0]), (s[r++] = n[1]));
          return r;
        }
        appendFlatLineCoordinates(t, e, i, n, s, r) {
          const o = this.coordinates;
          let a = o.length;
          const l = this.getBufferedMaxExtent();
          r && (e += n);
          let h = t[e],
            c = t[e + 1];
          const u = this.tmpCoordinate_;
          let d,
            g,
            f,
            p = !0;
          for (d = e + n; d < i; d += n)
            (u[0] = t[d]),
              (u[1] = t[d + 1]),
              (f = dt(l, u)),
              f !== g
                ? (p && ((o[a++] = h), (o[a++] = c), (p = !1)),
                  (o[a++] = u[0]),
                  (o[a++] = u[1]))
                : f === rt.INTERSECTING
                ? ((o[a++] = u[0]), (o[a++] = u[1]), (p = !1))
                : (p = !0),
              (h = u[0]),
              (c = u[1]),
              (g = f);
          return ((s && p) || d === e + n) && ((o[a++] = h), (o[a++] = c)), a;
        }
        drawCustomCoordinates_(t, e, i, n, s) {
          for (let r = 0, o = i.length; r < o; ++r) {
            const o = i[r],
              a = this.appendFlatLineCoordinates(t, e, o, n, !1, !1);
            s.push(a), (e = o);
          }
          return e;
        }
        drawCustom(t, e, i, n, s) {
          this.beginGeometry(t, e, s);
          const r = t.getType(),
            o = t.getStride(),
            a = this.coordinates.length;
          let l, h, c, u, d;
          switch (r) {
            case "MultiPolygon":
              (l = t.getOrientedFlatCoordinates()), (u = []);
              const e = t.getEndss();
              d = 0;
              for (let t = 0, i = e.length; t < i; ++t) {
                const i = [];
                (d = this.drawCustomCoordinates_(l, d, e[t], o, i)), u.push(i);
              }
              this.instructions.push([wa.CUSTOM, a, u, t, i, Yi, s]),
                this.hitDetectionInstructions.push([
                  wa.CUSTOM,
                  a,
                  u,
                  t,
                  n || i,
                  Yi,
                  s,
                ]);
              break;
            case "Polygon":
            case "MultiLineString":
              (c = []),
                (l =
                  "Polygon" == r
                    ? t.getOrientedFlatCoordinates()
                    : t.getFlatCoordinates()),
                (d = this.drawCustomCoordinates_(l, 0, t.getEnds(), o, c)),
                this.instructions.push([wa.CUSTOM, a, c, t, i, Xi, s]),
                this.hitDetectionInstructions.push([
                  wa.CUSTOM,
                  a,
                  c,
                  t,
                  n || i,
                  Xi,
                  s,
                ]);
              break;
            case "LineString":
            case "Circle":
              (l = t.getFlatCoordinates()),
                (h = this.appendFlatLineCoordinates(l, 0, l.length, o, !1, !1)),
                this.instructions.push([wa.CUSTOM, a, h, t, i, Wi, s]),
                this.hitDetectionInstructions.push([
                  wa.CUSTOM,
                  a,
                  h,
                  t,
                  n || i,
                  Wi,
                  s,
                ]);
              break;
            case "MultiPoint":
              (l = t.getFlatCoordinates()),
                (h = this.appendFlatPointCoordinates(l, o)),
                h > a &&
                  (this.instructions.push([wa.CUSTOM, a, h, t, i, Wi, s]),
                  this.hitDetectionInstructions.push([
                    wa.CUSTOM,
                    a,
                    h,
                    t,
                    n || i,
                    Wi,
                    s,
                  ]));
              break;
            case "Point":
              (l = t.getFlatCoordinates()),
                this.coordinates.push(l[0], l[1]),
                (h = this.coordinates.length),
                this.instructions.push([wa.CUSTOM, a, h, t, i, void 0, s]),
                this.hitDetectionInstructions.push([
                  wa.CUSTOM,
                  a,
                  h,
                  t,
                  n || i,
                  void 0,
                  s,
                ]);
          }
          this.endGeometry(e);
        }
        beginGeometry(t, e, i) {
          (this.beginGeometryInstruction1_ = [wa.BEGIN_GEOMETRY, e, 0, t, i]),
            this.instructions.push(this.beginGeometryInstruction1_),
            (this.beginGeometryInstruction2_ = [wa.BEGIN_GEOMETRY, e, 0, t, i]),
            this.hitDetectionInstructions.push(this.beginGeometryInstruction2_);
        }
        finish() {
          return {
            instructions: this.instructions,
            hitDetectionInstructions: this.hitDetectionInstructions,
            coordinates: this.coordinates,
          };
        }
        reverseHitDetectionInstructions() {
          const t = this.hitDetectionInstructions;
          let e;
          t.reverse();
          const i = t.length;
          let n,
            s,
            r = -1;
          for (e = 0; e < i; ++e)
            (n = t[e]),
              (s = n[0]),
              s == wa.END_GEOMETRY
                ? (r = e)
                : s == wa.BEGIN_GEOMETRY &&
                  ((n[2] = e),
                  u(this.hitDetectionInstructions, r, e),
                  (r = -1));
        }
        setFillStrokeStyle(t, e) {
          const i = this.state;
          if (t) {
            const e = t.getColor();
            (i.fillPatternScale =
              e && "object" === typeof e && "src" in e ? this.pixelRatio : 1),
              (i.fillStyle = kr(e || Pr));
          } else i.fillStyle = void 0;
          if (e) {
            const t = e.getColor();
            i.strokeStyle = kr(t || Dr);
            const n = e.getLineCap();
            i.lineCap = void 0 !== n ? n : Fr;
            const s = e.getLineDash();
            i.lineDash = s ? s.slice() : Lr;
            const r = e.getLineDashOffset();
            i.lineDashOffset = r || 0;
            const o = e.getLineJoin();
            i.lineJoin = void 0 !== o ? o : Tr;
            const a = e.getWidth();
            i.lineWidth = void 0 !== a ? a : 1;
            const l = e.getMiterLimit();
            (i.miterLimit = void 0 !== l ? l : 10),
              i.lineWidth > this.maxLineWidth &&
                ((this.maxLineWidth = i.lineWidth),
                (this.bufferedMaxExtent_ = null));
          } else
            (i.strokeStyle = void 0),
              (i.lineCap = void 0),
              (i.lineDash = null),
              (i.lineDashOffset = void 0),
              (i.lineJoin = void 0),
              (i.lineWidth = void 0),
              (i.miterLimit = void 0);
        }
        createFill(t) {
          const e = t.fillStyle,
            i = [wa.SET_FILL_STYLE, e];
          return "string" !== typeof e && i.push(t.fillPatternScale), i;
        }
        applyStroke(t) {
          this.instructions.push(this.createStroke(t));
        }
        createStroke(t) {
          return [
            wa.SET_STROKE_STYLE,
            t.strokeStyle,
            t.lineWidth * this.pixelRatio,
            t.lineCap,
            t.lineJoin,
            t.miterLimit,
            this.applyPixelRatio(t.lineDash),
            t.lineDashOffset * this.pixelRatio,
          ];
        }
        updateFillStyle(t, e) {
          const i = t.fillStyle;
          ("string" === typeof i && t.currentFillStyle == i) ||
            (void 0 !== i && this.instructions.push(e.call(this, t)),
            (t.currentFillStyle = i));
        }
        updateStrokeStyle(t, e) {
          const i = t.strokeStyle,
            n = t.lineCap,
            s = t.lineDash,
            r = t.lineDashOffset,
            o = t.lineJoin,
            a = t.lineWidth,
            l = t.miterLimit;
          (t.currentStrokeStyle != i ||
            t.currentLineCap != n ||
            (s != t.currentLineDash && !g(t.currentLineDash, s)) ||
            t.currentLineDashOffset != r ||
            t.currentLineJoin != o ||
            t.currentLineWidth != a ||
            t.currentMiterLimit != l) &&
            (void 0 !== i && e.call(this, t),
            (t.currentStrokeStyle = i),
            (t.currentLineCap = n),
            (t.currentLineDash = s),
            (t.currentLineDashOffset = r),
            (t.currentLineJoin = o),
            (t.currentLineWidth = a),
            (t.currentMiterLimit = l));
        }
        endGeometry(t) {
          (this.beginGeometryInstruction1_[2] = this.instructions.length),
            (this.beginGeometryInstruction1_ = null),
            (this.beginGeometryInstruction2_[2] =
              this.hitDetectionInstructions.length),
            (this.beginGeometryInstruction2_ = null);
          const e = [wa.END_GEOMETRY, t];
          this.instructions.push(e), this.hitDetectionInstructions.push(e);
        }
        getBufferedMaxExtent() {
          if (
            !this.bufferedMaxExtent_ &&
            ((this.bufferedMaxExtent_ =
              ((t = this.maxExtent),
              e
                ? ((e[0] = t[0]),
                  (e[1] = t[1]),
                  (e[2] = t[2]),
                  (e[3] = t[3]),
                  e)
                : t.slice())),
            this.maxLineWidth > 0)
          ) {
            const t = (this.resolution * (this.maxLineWidth + 1)) / 2;
            at(this.bufferedMaxExtent_, t, this.bufferedMaxExtent_);
          }
          var t, e;
          return this.bufferedMaxExtent_;
        }
      };
      const ba = class extends Ca {
        constructor(t, e, i, n) {
          super(t, e, i, n),
            (this.hitDetectionImage_ = null),
            (this.image_ = null),
            (this.imagePixelRatio_ = void 0),
            (this.anchorX_ = void 0),
            (this.anchorY_ = void 0),
            (this.height_ = void 0),
            (this.opacity_ = void 0),
            (this.originX_ = void 0),
            (this.originY_ = void 0),
            (this.rotateWithView_ = void 0),
            (this.rotation_ = void 0),
            (this.scale_ = void 0),
            (this.width_ = void 0),
            (this.declutterMode_ = void 0),
            (this.declutterImageWithText_ = void 0);
        }
        drawPoint(t, e, i) {
          if (
            !this.image_ ||
            (this.maxExtent && !ht(this.maxExtent, t.getFlatCoordinates()))
          )
            return;
          this.beginGeometry(t, e, i);
          const n = t.getFlatCoordinates(),
            s = t.getStride(),
            r = this.coordinates.length,
            o = this.appendFlatPointCoordinates(n, s);
          this.instructions.push([
            wa.DRAW_IMAGE,
            r,
            o,
            this.image_,
            this.anchorX_ * this.imagePixelRatio_,
            this.anchorY_ * this.imagePixelRatio_,
            Math.ceil(this.height_ * this.imagePixelRatio_),
            this.opacity_,
            this.originX_ * this.imagePixelRatio_,
            this.originY_ * this.imagePixelRatio_,
            this.rotateWithView_,
            this.rotation_,
            [
              (this.scale_[0] * this.pixelRatio) / this.imagePixelRatio_,
              (this.scale_[1] * this.pixelRatio) / this.imagePixelRatio_,
            ],
            Math.ceil(this.width_ * this.imagePixelRatio_),
            this.declutterMode_,
            this.declutterImageWithText_,
          ]),
            this.hitDetectionInstructions.push([
              wa.DRAW_IMAGE,
              r,
              o,
              this.hitDetectionImage_,
              this.anchorX_,
              this.anchorY_,
              this.height_,
              1,
              this.originX_,
              this.originY_,
              this.rotateWithView_,
              this.rotation_,
              this.scale_,
              this.width_,
              this.declutterMode_,
              this.declutterImageWithText_,
            ]),
            this.endGeometry(e);
        }
        drawMultiPoint(t, e, i) {
          if (!this.image_) return;
          this.beginGeometry(t, e, i);
          const n = t.getFlatCoordinates(),
            s = [];
          for (let a = 0, l = n.length; a < l; a += t.getStride())
            (this.maxExtent && !ht(this.maxExtent, n.slice(a, a + 2))) ||
              s.push(n[a], n[a + 1]);
          const r = this.coordinates.length,
            o = this.appendFlatPointCoordinates(s, 2);
          this.instructions.push([
            wa.DRAW_IMAGE,
            r,
            o,
            this.image_,
            this.anchorX_ * this.imagePixelRatio_,
            this.anchorY_ * this.imagePixelRatio_,
            Math.ceil(this.height_ * this.imagePixelRatio_),
            this.opacity_,
            this.originX_ * this.imagePixelRatio_,
            this.originY_ * this.imagePixelRatio_,
            this.rotateWithView_,
            this.rotation_,
            [
              (this.scale_[0] * this.pixelRatio) / this.imagePixelRatio_,
              (this.scale_[1] * this.pixelRatio) / this.imagePixelRatio_,
            ],
            Math.ceil(this.width_ * this.imagePixelRatio_),
            this.declutterMode_,
            this.declutterImageWithText_,
          ]),
            this.hitDetectionInstructions.push([
              wa.DRAW_IMAGE,
              r,
              o,
              this.hitDetectionImage_,
              this.anchorX_,
              this.anchorY_,
              this.height_,
              1,
              this.originX_,
              this.originY_,
              this.rotateWithView_,
              this.rotation_,
              this.scale_,
              this.width_,
              this.declutterMode_,
              this.declutterImageWithText_,
            ]),
            this.endGeometry(e);
        }
        finish() {
          return (
            this.reverseHitDetectionInstructions(),
            (this.anchorX_ = void 0),
            (this.anchorY_ = void 0),
            (this.hitDetectionImage_ = null),
            (this.image_ = null),
            (this.imagePixelRatio_ = void 0),
            (this.height_ = void 0),
            (this.scale_ = void 0),
            (this.opacity_ = void 0),
            (this.originX_ = void 0),
            (this.originY_ = void 0),
            (this.rotateWithView_ = void 0),
            (this.rotation_ = void 0),
            (this.width_ = void 0),
            super.finish()
          );
        }
        setImageStyle(t, e) {
          const i = t.getAnchor(),
            n = t.getSize(),
            s = t.getOrigin();
          (this.imagePixelRatio_ = t.getPixelRatio(this.pixelRatio)),
            (this.anchorX_ = i[0]),
            (this.anchorY_ = i[1]),
            (this.hitDetectionImage_ = t.getHitDetectionImage()),
            (this.image_ = t.getImage(this.pixelRatio)),
            (this.height_ = n[1]),
            (this.opacity_ = t.getOpacity()),
            (this.originX_ = s[0]),
            (this.originY_ = s[1]),
            (this.rotateWithView_ = t.getRotateWithView()),
            (this.rotation_ = t.getRotation()),
            (this.scale_ = t.getScaleArray()),
            (this.width_ = n[0]),
            (this.declutterMode_ = t.getDeclutterMode()),
            (this.declutterImageWithText_ = e);
        }
      };
      const ka = class extends Ca {
        constructor(t, e, i, n) {
          super(t, e, i, n);
        }
        drawFlatCoordinates_(t, e, i, n) {
          const s = this.coordinates.length,
            r = this.appendFlatLineCoordinates(t, e, i, n, !1, !1),
            o = [wa.MOVE_TO_LINE_TO, s, r];
          return (
            this.instructions.push(o), this.hitDetectionInstructions.push(o), i
          );
        }
        drawLineString(t, e, i) {
          const n = this.state,
            s = n.strokeStyle,
            r = n.lineWidth;
          if (void 0 === s || void 0 === r) return;
          this.updateStrokeStyle(n, this.applyStroke),
            this.beginGeometry(t, e, i),
            this.hitDetectionInstructions.push(
              [
                wa.SET_STROKE_STYLE,
                n.strokeStyle,
                n.lineWidth,
                n.lineCap,
                n.lineJoin,
                n.miterLimit,
                Lr,
                0,
              ],
              xa
            );
          const o = t.getFlatCoordinates(),
            a = t.getStride();
          this.drawFlatCoordinates_(o, 0, o.length, a),
            this.hitDetectionInstructions.push(ya),
            this.endGeometry(e);
        }
        drawMultiLineString(t, e, i) {
          const n = this.state,
            s = n.strokeStyle,
            r = n.lineWidth;
          if (void 0 === s || void 0 === r) return;
          this.updateStrokeStyle(n, this.applyStroke),
            this.beginGeometry(t, e, i),
            this.hitDetectionInstructions.push(
              [
                wa.SET_STROKE_STYLE,
                n.strokeStyle,
                n.lineWidth,
                n.lineCap,
                n.lineJoin,
                n.miterLimit,
                Lr,
                0,
              ],
              xa
            );
          const o = t.getEnds(),
            a = t.getFlatCoordinates(),
            l = t.getStride();
          let h = 0;
          for (let c = 0, u = o.length; c < u; ++c)
            h = this.drawFlatCoordinates_(a, h, o[c], l);
          this.hitDetectionInstructions.push(ya), this.endGeometry(e);
        }
        finish() {
          const t = this.state;
          return (
            void 0 != t.lastStroke &&
              t.lastStroke != this.coordinates.length &&
              this.instructions.push(ya),
            this.reverseHitDetectionInstructions(),
            (this.state = null),
            super.finish()
          );
        }
        applyStroke(t) {
          void 0 != t.lastStroke &&
            t.lastStroke != this.coordinates.length &&
            (this.instructions.push(ya),
            (t.lastStroke = this.coordinates.length)),
            (t.lastStroke = 0),
            super.applyStroke(t),
            this.instructions.push(xa);
        }
      };
      const Ma = class extends Ca {
        constructor(t, e, i, n) {
          super(t, e, i, n);
        }
        drawFlatCoordinatess_(t, e, i, n) {
          const s = this.state,
            r = void 0 !== s.fillStyle,
            o = void 0 !== s.strokeStyle,
            a = i.length;
          this.instructions.push(xa), this.hitDetectionInstructions.push(xa);
          for (let l = 0; l < a; ++l) {
            const s = i[l],
              r = this.coordinates.length,
              a = this.appendFlatLineCoordinates(t, e, s, n, !0, !o),
              h = [wa.MOVE_TO_LINE_TO, r, a];
            this.instructions.push(h),
              this.hitDetectionInstructions.push(h),
              o &&
                (this.instructions.push(va),
                this.hitDetectionInstructions.push(va)),
              (e = s);
          }
          return (
            r &&
              (this.instructions.push(_a),
              this.hitDetectionInstructions.push(_a)),
            o &&
              (this.instructions.push(ya),
              this.hitDetectionInstructions.push(ya)),
            e
          );
        }
        drawCircle(t, e, i) {
          const n = this.state,
            s = n.fillStyle,
            r = n.strokeStyle;
          if (void 0 === s && void 0 === r) return;
          this.setFillStrokeStyles_(),
            this.beginGeometry(t, e, i),
            void 0 !== n.fillStyle &&
              this.hitDetectionInstructions.push([wa.SET_FILL_STYLE, Pr]),
            void 0 !== n.strokeStyle &&
              this.hitDetectionInstructions.push([
                wa.SET_STROKE_STYLE,
                n.strokeStyle,
                n.lineWidth,
                n.lineCap,
                n.lineJoin,
                n.miterLimit,
                Lr,
                0,
              ]);
          const o = t.getFlatCoordinates(),
            a = t.getStride(),
            l = this.coordinates.length;
          this.appendFlatLineCoordinates(o, 0, o.length, a, !1, !1);
          const h = [wa.CIRCLE, l];
          this.instructions.push(xa, h),
            this.hitDetectionInstructions.push(xa, h),
            void 0 !== n.fillStyle &&
              (this.instructions.push(_a),
              this.hitDetectionInstructions.push(_a)),
            void 0 !== n.strokeStyle &&
              (this.instructions.push(ya),
              this.hitDetectionInstructions.push(ya)),
            this.endGeometry(e);
        }
        drawPolygon(t, e, i) {
          const n = this.state,
            s = n.fillStyle,
            r = n.strokeStyle;
          if (void 0 === s && void 0 === r) return;
          this.setFillStrokeStyles_(),
            this.beginGeometry(t, e, i),
            void 0 !== n.fillStyle &&
              this.hitDetectionInstructions.push([wa.SET_FILL_STYLE, Pr]),
            void 0 !== n.strokeStyle &&
              this.hitDetectionInstructions.push([
                wa.SET_STROKE_STYLE,
                n.strokeStyle,
                n.lineWidth,
                n.lineCap,
                n.lineJoin,
                n.miterLimit,
                Lr,
                0,
              ]);
          const o = t.getEnds(),
            a = t.getOrientedFlatCoordinates(),
            l = t.getStride();
          this.drawFlatCoordinatess_(a, 0, o, l), this.endGeometry(e);
        }
        drawMultiPolygon(t, e, i) {
          const n = this.state,
            s = n.fillStyle,
            r = n.strokeStyle;
          if (void 0 === s && void 0 === r) return;
          this.setFillStrokeStyles_(),
            this.beginGeometry(t, e, i),
            void 0 !== n.fillStyle &&
              this.hitDetectionInstructions.push([wa.SET_FILL_STYLE, Pr]),
            void 0 !== n.strokeStyle &&
              this.hitDetectionInstructions.push([
                wa.SET_STROKE_STYLE,
                n.strokeStyle,
                n.lineWidth,
                n.lineCap,
                n.lineJoin,
                n.miterLimit,
                Lr,
                0,
              ]);
          const o = t.getEndss(),
            a = t.getOrientedFlatCoordinates(),
            l = t.getStride();
          let h = 0;
          for (let c = 0, u = o.length; c < u; ++c)
            h = this.drawFlatCoordinatess_(a, h, o[c], l);
          this.endGeometry(e);
        }
        finish() {
          this.reverseHitDetectionInstructions(), (this.state = null);
          const t = this.tolerance;
          if (0 !== t) {
            const e = this.coordinates;
            for (let i = 0, n = e.length; i < n; ++i) e[i] = Kt(e[i], t);
          }
          return super.finish();
        }
        setFillStrokeStyles_() {
          const t = this.state;
          void 0 !== t.fillStyle && this.updateFillStyle(t, this.createFill),
            void 0 !== t.strokeStyle &&
              this.updateStrokeStyle(t, this.applyStroke);
        }
      };
      function Ia(t, e, i, n, s) {
        const r = [];
        let o = i,
          a = 0,
          l = e.slice(i, 2);
        for (; a < t && o + s < n; ) {
          const [i, n] = l.slice(-2),
            h = e[o + s],
            c = e[o + s + 1],
            u = Math.sqrt((h - i) * (h - i) + (c - n) * (c - n));
          if (((a += u), a >= t)) {
            const e = (t - a + u) / u,
              d = qt(i, h, e),
              g = qt(n, c, e);
            l.push(d, g), r.push(l), (l = [d, g]), a == t && (o += s), (a = 0);
          } else if (a < t) l.push(e[o + s], e[o + s + 1]), (o += s);
          else {
            const t = u - a,
              e = qt(i, h, t / u),
              d = qt(n, c, t / u);
            l.push(e, d), r.push(l), (l = [e, d]), (a = 0), (o += s);
          }
        }
        return a > 0 && r.push(l), r;
      }
      function Ea(t, e, i, n, s) {
        let r,
          o,
          a,
          l,
          h,
          c,
          u,
          d,
          g,
          f,
          p = i,
          m = i,
          _ = 0,
          y = 0,
          x = i;
        for (o = i; o < n; o += s) {
          const i = e[o],
            n = e[o + 1];
          void 0 !== h &&
            ((g = i - h),
            (f = n - c),
            (l = Math.sqrt(g * g + f * f)),
            void 0 !== u &&
              ((y += a),
              (r = Math.acos((u * g + d * f) / (a * l))),
              r > t &&
                (y > _ && ((_ = y), (p = x), (m = o)), (y = 0), (x = o - s))),
            (a = l),
            (u = g),
            (d = f)),
            (h = i),
            (c = n);
        }
        return (y += l), y > _ ? [x, o] : [p, m];
      }
      const Ra = {
        left: 0,
        center: 0.5,
        right: 1,
        top: 0,
        middle: 0.5,
        hanging: 0.2,
        alphabetic: 0.8,
        ideographic: 0.8,
        bottom: 1,
      };
      const Pa = class extends Ca {
          constructor(t, e, i, n) {
            super(t, e, i, n),
              (this.labels_ = null),
              (this.text_ = ""),
              (this.textOffsetX_ = 0),
              (this.textOffsetY_ = 0),
              (this.textRotateWithView_ = void 0),
              (this.textRotation_ = 0),
              (this.textFillState_ = null),
              (this.fillStates = {}),
              (this.fillStates[Pr] = { fillStyle: Pr }),
              (this.textStrokeState_ = null),
              (this.strokeStates = {}),
              (this.textState_ = {}),
              (this.textStates = {}),
              (this.textKey_ = ""),
              (this.fillKey_ = ""),
              (this.strokeKey_ = ""),
              (this.declutterMode_ = void 0),
              (this.declutterImageWithText_ = void 0);
          }
          finish() {
            const t = super.finish();
            return (
              (t.textStates = this.textStates),
              (t.fillStates = this.fillStates),
              (t.strokeStates = this.strokeStates),
              t
            );
          }
          drawText(t, e, i) {
            const n = this.textFillState_,
              s = this.textStrokeState_,
              r = this.textState_;
            if ("" === this.text_ || !r || (!n && !s)) return;
            const o = this.coordinates;
            let a = o.length;
            const l = t.getType();
            let h = null,
              c = t.getStride();
            if (
              "line" !== r.placement ||
              ("LineString" != l &&
                "MultiLineString" != l &&
                "Polygon" != l &&
                "MultiPolygon" != l)
            ) {
              let n = r.overflow ? null : [];
              switch (l) {
                case "Point":
                case "MultiPoint":
                  h = t.getFlatCoordinates();
                  break;
                case "LineString":
                  h = t.getFlatMidpoint();
                  break;
                case "Circle":
                  h = t.getCenter();
                  break;
                case "MultiLineString":
                  (h = t.getFlatMidpoints()), (c = 2);
                  break;
                case "Polygon":
                  (h = t.getFlatInteriorPoint()),
                    r.overflow || n.push(h[2] / this.resolution),
                    (c = 3);
                  break;
                case "MultiPolygon":
                  const e = t.getFlatInteriorPoints();
                  h = [];
                  for (let t = 0, i = e.length; t < i; t += 3)
                    r.overflow || n.push(e[t + 2] / this.resolution),
                      h.push(e[t], e[t + 1]);
                  if (0 === h.length) return;
                  c = 2;
              }
              const s = this.appendFlatPointCoordinates(h, c);
              if (s === a) return;
              if (n && (s - a) / 2 !== h.length / c) {
                let t = a / 2;
                n = n.filter((e, i) => {
                  const n =
                    o[2 * (t + i)] === h[i * c] &&
                    o[2 * (t + i) + 1] === h[i * c + 1];
                  return n || --t, n;
                });
              }
              this.saveTextStates_(),
                (r.backgroundFill || r.backgroundStroke) &&
                  (this.setFillStrokeStyle(
                    r.backgroundFill,
                    r.backgroundStroke
                  ),
                  r.backgroundFill &&
                    this.updateFillStyle(this.state, this.createFill),
                  r.backgroundStroke &&
                    (this.updateStrokeStyle(this.state, this.applyStroke),
                    this.hitDetectionInstructions.push(
                      this.createStroke(this.state)
                    ))),
                this.beginGeometry(t, e, i);
              let u = r.padding;
              if (u != jr && (r.scale[0] < 0 || r.scale[1] < 0)) {
                let t = r.padding[0],
                  e = r.padding[1],
                  i = r.padding[2],
                  n = r.padding[3];
                r.scale[0] < 0 && ((e = -e), (n = -n)),
                  r.scale[1] < 0 && ((t = -t), (i = -i)),
                  (u = [t, e, i, n]);
              }
              const d = this.pixelRatio;
              this.instructions.push([
                wa.DRAW_IMAGE,
                a,
                s,
                null,
                NaN,
                NaN,
                NaN,
                1,
                0,
                0,
                this.textRotateWithView_,
                this.textRotation_,
                [1, 1],
                NaN,
                this.declutterMode_,
                this.declutterImageWithText_,
                u == jr
                  ? jr
                  : u.map(function (t) {
                      return t * d;
                    }),
                !!r.backgroundFill,
                !!r.backgroundStroke,
                this.text_,
                this.textKey_,
                this.strokeKey_,
                this.fillKey_,
                this.textOffsetX_,
                this.textOffsetY_,
                n,
              ]);
              const g = 1 / d,
                f = this.state.fillStyle;
              r.backgroundFill &&
                ((this.state.fillStyle = Pr),
                this.hitDetectionInstructions.push(
                  this.createFill(this.state)
                )),
                this.hitDetectionInstructions.push([
                  wa.DRAW_IMAGE,
                  a,
                  s,
                  null,
                  NaN,
                  NaN,
                  NaN,
                  1,
                  0,
                  0,
                  this.textRotateWithView_,
                  this.textRotation_,
                  [g, g],
                  NaN,
                  this.declutterMode_,
                  this.declutterImageWithText_,
                  u,
                  !!r.backgroundFill,
                  !!r.backgroundStroke,
                  this.text_,
                  this.textKey_,
                  this.strokeKey_,
                  this.fillKey_ ? Pr : this.fillKey_,
                  this.textOffsetX_,
                  this.textOffsetY_,
                  n,
                ]),
                r.backgroundFill &&
                  ((this.state.fillStyle = f),
                  this.hitDetectionInstructions.push(
                    this.createFill(this.state)
                  )),
                this.endGeometry(e);
            } else {
              if (!Lt(this.maxExtent, t.getExtent())) return;
              let n;
              if (((h = t.getFlatCoordinates()), "LineString" == l))
                n = [h.length];
              else if ("MultiLineString" == l) n = t.getEnds();
              else if ("Polygon" == l) n = t.getEnds().slice(0, 1);
              else if ("MultiPolygon" == l) {
                const e = t.getEndss();
                n = [];
                for (let t = 0, i = e.length; t < i; ++t) n.push(e[t][0]);
              }
              this.beginGeometry(t, e, i);
              const s = r.repeat,
                u = s ? void 0 : r.textAlign;
              let d = 0;
              for (let t = 0, e = n.length; t < e; ++t) {
                let e;
                e = s
                  ? Ia(s * this.resolution, h, d, n[t], c)
                  : [h.slice(d, n[t])];
                for (let i = 0, s = e.length; i < s; ++i) {
                  const s = e[i];
                  let l = 0,
                    h = s.length;
                  if (void 0 == u) {
                    const t = Ea(r.maxAngle, s, 0, s.length, 2);
                    (l = t[0]), (h = t[1]);
                  }
                  for (let t = l; t < h; t += c) o.push(s[t], s[t + 1]);
                  const g = o.length;
                  (d = n[t]), this.drawChars_(a, g), (a = g);
                }
              }
              this.endGeometry(e);
            }
          }
          saveTextStates_() {
            const t = this.textStrokeState_,
              e = this.textState_,
              i = this.textFillState_,
              n = this.strokeKey_;
            t &&
              (n in this.strokeStates ||
                (this.strokeStates[n] = {
                  strokeStyle: t.strokeStyle,
                  lineCap: t.lineCap,
                  lineDashOffset: t.lineDashOffset,
                  lineWidth: t.lineWidth,
                  lineJoin: t.lineJoin,
                  miterLimit: t.miterLimit,
                  lineDash: t.lineDash,
                }));
            const s = this.textKey_;
            s in this.textStates ||
              (this.textStates[s] = {
                font: e.font,
                textAlign: e.textAlign || Ar,
                justify: e.justify,
                textBaseline: e.textBaseline || Or,
                scale: e.scale,
              });
            const r = this.fillKey_;
            i &&
              (r in this.fillStates ||
                (this.fillStates[r] = { fillStyle: i.fillStyle }));
          }
          drawChars_(t, e) {
            const i = this.textStrokeState_,
              n = this.textState_,
              s = this.strokeKey_,
              r = this.textKey_,
              o = this.fillKey_;
            this.saveTextStates_();
            const a = this.pixelRatio,
              l = Ra[n.textBaseline],
              h = this.textOffsetY_ * a,
              c = this.text_,
              u = i ? (i.lineWidth * Math.abs(n.scale[0])) / 2 : 0;
            this.instructions.push([
              wa.DRAW_CHARS,
              t,
              e,
              l,
              n.overflow,
              o,
              n.maxAngle,
              a,
              h,
              s,
              u * a,
              c,
              r,
              1,
              this.declutterMode_,
            ]),
              this.hitDetectionInstructions.push([
                wa.DRAW_CHARS,
                t,
                e,
                l,
                n.overflow,
                o ? Pr : o,
                n.maxAngle,
                a,
                h,
                s,
                u * a,
                c,
                r,
                1 / a,
                this.declutterMode_,
              ]);
          }
          setTextStyle(t, e) {
            let i, n, s;
            if (t) {
              const e = t.getFill();
              e
                ? ((n = this.textFillState_),
                  n || ((n = {}), (this.textFillState_ = n)),
                  (n.fillStyle = kr(e.getColor() || Pr)))
                : ((n = null), (this.textFillState_ = n));
              const r = t.getStroke();
              if (r) {
                (s = this.textStrokeState_),
                  s || ((s = {}), (this.textStrokeState_ = s));
                const t = r.getLineDash(),
                  e = r.getLineDashOffset(),
                  i = r.getWidth(),
                  n = r.getMiterLimit();
                (s.lineCap = r.getLineCap() || Fr),
                  (s.lineDash = t ? t.slice() : Lr),
                  (s.lineDashOffset = void 0 === e ? 0 : e),
                  (s.lineJoin = r.getLineJoin() || Tr),
                  (s.lineWidth = void 0 === i ? 1 : i),
                  (s.miterLimit = void 0 === n ? 10 : n),
                  (s.strokeStyle = kr(r.getColor() || Dr));
              } else (s = null), (this.textStrokeState_ = s);
              i = this.textState_;
              const o = t.getFont() || Rr;
              Nr(o);
              const a = t.getScaleArray();
              (i.overflow = t.getOverflow()),
                (i.font = o),
                (i.maxAngle = t.getMaxAngle()),
                (i.placement = t.getPlacement()),
                (i.textAlign = t.getTextAlign()),
                (i.repeat = t.getRepeat()),
                (i.justify = t.getJustify()),
                (i.textBaseline = t.getTextBaseline() || Or),
                (i.backgroundFill = t.getBackgroundFill()),
                (i.backgroundStroke = t.getBackgroundStroke()),
                (i.padding = t.getPadding() || jr),
                (i.scale = void 0 === a ? [1, 1] : a);
              const l = t.getOffsetX(),
                h = t.getOffsetY(),
                c = t.getRotateWithView(),
                u = t.getRotation();
              (this.text_ = t.getText() || ""),
                (this.textOffsetX_ = void 0 === l ? 0 : l),
                (this.textOffsetY_ = void 0 === h ? 0 : h),
                (this.textRotateWithView_ = void 0 !== c && c),
                (this.textRotation_ = void 0 === u ? 0 : u),
                (this.strokeKey_ = s
                  ? ("string" == typeof s.strokeStyle
                      ? s.strokeStyle
                      : F(s.strokeStyle)) +
                    s.lineCap +
                    s.lineDashOffset +
                    "|" +
                    s.lineWidth +
                    s.lineJoin +
                    s.miterLimit +
                    "[" +
                    s.lineDash.join() +
                    "]"
                  : ""),
                (this.textKey_ =
                  i.font +
                  i.scale +
                  (i.textAlign || "?") +
                  (i.repeat || "?") +
                  (i.justify || "?") +
                  (i.textBaseline || "?")),
                (this.fillKey_ =
                  n && n.fillStyle
                    ? "string" == typeof n.fillStyle
                      ? n.fillStyle
                      : "|" + F(n.fillStyle)
                    : "");
            } else this.text_ = "";
            (this.declutterMode_ = t.getDeclutterMode()),
              (this.declutterImageWithText_ = e);
          }
        },
        Fa = {
          Circle: Ma,
          Default: Ca,
          Image: ba,
          LineString: ka,
          Polygon: Ma,
          Text: Pa,
        };
      const La = class {
        constructor(t, e, i, n) {
          (this.tolerance_ = t),
            (this.maxExtent_ = e),
            (this.pixelRatio_ = n),
            (this.resolution_ = i),
            (this.buildersByZIndex_ = {});
        }
        finish() {
          const t = {};
          for (const e in this.buildersByZIndex_) {
            t[e] = t[e] || {};
            const i = this.buildersByZIndex_[e];
            for (const n in i) {
              const s = i[n].finish();
              t[e][n] = s;
            }
          }
          return t;
        }
        getBuilder(t, e) {
          const i = void 0 !== t ? t.toString() : "0";
          let n = this.buildersByZIndex_[i];
          void 0 === n && ((n = {}), (this.buildersByZIndex_[i] = n));
          let s = n[e];
          if (void 0 === s) {
            (s = new (0, Fa[e])(
              this.tolerance_,
              this.maxExtent_,
              this.resolution_,
              this.pixelRatio_
            )),
              (n[e] = s);
          }
          return s;
        }
      };
      const Ta = class extends E {
        constructor(t) {
          super(),
            (this.ready = !0),
            (this.boundHandleImageChange_ = this.handleImageChange_.bind(this)),
            (this.layer_ = t),
            (this.staleKeys_ = new Array()),
            (this.maxStaleKeys = 5);
        }
        getStaleKeys() {
          return this.staleKeys_;
        }
        prependStaleKey(t) {
          this.staleKeys_.unshift(t),
            this.staleKeys_.length > this.maxStaleKeys &&
              (this.staleKeys_.length = this.maxStaleKeys);
        }
        getFeatures(t) {
          return R();
        }
        getData(t) {
          return null;
        }
        prepareFrame(t) {
          return R();
        }
        renderFrame(t, e) {
          return R();
        }
        forEachFeatureAtCoordinate(t, e, i, n, s) {}
        getLayer() {
          return this.layer_;
        }
        handleFontsChanged() {}
        handleImageChange_(t) {
          const e = t.target;
          (e.getState() !== Ns.LOADED && e.getState() !== Ns.ERROR) ||
            this.renderIfReadyAndVisible();
        }
        loadImage(t) {
          let e = t.getState();
          return (
            e != Ns.LOADED &&
              e != Ns.ERROR &&
              t.addEventListener(w, this.boundHandleImageChange_),
            e == Ns.IDLE && (t.load(), (e = t.getState())),
            e == Ns.LOADED
          );
        }
        renderIfReadyAndVisible() {
          const t = this.getLayer();
          t && t.getVisible() && "ready" === t.getSourceState() && t.changed();
        }
        renderDeferred(t) {}
        disposeInternal() {
          delete this.layer_, super.disposeInternal();
        }
      };
      const Da = class extends o {
        constructor(t, e, i, n) {
          super(t),
            (this.inversePixelTransform = e),
            (this.frameState = i),
            (this.context = n);
        }
      };
      const Aa = class {
          constructor() {
            (this.instructions_ = []),
              (this.zIndex = 0),
              (this.offset_ = 0),
              (this.context_ = new Proxy(_r(), {
                get: (t, e) => {
                  if ("function" === typeof _r()[e])
                    return (
                      this.instructions_[this.zIndex + this.offset_] ||
                        (this.instructions_[this.zIndex + this.offset_] = []),
                      this.instructions_[this.zIndex + this.offset_].push(e),
                      this.pushMethodArgs_
                    );
                },
                set: (t, e, i) => (
                  this.instructions_[this.zIndex + this.offset_] ||
                    (this.instructions_[this.zIndex + this.offset_] = []),
                  this.instructions_[this.zIndex + this.offset_].push(e, i),
                  !0
                ),
              }));
          }
          pushMethodArgs_ = (...t) => (
            this.instructions_[this.zIndex + this.offset_].push(t), this
          );
          pushFunction(t) {
            this.instructions_[this.zIndex + this.offset_].push(t);
          }
          getContext() {
            return this.context_;
          }
          draw(t) {
            this.instructions_.forEach((e) => {
              for (let i = 0, n = e.length; i < n; ++i) {
                const n = e[i];
                if ("function" === typeof n) {
                  n(t);
                  continue;
                }
                const s = e[++i];
                if ("function" === typeof t[n]) t[n](...s);
                else {
                  if ("function" === typeof s) {
                    t[n] = s(t);
                    continue;
                  }
                  t[n] = s;
                }
              }
            });
          }
          clear() {
            (this.instructions_.length = 0),
              (this.zIndex = 0),
              (this.offset_ = 0);
          }
          offset() {
            (this.offset_ = this.instructions_.length), (this.zIndex = 0);
          }
        },
        Oa = [];
      let ja = null;
      const Ga = class extends Ta {
        constructor(t) {
          super(t),
            (this.container = null),
            this.renderedResolution,
            (this.tempTransform = [1, 0, 0, 1, 0, 0]),
            (this.pixelTransform = [1, 0, 0, 1, 0, 0]),
            (this.inversePixelTransform = [1, 0, 0, 1, 0, 0]),
            (this.context = null),
            (this.deferredContext_ = null),
            (this.containerReused = !1),
            (this.frameState = null);
        }
        getImageData(t, e, i) {
          let n;
          ja || (ja = pr(1, 1, void 0, { willReadFrequently: !0 })),
            ja.clearRect(0, 0, 1, 1);
          try {
            ja.drawImage(t, e, i, 1, 1, 0, 0, 1, 1),
              (n = ja.getImageData(0, 0, 1, 1).data);
          } catch (s) {
            return (ja = null), null;
          }
          return n;
        }
        getBackground(t) {
          let e = this.getLayer().getBackground();
          return (
            "function" === typeof e && (e = e(t.viewState.resolution)),
            e || void 0
          );
        }
        useContainer(t, e, i) {
          const n = this.getLayer().getClassName();
          let s, r;
          if (
            t &&
            t.className === n &&
            (!i ||
              (t &&
                t.style.backgroundColor &&
                g(hr(t.style.backgroundColor), hr(i))))
          ) {
            const e = t.firstElementChild;
            e instanceof HTMLCanvasElement && (r = e.getContext("2d"));
          }
          if (
            (r && r.canvas.style.transform === e
              ? ((this.container = t),
                (this.context = r),
                (this.containerReused = !0))
              : this.containerReused
              ? ((this.container = null),
                (this.context = null),
                (this.containerReused = !1))
              : this.container && (this.container.style.backgroundColor = null),
            !this.container)
          ) {
            (s = document.createElement("div")), (s.className = n);
            let t = s.style;
            (t.position = "absolute"),
              (t.width = "100%"),
              (t.height = "100%"),
              (r = pr());
            const e = r.canvas;
            s.appendChild(e),
              (t = e.style),
              (t.position = "absolute"),
              (t.left = "0"),
              (t.transformOrigin = "top left"),
              (this.container = s),
              (this.context = r);
          }
          this.containerReused ||
            !i ||
            this.container.style.backgroundColor ||
            (this.container.style.backgroundColor = i);
        }
        clipUnrotated(t, e, i) {
          const n = Rt(i),
            s = Pt(i),
            r = kt(i),
            o = bt(i);
          jt(e.coordinateToPixelTransform, n),
            jt(e.coordinateToPixelTransform, s),
            jt(e.coordinateToPixelTransform, r),
            jt(e.coordinateToPixelTransform, o);
          const a = this.inversePixelTransform;
          jt(a, n),
            jt(a, s),
            jt(a, r),
            jt(a, o),
            t.save(),
            t.beginPath(),
            t.moveTo(Math.round(n[0]), Math.round(n[1])),
            t.lineTo(Math.round(s[0]), Math.round(s[1])),
            t.lineTo(Math.round(r[0]), Math.round(r[1])),
            t.lineTo(Math.round(o[0]), Math.round(o[1])),
            t.clip();
        }
        prepareContainer(t, e) {
          const i = t.extent,
            n = t.viewState.resolution,
            s = t.viewState.rotation,
            r = t.pixelRatio,
            o = Math.round((Ft(i) / n) * r),
            a = Math.round((Et(i) / n) * r);
          Gt(
            this.pixelTransform,
            t.size[0] / 2,
            t.size[1] / 2,
            1 / r,
            1 / r,
            s,
            -o / 2,
            -a / 2
          ),
            Zt(this.inversePixelTransform, this.pixelTransform);
          const l = Bt(this.pixelTransform);
          if (
            (this.useContainer(e, l, this.getBackground(t)),
            !this.containerReused)
          ) {
            const t = this.context.canvas;
            t.width != o || t.height != a
              ? ((t.width = o), (t.height = a))
              : this.context.clearRect(0, 0, o, a),
              l !== t.style.transform && (t.style.transform = l);
          }
        }
        dispatchRenderEvent_(t, e, i) {
          const n = this.getLayer();
          if (n.hasListener(t)) {
            const s = new Da(t, this.inversePixelTransform, i, e);
            n.dispatchEvent(s);
          }
        }
        preRender(t, e) {
          (this.frameState = e),
            e.declutter || this.dispatchRenderEvent_(Ss, t, e);
        }
        postRender(t, e) {
          e.declutter || this.dispatchRenderEvent_(Cs, t, e);
        }
        renderDeferredInternal(t) {}
        getRenderContext(t) {
          return (
            t.declutter &&
              !this.deferredContext_ &&
              (this.deferredContext_ = new Aa()),
            t.declutter ? this.deferredContext_.getContext() : this.context
          );
        }
        renderDeferred(t) {
          t.declutter &&
            (this.dispatchRenderEvent_(Ss, this.context, t),
            t.declutter &&
              this.deferredContext_ &&
              (this.deferredContext_.draw(this.context),
              this.deferredContext_.clear()),
            this.renderDeferredInternal(t),
            this.dispatchRenderEvent_(Cs, this.context, t));
        }
        getRenderTransform(t, e, i, n, s, r, o) {
          const a = s / 2,
            l = r / 2,
            h = n / e,
            c = -h,
            u = -t[0] + o,
            d = -t[1];
          return Gt(this.tempTransform, a, l, h, c, -i, u, d);
        }
        disposeInternal() {
          delete this.frameState, super.disposeInternal();
        }
      };
      function Za(t, e, i, n, s, r, o, a, l, h, c, u) {
        let d = t[e],
          g = t[e + 1],
          f = 0,
          p = 0,
          m = 0,
          _ = 0;
        function y() {
          (f = d),
            (p = g),
            (d = t[(e += n)]),
            (g = t[e + 1]),
            (_ += m),
            (m = Math.sqrt((d - f) * (d - f) + (g - p) * (g - p)));
        }
        do {
          y();
        } while (e < i - n && _ + m < r);
        let x = 0 === m ? 0 : (r - _) / m;
        const v = qt(f, d, x),
          w = qt(p, g, x),
          S = e - n,
          C = _,
          b = r + a * l(h, s, c);
        for (; e < i - n && _ + m < b; ) y();
        x = 0 === m ? 0 : (b - _) / m;
        const k = qt(f, d, x),
          M = qt(p, g, x);
        let I;
        if (u) {
          const t = [v, w, k, M];
          ri(t, 0, 4, 2, u, t, t), (I = t[0] > t[2]);
        } else I = v > k;
        const E = Math.PI,
          R = [],
          P = S + n === e;
        let F;
        if (((m = 0), (_ = C), (d = t[(e = S)]), (g = t[e + 1]), P)) {
          y(), (F = Math.atan2(g - p, d - f)), I && (F += F > 0 ? -E : E);
          const t = (k + v) / 2,
            e = (M + w) / 2;
          return (R[0] = [t, e, (b - r) / 2, F, s]), R;
        }
        for (let L = 0, T = (s = s.replace(/\n/g, " ")).length; L < T; ) {
          y();
          let t = Math.atan2(g - p, d - f);
          if ((I && (t += t > 0 ? -E : E), void 0 !== F)) {
            let e = t - F;
            if (((e += e > E ? -2 * E : e < -E ? 2 * E : 0), Math.abs(e) > o))
              return null;
          }
          F = t;
          const u = L;
          let v = 0;
          for (; L < T; ++L) {
            const t = a * l(h, s[I ? T - L - 1 : L], c);
            if (e + n < i && _ + m < r + v + t / 2) break;
            v += t;
          }
          if (L === u) continue;
          const w = I ? s.substring(T - u, T - L) : s.substring(u, L);
          x = 0 === m ? 0 : (r + v / 2 - _) / m;
          const S = qt(f, d, x),
            C = qt(p, g, x);
          R.push([S, C, v / 2, t, w]), (r += v);
        }
        return R;
      }
      const za = [1 / 0, 1 / 0, -1 / 0, -1 / 0],
        Ba = [],
        Na = [],
        Wa = [],
        Xa = [];
      function Ya(t) {
        return t[3].declutterBox;
      }
      const Va = new RegExp(
        "[" +
          String.fromCharCode(1425) +
          "-" +
          String.fromCharCode(2303) +
          String.fromCharCode(64285) +
          "-" +
          String.fromCharCode(65023) +
          String.fromCharCode(65136) +
          "-" +
          String.fromCharCode(65276) +
          String.fromCharCode(67584) +
          "-" +
          String.fromCharCode(69631) +
          String.fromCharCode(124928) +
          "-" +
          String.fromCharCode(126975) +
          "]"
      );
      function qa(t, e) {
        return (
          "start" === e
            ? (e = Va.test(t) ? "right" : "left")
            : "end" === e && (e = Va.test(t) ? "left" : "right"),
          Ra[e]
        );
      }
      function $a(t, e, i) {
        return i > 0 && t.push("\n", ""), t.push(e, ""), t;
      }
      const Ua = class {
          constructor(t, e, i, n, s) {
            (this.overlaps = i),
              (this.pixelRatio = e),
              (this.resolution = t),
              this.alignAndScaleFill_,
              (this.instructions = n.instructions),
              (this.coordinates = n.coordinates),
              (this.coordinateCache_ = {}),
              (this.renderedTransform_ = [1, 0, 0, 1, 0, 0]),
              (this.hitDetectionInstructions = n.hitDetectionInstructions),
              (this.pixelCoordinates_ = null),
              (this.viewRotation_ = 0),
              (this.fillStates = n.fillStates || {}),
              (this.strokeStates = n.strokeStates || {}),
              (this.textStates = n.textStates || {}),
              (this.widths_ = {}),
              (this.labels_ = {}),
              (this.zIndexContext_ = s ? new Aa() : null);
          }
          getZIndexContext() {
            return this.zIndexContext_;
          }
          createLabel(t, e, i, n) {
            const s = t + e + i + n;
            if (this.labels_[s]) return this.labels_[s];
            const r = n ? this.strokeStates[n] : null,
              o = i ? this.fillStates[i] : null,
              a = this.textStates[e],
              l = this.pixelRatio,
              h = [a.scale[0] * l, a.scale[1] * l],
              c = a.justify
                ? Ra[a.justify]
                : qa(Array.isArray(t) ? t[0] : t, a.textAlign || Ar),
              u = n && r.lineWidth ? r.lineWidth : 0,
              d = Array.isArray(t) ? t : String(t).split("\n").reduce($a, []),
              {
                width: g,
                height: f,
                widths: p,
                heights: m,
                lineWidths: _,
              } = (function (t, e) {
                const i = [],
                  n = [],
                  s = [];
                let r = 0,
                  o = 0,
                  a = 0,
                  l = 0;
                for (let h = 0, c = e.length; h <= c; h += 2) {
                  const u = e[h];
                  if ("\n" === u || h === c) {
                    (r = Math.max(r, o)), s.push(o), (o = 0), (a += l), (l = 0);
                    continue;
                  }
                  const d = e[h + 1] || t.font,
                    g = Yr(d, u);
                  i.push(g), (o += g);
                  const f = Wr(d);
                  n.push(f), (l = Math.max(l, f));
                }
                return {
                  width: r,
                  height: a,
                  widths: i,
                  heights: n,
                  lineWidths: s,
                };
              })(a, d),
              y = g + u,
              x = [],
              v = (y + 2) * h[0],
              w = (f + u) * h[1],
              S = {
                width: v < 0 ? Math.floor(v) : Math.ceil(v),
                height: w < 0 ? Math.floor(w) : Math.ceil(w),
                contextInstructions: x,
              };
            (1 == h[0] && 1 == h[1]) || x.push("scale", h),
              n &&
                (x.push("strokeStyle", r.strokeStyle),
                x.push("lineWidth", u),
                x.push("lineCap", r.lineCap),
                x.push("lineJoin", r.lineJoin),
                x.push("miterLimit", r.miterLimit),
                x.push("setLineDash", [r.lineDash]),
                x.push("lineDashOffset", r.lineDashOffset)),
              i && x.push("fillStyle", o.fillStyle),
              x.push("textBaseline", "middle"),
              x.push("textAlign", "center");
            const C = 0.5 - c;
            let b = c * y + C * u;
            const k = [],
              M = [];
            let I,
              E = 0,
              R = 0,
              P = 0,
              F = 0;
            for (let L = 0, T = d.length; L < T; L += 2) {
              const t = d[L];
              if ("\n" === t) {
                (R += E), (E = 0), (b = c * y + C * u), ++F;
                continue;
              }
              const e = d[L + 1] || a.font;
              e !== I &&
                (n && k.push("font", e), i && M.push("font", e), (I = e)),
                (E = Math.max(E, m[P]));
              const s = [
                t,
                b + C * p[P] + c * (p[P] - _[F]),
                0.5 * (u + E) + R,
              ];
              (b += p[P]),
                n && k.push("strokeText", s),
                i && M.push("fillText", s),
                ++P;
            }
            return (
              Array.prototype.push.apply(x, k),
              Array.prototype.push.apply(x, M),
              (this.labels_[s] = S),
              S
            );
          }
          replayTextBackground_(t, e, i, n, s, r, o) {
            t.beginPath(),
              t.moveTo.apply(t, e),
              t.lineTo.apply(t, i),
              t.lineTo.apply(t, n),
              t.lineTo.apply(t, s),
              t.lineTo.apply(t, e),
              r && ((this.alignAndScaleFill_ = r[2]), this.fill_(t)),
              o && (this.setStrokeStyle_(t, o), t.stroke());
          }
          calculateImageOrLabelDimensions_(
            t,
            e,
            i,
            n,
            s,
            r,
            o,
            a,
            l,
            h,
            c,
            u,
            d,
            g,
            f,
            p
          ) {
            let m = i - (o *= u[0]),
              _ = n - (a *= u[1]);
            const y = s + l > t ? t - l : s,
              x = r + h > e ? e - h : r,
              v = g[3] + y * u[0] + g[1],
              w = g[0] + x * u[1] + g[2],
              S = m - g[3],
              C = _ - g[0];
            let b;
            return (
              (f || 0 !== c) &&
                ((Ba[0] = S),
                (Xa[0] = S),
                (Ba[1] = C),
                (Na[1] = C),
                (Na[0] = S + v),
                (Wa[0] = Na[0]),
                (Wa[1] = C + w),
                (Xa[1] = Wa[1])),
              0 !== c
                ? ((b = Gt([1, 0, 0, 1, 0, 0], i, n, 1, 1, c, -i, -n)),
                  jt(b, Ba),
                  jt(b, Na),
                  jt(b, Wa),
                  jt(b, Xa),
                  ft(
                    Math.min(Ba[0], Na[0], Wa[0], Xa[0]),
                    Math.min(Ba[1], Na[1], Wa[1], Xa[1]),
                    Math.max(Ba[0], Na[0], Wa[0], Xa[0]),
                    Math.max(Ba[1], Na[1], Wa[1], Xa[1]),
                    za
                  ))
                : ft(
                    Math.min(S, S + v),
                    Math.min(C, C + w),
                    Math.max(S, S + v),
                    Math.max(C, C + w),
                    za
                  ),
              d && ((m = Math.round(m)), (_ = Math.round(_))),
              {
                drawImageX: m,
                drawImageY: _,
                drawImageW: y,
                drawImageH: x,
                originX: l,
                originY: h,
                declutterBox: {
                  minX: za[0],
                  minY: za[1],
                  maxX: za[2],
                  maxY: za[3],
                  value: p,
                },
                canvasTransform: b,
                scale: u,
              }
            );
          }
          replayImageOrLabel_(t, e, i, n, s, r, o) {
            const a = !(!r && !o),
              l = n.declutterBox,
              h = o ? (o[2] * n.scale[0]) / 2 : 0;
            return (
              l.minX - h <= e[0] &&
                l.maxX + h >= 0 &&
                l.minY - h <= e[1] &&
                l.maxY + h >= 0 &&
                (a && this.replayTextBackground_(t, Ba, Na, Wa, Xa, r, o),
                qr(
                  t,
                  n.canvasTransform,
                  s,
                  i,
                  n.originX,
                  n.originY,
                  n.drawImageW,
                  n.drawImageH,
                  n.drawImageX,
                  n.drawImageY,
                  n.scale
                )),
              !0
            );
          }
          fill_(t) {
            const e = this.alignAndScaleFill_;
            if (e) {
              const i = jt(this.renderedTransform_, [0, 0]),
                n = 512 * this.pixelRatio;
              t.save(),
                t.translate(i[0] % n, i[1] % n),
                1 !== e && t.scale(e, e),
                t.rotate(this.viewRotation_);
            }
            t.fill(), e && t.restore();
          }
          setStrokeStyle_(t, e) {
            (t.strokeStyle = e[1]),
              (t.lineWidth = e[2]),
              (t.lineCap = e[3]),
              (t.lineJoin = e[4]),
              (t.miterLimit = e[5]),
              (t.lineDashOffset = e[7]),
              t.setLineDash(e[6]);
          }
          drawLabelWithPointPlacement_(t, e, i, n) {
            const s = this.textStates[e],
              r = this.createLabel(t, e, n, i),
              o = this.strokeStates[i],
              a = this.pixelRatio,
              l = qa(Array.isArray(t) ? t[0] : t, s.textAlign || Ar),
              h = Ra[s.textBaseline || Or],
              c = o && o.lineWidth ? o.lineWidth : 0;
            return {
              label: r,
              anchorX: l * (r.width / a - 2 * s.scale[0]) + 2 * (0.5 - l) * c,
              anchorY: (h * r.height) / a + 2 * (0.5 - h) * c,
            };
          }
          execute_(t, e, i, n, s, r, o, a) {
            const l = this.zIndexContext_;
            let h;
            var c, u;
            this.pixelCoordinates_ && g(i, this.renderedTransform_)
              ? (h = this.pixelCoordinates_)
              : (this.pixelCoordinates_ || (this.pixelCoordinates_ = []),
                (h = si(
                  this.coordinates,
                  0,
                  this.coordinates.length,
                  2,
                  i,
                  this.pixelCoordinates_
                )),
                (c = this.renderedTransform_),
                (u = i),
                (c[0] = u[0]),
                (c[1] = u[1]),
                (c[2] = u[2]),
                (c[3] = u[3]),
                (c[4] = u[4]),
                (c[5] = u[5]));
            let d = 0;
            const f = n.length;
            let p,
              m,
              _,
              y,
              x,
              v,
              w,
              S,
              C,
              b,
              k,
              M,
              I,
              E = 0,
              R = 0,
              P = 0,
              F = null,
              L = null;
            const T = this.coordinateCache_,
              D = this.viewRotation_,
              A = Math.round(1e12 * Math.atan2(-i[1], i[0])) / 1e12,
              O = {
                context: t,
                pixelRatio: this.pixelRatio,
                resolution: this.resolution,
                rotation: D,
              },
              j = this.instructions != n || this.overlaps ? 0 : 200;
            let G, Z, z, B;
            for (; d < f; ) {
              const i = n[d];
              switch (i[0]) {
                case wa.BEGIN_GEOMETRY:
                  (G = i[1]),
                    (B = i[3]),
                    G.getGeometry()
                      ? void 0 === o || Lt(o, B.getExtent())
                        ? ++d
                        : (d = i[2] + 1)
                      : (d = i[2]),
                    l && (l.zIndex = i[4]);
                  break;
                case wa.BEGIN_PATH:
                  R > j && (this.fill_(t), (R = 0)),
                    P > j && (t.stroke(), (P = 0)),
                    R || P || (t.beginPath(), (x = NaN), (v = NaN)),
                    ++d;
                  break;
                case wa.CIRCLE:
                  E = i[1];
                  const n = h[E],
                    c = h[E + 1],
                    u = h[E + 2] - n,
                    g = h[E + 3] - c,
                    f = Math.sqrt(u * u + g * g);
                  t.moveTo(n + f, c), t.arc(n, c, f, 0, 2 * Math.PI, !0), ++d;
                  break;
                case wa.CLOSE_PATH:
                  t.closePath(), ++d;
                  break;
                case wa.CUSTOM:
                  (E = i[1]), (p = i[2]);
                  const N = i[3],
                    W = i[4],
                    X = i[5];
                  (O.geometry = N), (O.feature = G), d in T || (T[d] = []);
                  const Y = T[d];
                  X
                    ? X(h, E, p, 2, Y)
                    : ((Y[0] = h[E]), (Y[1] = h[E + 1]), (Y.length = 2)),
                    l && (l.zIndex = i[6]),
                    W(Y, O),
                    ++d;
                  break;
                case wa.DRAW_IMAGE:
                  (E = i[1]), (p = i[2]), (C = i[3]), (m = i[4]), (_ = i[5]);
                  let V = i[6];
                  const q = i[7],
                    $ = i[8],
                    U = i[9],
                    H = i[10];
                  let K = i[11];
                  const J = i[12];
                  let Q = i[13];
                  y = i[14] || "declutter";
                  const tt = i[15];
                  if (!C && i.length >= 20) {
                    (b = i[19]), (k = i[20]), (M = i[21]), (I = i[22]);
                    const t = this.drawLabelWithPointPlacement_(b, k, M, I);
                    (C = t.label), (i[3] = C);
                    const e = i[23];
                    (m = (t.anchorX - e) * this.pixelRatio), (i[4] = m);
                    const n = i[24];
                    (_ = (t.anchorY - n) * this.pixelRatio),
                      (i[5] = _),
                      (V = C.height),
                      (i[6] = V),
                      (Q = C.width),
                      (i[13] = Q);
                  }
                  let et, it, nt, st;
                  i.length > 25 && (et = i[25]),
                    i.length > 17
                      ? ((it = i[16]), (nt = i[17]), (st = i[18]))
                      : ((it = jr), (nt = !1), (st = !1)),
                    H && A ? (K += D) : H || A || (K -= D);
                  let rt = 0;
                  for (; E < p; E += 2) {
                    if (et && et[rt++] < Q / this.pixelRatio) continue;
                    const i = this.calculateImageOrLabelDimensions_(
                        C.width,
                        C.height,
                        h[E],
                        h[E + 1],
                        Q,
                        V,
                        m,
                        _,
                        $,
                        U,
                        K,
                        J,
                        s,
                        it,
                        nt || st,
                        G
                      ),
                      n = [t, e, C, i, q, nt ? F : null, st ? L : null];
                    if (a) {
                      let t, e, s, r, o;
                      if (tt) {
                        const i = p - E;
                        if (!tt[i]) {
                          tt[i] = { args: n, declutterMode: y };
                          continue;
                        }
                        const r = tt[i];
                        (t = r.args),
                          (e = r.declutterMode),
                          delete tt[i],
                          (s = Ya(t));
                      }
                      if (
                        (!t || ("declutter" === e && a.collides(s)) || (r = !0),
                        ("declutter" === y && a.collides(i.declutterBox)) ||
                          (o = !0),
                        "declutter" === e && "declutter" === y)
                      ) {
                        const t = r && o;
                        (r = t), (o = t);
                      }
                      r &&
                        ("none" !== e && a.insert(s),
                        this.replayImageOrLabel_.apply(this, t)),
                        o &&
                          ("none" !== y && a.insert(i.declutterBox),
                          this.replayImageOrLabel_.apply(this, n));
                    } else this.replayImageOrLabel_.apply(this, n);
                  }
                  ++d;
                  break;
                case wa.DRAW_CHARS:
                  const ot = i[1],
                    at = i[2],
                    lt = i[3],
                    ht = i[4];
                  I = i[5];
                  const ct = i[6],
                    ut = i[7],
                    dt = i[8];
                  M = i[9];
                  const gt = i[10];
                  (b = i[11]), (k = i[12]);
                  const ft = [i[13], i[13]];
                  y = i[14] || "declutter";
                  const pt = this.textStates[k],
                    mt = pt.font,
                    _t = [pt.scale[0] * ut, pt.scale[1] * ut];
                  let yt;
                  mt in this.widths_
                    ? (yt = this.widths_[mt])
                    : ((yt = {}), (this.widths_[mt] = yt));
                  const xt = $i(h, ot, at, 2),
                    vt = Math.abs(_t[0]) * Vr(mt, b, yt);
                  if (ht || vt <= xt) {
                    const i = Za(
                      h,
                      ot,
                      at,
                      2,
                      b,
                      (xt - vt) * qa(b, this.textStates[k].textAlign),
                      ct,
                      Math.abs(_t[0]),
                      Vr,
                      mt,
                      yt,
                      A ? 0 : this.viewRotation_
                    );
                    t: if (i) {
                      const n = [];
                      let s, r, o, l, h;
                      if (M)
                        for (s = 0, r = i.length; s < r; ++s) {
                          (h = i[s]),
                            (o = h[4]),
                            (l = this.createLabel(o, k, "", M)),
                            (m = h[2] + (_t[0] < 0 ? -gt : gt)),
                            (_ =
                              lt * l.height +
                              (2 * (0.5 - lt) * gt * _t[1]) / _t[0] -
                              dt);
                          const r = this.calculateImageOrLabelDimensions_(
                            l.width,
                            l.height,
                            h[0],
                            h[1],
                            l.width,
                            l.height,
                            m,
                            _,
                            0,
                            0,
                            h[3],
                            ft,
                            !1,
                            jr,
                            !1,
                            G
                          );
                          if (
                            a &&
                            "declutter" === y &&
                            a.collides(r.declutterBox)
                          )
                            break t;
                          n.push([t, e, l, r, 1, null, null]);
                        }
                      if (I)
                        for (s = 0, r = i.length; s < r; ++s) {
                          (h = i[s]),
                            (o = h[4]),
                            (l = this.createLabel(o, k, I, "")),
                            (m = h[2]),
                            (_ = lt * l.height - dt);
                          const r = this.calculateImageOrLabelDimensions_(
                            l.width,
                            l.height,
                            h[0],
                            h[1],
                            l.width,
                            l.height,
                            m,
                            _,
                            0,
                            0,
                            h[3],
                            ft,
                            !1,
                            jr,
                            !1,
                            G
                          );
                          if (
                            a &&
                            "declutter" === y &&
                            a.collides(r.declutterBox)
                          )
                            break t;
                          n.push([t, e, l, r, 1, null, null]);
                        }
                      a && "none" !== y && a.load(n.map(Ya));
                      for (let t = 0, e = n.length; t < e; ++t)
                        this.replayImageOrLabel_.apply(this, n[t]);
                    }
                  }
                  ++d;
                  break;
                case wa.END_GEOMETRY:
                  if (void 0 !== r) {
                    G = i[1];
                    const t = r(G, B, y);
                    if (t) return t;
                  }
                  ++d;
                  break;
                case wa.FILL:
                  j ? R++ : this.fill_(t), ++d;
                  break;
                case wa.MOVE_TO_LINE_TO:
                  for (
                    E = i[1],
                      p = i[2],
                      Z = h[E],
                      z = h[E + 1],
                      t.moveTo(Z, z),
                      x = (Z + 0.5) | 0,
                      v = (z + 0.5) | 0,
                      E += 2;
                    E < p;
                    E += 2
                  )
                    (Z = h[E]),
                      (z = h[E + 1]),
                      (w = (Z + 0.5) | 0),
                      (S = (z + 0.5) | 0),
                      (E != p - 2 && w === x && S === v) ||
                        (t.lineTo(Z, z), (x = w), (v = S));
                  ++d;
                  break;
                case wa.SET_FILL_STYLE:
                  (F = i),
                    (this.alignAndScaleFill_ = i[2]),
                    R && (this.fill_(t), (R = 0), P && (t.stroke(), (P = 0))),
                    (t.fillStyle = i[1]),
                    ++d;
                  break;
                case wa.SET_STROKE_STYLE:
                  (L = i),
                    P && (t.stroke(), (P = 0)),
                    this.setStrokeStyle_(t, i),
                    ++d;
                  break;
                case wa.STROKE:
                  j ? P++ : t.stroke(), ++d;
                  break;
                default:
                  ++d;
              }
            }
            R && this.fill_(t), P && t.stroke();
          }
          execute(t, e, i, n, s, r) {
            (this.viewRotation_ = n),
              this.execute_(t, e, i, this.instructions, s, void 0, void 0, r);
          }
          executeHitDetection(t, e, i, n, s) {
            return (
              (this.viewRotation_ = i),
              this.execute_(
                t,
                [t.canvas.width, t.canvas.height],
                e,
                this.hitDetectionInstructions,
                !0,
                n,
                s
              )
            );
          }
        },
        Ha = ["Polygon", "Circle", "LineString", "Image", "Text", "Default"],
        Ka = ["Image", "Text"],
        Ja = Ha.filter((t) => !Ka.includes(t));
      const Qa = {};
      const tl = class {
        constructor(t, e, i, n, s, r, o) {
          (this.maxExtent_ = t),
            (this.overlaps_ = n),
            (this.pixelRatio_ = i),
            (this.resolution_ = e),
            (this.renderBuffer_ = r),
            (this.executorsByZIndex_ = {}),
            (this.hitDetectionContext_ = null),
            (this.hitDetectionTransform_ = [1, 0, 0, 1, 0, 0]),
            (this.renderedContext_ = null),
            (this.deferredZIndexContexts_ = {}),
            this.createExecutors_(s, o);
        }
        clip(t, e) {
          const i = this.getClipCoords(e);
          t.beginPath(),
            t.moveTo(i[0], i[1]),
            t.lineTo(i[2], i[3]),
            t.lineTo(i[4], i[5]),
            t.lineTo(i[6], i[7]),
            t.clip();
        }
        createExecutors_(t, e) {
          for (const i in t) {
            let n = this.executorsByZIndex_[i];
            void 0 === n && ((n = {}), (this.executorsByZIndex_[i] = n));
            const s = t[i];
            for (const t in s) {
              const i = s[t];
              n[t] = new Ua(
                this.resolution_,
                this.pixelRatio_,
                this.overlaps_,
                i,
                e
              );
            }
          }
        }
        hasExecutors(t) {
          for (const e in this.executorsByZIndex_) {
            const i = this.executorsByZIndex_[e];
            for (let e = 0, n = t.length; e < n; ++e) if (t[e] in i) return !0;
          }
          return !1;
        }
        forEachFeatureAtCoordinate(t, e, i, n, s, r) {
          const o = 2 * (n = Math.round(n)) + 1,
            a = Gt(
              this.hitDetectionTransform_,
              n + 0.5,
              n + 0.5,
              1 / e,
              -1 / e,
              -i,
              -t[0],
              -t[1]
            ),
            l = !this.hitDetectionContext_;
          l &&
            (this.hitDetectionContext_ = pr(o, o, void 0, {
              willReadFrequently: !0,
            }));
          const c = this.hitDetectionContext_;
          let u;
          c.canvas.width !== o || c.canvas.height !== o
            ? ((c.canvas.width = o), (c.canvas.height = o))
            : l || c.clearRect(0, 0, o, o),
            void 0 !== this.renderBuffer_ &&
              ((u = [1 / 0, 1 / 0, -1 / 0, -1 / 0]),
              vt(u, t),
              at(u, e * (this.renderBuffer_ + n), u));
          const d = (function (t) {
            if (void 0 !== Qa[t]) return Qa[t];
            const e = 2 * t + 1,
              i = t * t,
              n = new Array(i + 1);
            for (let r = 0; r <= t; ++r)
              for (let s = 0; s <= t; ++s) {
                const o = r * r + s * s;
                if (o > i) break;
                let a = n[o];
                a || ((a = []), (n[o] = a)),
                  a.push(4 * ((t + r) * e + (t + s)) + 3),
                  r > 0 && a.push(4 * ((t - r) * e + (t + s)) + 3),
                  s > 0 &&
                    (a.push(4 * ((t + r) * e + (t - s)) + 3),
                    r > 0 && a.push(4 * ((t - r) * e + (t - s)) + 3));
              }
            const s = [];
            for (let r = 0, o = n.length; r < o; ++r) n[r] && s.push(...n[r]);
            return (Qa[t] = s), s;
          })(n);
          let g;
          function f(t, e, i) {
            const a = c.getImageData(0, 0, o, o).data;
            for (let l = 0, h = d.length; l < h; l++)
              if (a[d[l]] > 0) {
                if (
                  !r ||
                  "none" === i ||
                  ("Image" !== g && "Text" !== g) ||
                  r.includes(t)
                ) {
                  const i = (d[l] - 3) / 4,
                    r = n - (i % o),
                    a = n - ((i / o) | 0),
                    h = s(t, e, r * r + a * a);
                  if (h) return h;
                }
                c.clearRect(0, 0, o, o);
                break;
              }
          }
          const p = Object.keys(this.executorsByZIndex_).map(Number);
          let m, _, y, x, v;
          for (p.sort(h), m = p.length - 1; m >= 0; --m) {
            const t = p[m].toString();
            for (y = this.executorsByZIndex_[t], _ = Ha.length - 1; _ >= 0; --_)
              if (
                ((g = Ha[_]),
                (x = y[g]),
                void 0 !== x && ((v = x.executeHitDetection(c, a, i, f, u)), v))
              )
                return v;
          }
        }
        getClipCoords(t) {
          const e = this.maxExtent_;
          if (!e) return null;
          const i = e[0],
            n = e[1],
            s = e[2],
            r = e[3],
            o = [i, n, i, r, s, r, s, n];
          return si(o, 0, 8, 2, t, o), o;
        }
        isEmpty() {
          return x(this.executorsByZIndex_);
        }
        execute(t, e, i, n, s, r, o) {
          const a = Object.keys(this.executorsByZIndex_).map(Number);
          a.sort(h), (r = r || Ha);
          const l = Ha.length;
          let c, u, d, g, f;
          for (o && a.reverse(), c = 0, u = a.length; c < u; ++c) {
            const h = a[c].toString();
            for (
              f = this.executorsByZIndex_[h], d = 0, g = r.length;
              d < g;
              ++d
            ) {
              const h = r[d],
                u = f[h];
              if (void 0 !== u) {
                const r = null === o ? void 0 : u.getZIndexContext(),
                  g = r ? r.getContext() : t,
                  f = this.maxExtent_ && "Image" !== h && "Text" !== h;
                if (
                  (f && (g.save(), this.clip(g, i)),
                  r && "Text" !== h && "Image" !== h
                    ? r.pushFunction((t) => u.execute(t, e, i, n, s, o))
                    : u.execute(g, e, i, n, s, o),
                  f && g.restore(),
                  r)
                ) {
                  r.offset();
                  const t = a[c] * l + d;
                  this.deferredZIndexContexts_[t] ||
                    (this.deferredZIndexContexts_[t] = []),
                    this.deferredZIndexContexts_[t].push(r);
                }
              }
            }
          }
          this.renderedContext_ = t;
        }
        getDeferredZIndexContexts() {
          return this.deferredZIndexContexts_;
        }
        getRenderedContext() {
          return this.renderedContext_;
        }
        renderDeferred() {
          const t = this.deferredZIndexContexts_,
            e = Object.keys(t).map(Number).sort(h);
          for (let i = 0, n = e.length; i < n; ++i)
            t[e[i]].forEach((t) => {
              t.draw(this.renderedContext_), t.clear();
            }),
              (t[e[i]].length = 0);
        }
      };
      const el = class extends Sa {
          constructor(t, e, i, n, s, r, o) {
            super(),
              (this.context_ = t),
              (this.pixelRatio_ = e),
              (this.extent_ = i),
              (this.transform_ = n),
              (this.transformRotation_ = n
                ? $t(Math.atan2(n[1], n[0]), 10)
                : 0),
              (this.viewRotation_ = s),
              (this.squaredTolerance_ = r),
              (this.userTransform_ = o),
              (this.contextFillState_ = null),
              (this.contextStrokeState_ = null),
              (this.contextTextState_ = null),
              (this.fillState_ = null),
              (this.strokeState_ = null),
              (this.image_ = null),
              (this.imageAnchorX_ = 0),
              (this.imageAnchorY_ = 0),
              (this.imageHeight_ = 0),
              (this.imageOpacity_ = 0),
              (this.imageOriginX_ = 0),
              (this.imageOriginY_ = 0),
              (this.imageRotateWithView_ = !1),
              (this.imageRotation_ = 0),
              (this.imageScale_ = [0, 0]),
              (this.imageWidth_ = 0),
              (this.text_ = ""),
              (this.textOffsetX_ = 0),
              (this.textOffsetY_ = 0),
              (this.textRotateWithView_ = !1),
              (this.textRotation_ = 0),
              (this.textScale_ = [0, 0]),
              (this.textFillState_ = null),
              (this.textStrokeState_ = null),
              (this.textState_ = null),
              (this.pixelCoordinates_ = []),
              (this.tmpLocalTransform_ = [1, 0, 0, 1, 0, 0]);
          }
          drawImages_(t, e, i, n) {
            if (!this.image_) return;
            const s = si(t, e, i, n, this.transform_, this.pixelCoordinates_),
              r = this.context_,
              o = this.tmpLocalTransform_,
              a = r.globalAlpha;
            1 != this.imageOpacity_ && (r.globalAlpha = a * this.imageOpacity_);
            let l = this.imageRotation_;
            0 === this.transformRotation_ && (l -= this.viewRotation_),
              this.imageRotateWithView_ && (l += this.viewRotation_);
            for (let h = 0, c = s.length; h < c; h += 2) {
              const t = s[h] - this.imageAnchorX_,
                e = s[h + 1] - this.imageAnchorY_;
              if (
                0 !== l ||
                1 != this.imageScale_[0] ||
                1 != this.imageScale_[1]
              ) {
                const i = t + this.imageAnchorX_,
                  n = e + this.imageAnchorY_;
                Gt(o, i, n, 1, 1, l, -i, -n),
                  r.save(),
                  r.transform.apply(r, o),
                  r.translate(i, n),
                  r.scale(this.imageScale_[0], this.imageScale_[1]),
                  r.drawImage(
                    this.image_,
                    this.imageOriginX_,
                    this.imageOriginY_,
                    this.imageWidth_,
                    this.imageHeight_,
                    -this.imageAnchorX_,
                    -this.imageAnchorY_,
                    this.imageWidth_,
                    this.imageHeight_
                  ),
                  r.restore();
              } else
                r.drawImage(
                  this.image_,
                  this.imageOriginX_,
                  this.imageOriginY_,
                  this.imageWidth_,
                  this.imageHeight_,
                  t,
                  e,
                  this.imageWidth_,
                  this.imageHeight_
                );
            }
            1 != this.imageOpacity_ && (r.globalAlpha = a);
          }
          drawText_(t, e, i, n) {
            if (!this.textState_ || "" === this.text_) return;
            this.textFillState_ &&
              this.setContextFillState_(this.textFillState_),
              this.textStrokeState_ &&
                this.setContextStrokeState_(this.textStrokeState_),
              this.setContextTextState_(this.textState_);
            const s = si(t, e, i, n, this.transform_, this.pixelCoordinates_),
              r = this.context_;
            let o = this.textRotation_;
            for (
              0 === this.transformRotation_ && (o -= this.viewRotation_),
                this.textRotateWithView_ && (o += this.viewRotation_);
              e < i;
              e += n
            ) {
              const t = s[e] + this.textOffsetX_,
                i = s[e + 1] + this.textOffsetY_;
              0 !== o || 1 != this.textScale_[0] || 1 != this.textScale_[1]
                ? (r.save(),
                  r.translate(t - this.textOffsetX_, i - this.textOffsetY_),
                  r.rotate(o),
                  r.translate(this.textOffsetX_, this.textOffsetY_),
                  r.scale(this.textScale_[0], this.textScale_[1]),
                  this.textStrokeState_ && r.strokeText(this.text_, 0, 0),
                  this.textFillState_ && r.fillText(this.text_, 0, 0),
                  r.restore())
                : (this.textStrokeState_ && r.strokeText(this.text_, t, i),
                  this.textFillState_ && r.fillText(this.text_, t, i));
            }
          }
          moveToLineTo_(t, e, i, n, s) {
            const r = this.context_,
              o = si(t, e, i, n, this.transform_, this.pixelCoordinates_);
            r.moveTo(o[0], o[1]);
            let a = o.length;
            s && (a -= 2);
            for (let l = 2; l < a; l += 2) r.lineTo(o[l], o[l + 1]);
            return s && r.closePath(), i;
          }
          drawRings_(t, e, i, n) {
            for (let s = 0, r = i.length; s < r; ++s)
              e = this.moveToLineTo_(t, e, i[s], n, !0);
            return e;
          }
          drawCircle(t) {
            if (
              (this.squaredTolerance_ &&
                (t = t.simplifyTransformed(
                  this.squaredTolerance_,
                  this.userTransform_
                )),
              Lt(this.extent_, t.getExtent()))
            ) {
              if (this.fillState_ || this.strokeState_) {
                this.fillState_ && this.setContextFillState_(this.fillState_),
                  this.strokeState_ &&
                    this.setContextStrokeState_(this.strokeState_);
                const e = (function (t, e, i) {
                    const n = t.getFlatCoordinates();
                    if (!n) return null;
                    const s = t.getStride();
                    return si(n, 0, n.length, s, e, i);
                  })(t, this.transform_, this.pixelCoordinates_),
                  i = e[2] - e[0],
                  n = e[3] - e[1],
                  s = Math.sqrt(i * i + n * n),
                  r = this.context_;
                r.beginPath(),
                  r.arc(e[0], e[1], s, 0, 2 * Math.PI),
                  this.fillState_ && r.fill(),
                  this.strokeState_ && r.stroke();
              }
              "" !== this.text_ && this.drawText_(t.getCenter(), 0, 2, 2);
            }
          }
          setStyle(t) {
            this.setFillStrokeStyle(t.getFill(), t.getStroke()),
              this.setImageStyle(t.getImage()),
              this.setTextStyle(t.getText());
          }
          setTransform(t) {
            this.transform_ = t;
          }
          drawGeometry(t) {
            switch (t.getType()) {
              case "Point":
                this.drawPoint(t);
                break;
              case "LineString":
                this.drawLineString(t);
                break;
              case "Polygon":
                this.drawPolygon(t);
                break;
              case "MultiPoint":
                this.drawMultiPoint(t);
                break;
              case "MultiLineString":
                this.drawMultiLineString(t);
                break;
              case "MultiPolygon":
                this.drawMultiPolygon(t);
                break;
              case "GeometryCollection":
                this.drawGeometryCollection(t);
                break;
              case "Circle":
                this.drawCircle(t);
            }
          }
          drawFeature(t, e) {
            const i = e.getGeometryFunction()(t);
            i && (this.setStyle(e), this.drawGeometry(i));
          }
          drawGeometryCollection(t) {
            const e = t.getGeometriesArray();
            for (let i = 0, n = e.length; i < n; ++i) this.drawGeometry(e[i]);
          }
          drawPoint(t) {
            this.squaredTolerance_ &&
              (t = t.simplifyTransformed(
                this.squaredTolerance_,
                this.userTransform_
              ));
            const e = t.getFlatCoordinates(),
              i = t.getStride();
            this.image_ && this.drawImages_(e, 0, e.length, i),
              "" !== this.text_ && this.drawText_(e, 0, e.length, i);
          }
          drawMultiPoint(t) {
            this.squaredTolerance_ &&
              (t = t.simplifyTransformed(
                this.squaredTolerance_,
                this.userTransform_
              ));
            const e = t.getFlatCoordinates(),
              i = t.getStride();
            this.image_ && this.drawImages_(e, 0, e.length, i),
              "" !== this.text_ && this.drawText_(e, 0, e.length, i);
          }
          drawLineString(t) {
            if (
              (this.squaredTolerance_ &&
                (t = t.simplifyTransformed(
                  this.squaredTolerance_,
                  this.userTransform_
                )),
              Lt(this.extent_, t.getExtent()))
            ) {
              if (this.strokeState_) {
                this.setContextStrokeState_(this.strokeState_);
                const e = this.context_,
                  i = t.getFlatCoordinates();
                e.beginPath(),
                  this.moveToLineTo_(i, 0, i.length, t.getStride(), !1),
                  e.stroke();
              }
              if ("" !== this.text_) {
                const e = t.getFlatMidpoint();
                this.drawText_(e, 0, 2, 2);
              }
            }
          }
          drawMultiLineString(t) {
            this.squaredTolerance_ &&
              (t = t.simplifyTransformed(
                this.squaredTolerance_,
                this.userTransform_
              ));
            const e = t.getExtent();
            if (Lt(this.extent_, e)) {
              if (this.strokeState_) {
                this.setContextStrokeState_(this.strokeState_);
                const e = this.context_,
                  i = t.getFlatCoordinates();
                let n = 0;
                const s = t.getEnds(),
                  r = t.getStride();
                e.beginPath();
                for (let t = 0, o = s.length; t < o; ++t)
                  n = this.moveToLineTo_(i, n, s[t], r, !1);
                e.stroke();
              }
              if ("" !== this.text_) {
                const e = t.getFlatMidpoints();
                this.drawText_(e, 0, e.length, 2);
              }
            }
          }
          drawPolygon(t) {
            if (
              (this.squaredTolerance_ &&
                (t = t.simplifyTransformed(
                  this.squaredTolerance_,
                  this.userTransform_
                )),
              Lt(this.extent_, t.getExtent()))
            ) {
              if (this.strokeState_ || this.fillState_) {
                this.fillState_ && this.setContextFillState_(this.fillState_),
                  this.strokeState_ &&
                    this.setContextStrokeState_(this.strokeState_);
                const e = this.context_;
                e.beginPath(),
                  this.drawRings_(
                    t.getOrientedFlatCoordinates(),
                    0,
                    t.getEnds(),
                    t.getStride()
                  ),
                  this.fillState_ && e.fill(),
                  this.strokeState_ && e.stroke();
              }
              if ("" !== this.text_) {
                const e = t.getFlatInteriorPoint();
                this.drawText_(e, 0, 2, 2);
              }
            }
          }
          drawMultiPolygon(t) {
            if (
              (this.squaredTolerance_ &&
                (t = t.simplifyTransformed(
                  this.squaredTolerance_,
                  this.userTransform_
                )),
              Lt(this.extent_, t.getExtent()))
            ) {
              if (this.strokeState_ || this.fillState_) {
                this.fillState_ && this.setContextFillState_(this.fillState_),
                  this.strokeState_ &&
                    this.setContextStrokeState_(this.strokeState_);
                const e = this.context_,
                  i = t.getOrientedFlatCoordinates();
                let n = 0;
                const s = t.getEndss(),
                  r = t.getStride();
                e.beginPath();
                for (let t = 0, o = s.length; t < o; ++t) {
                  const e = s[t];
                  n = this.drawRings_(i, n, e, r);
                }
                this.fillState_ && e.fill(), this.strokeState_ && e.stroke();
              }
              if ("" !== this.text_) {
                const e = t.getFlatInteriorPoints();
                this.drawText_(e, 0, e.length, 2);
              }
            }
          }
          setContextFillState_(t) {
            const e = this.context_,
              i = this.contextFillState_;
            i
              ? i.fillStyle != t.fillStyle &&
                ((i.fillStyle = t.fillStyle), (e.fillStyle = t.fillStyle))
              : ((e.fillStyle = t.fillStyle),
                (this.contextFillState_ = { fillStyle: t.fillStyle }));
          }
          setContextStrokeState_(t) {
            const e = this.context_,
              i = this.contextStrokeState_;
            i
              ? (i.lineCap != t.lineCap &&
                  ((i.lineCap = t.lineCap), (e.lineCap = t.lineCap)),
                g(i.lineDash, t.lineDash) ||
                  e.setLineDash((i.lineDash = t.lineDash)),
                i.lineDashOffset != t.lineDashOffset &&
                  ((i.lineDashOffset = t.lineDashOffset),
                  (e.lineDashOffset = t.lineDashOffset)),
                i.lineJoin != t.lineJoin &&
                  ((i.lineJoin = t.lineJoin), (e.lineJoin = t.lineJoin)),
                i.lineWidth != t.lineWidth &&
                  ((i.lineWidth = t.lineWidth), (e.lineWidth = t.lineWidth)),
                i.miterLimit != t.miterLimit &&
                  ((i.miterLimit = t.miterLimit),
                  (e.miterLimit = t.miterLimit)),
                i.strokeStyle != t.strokeStyle &&
                  ((i.strokeStyle = t.strokeStyle),
                  (e.strokeStyle = t.strokeStyle)))
              : ((e.lineCap = t.lineCap),
                e.setLineDash(t.lineDash),
                (e.lineDashOffset = t.lineDashOffset),
                (e.lineJoin = t.lineJoin),
                (e.lineWidth = t.lineWidth),
                (e.miterLimit = t.miterLimit),
                (e.strokeStyle = t.strokeStyle),
                (this.contextStrokeState_ = {
                  lineCap: t.lineCap,
                  lineDash: t.lineDash,
                  lineDashOffset: t.lineDashOffset,
                  lineJoin: t.lineJoin,
                  lineWidth: t.lineWidth,
                  miterLimit: t.miterLimit,
                  strokeStyle: t.strokeStyle,
                }));
          }
          setContextTextState_(t) {
            const e = this.context_,
              i = this.contextTextState_,
              n = t.textAlign ? t.textAlign : Ar;
            i
              ? (i.font != t.font && ((i.font = t.font), (e.font = t.font)),
                i.textAlign != n && ((i.textAlign = n), (e.textAlign = n)),
                i.textBaseline != t.textBaseline &&
                  ((i.textBaseline = t.textBaseline),
                  (e.textBaseline = t.textBaseline)))
              : ((e.font = t.font),
                (e.textAlign = n),
                (e.textBaseline = t.textBaseline),
                (this.contextTextState_ = {
                  font: t.font,
                  textAlign: n,
                  textBaseline: t.textBaseline,
                }));
          }
          setFillStrokeStyle(t, e) {
            if (t) {
              const e = t.getColor();
              this.fillState_ = { fillStyle: kr(e || Pr) };
            } else this.fillState_ = null;
            if (e) {
              const t = e.getColor(),
                i = e.getLineCap(),
                n = e.getLineDash(),
                s = e.getLineDashOffset(),
                r = e.getLineJoin(),
                o = e.getWidth(),
                a = e.getMiterLimit(),
                l = n || Lr;
              this.strokeState_ = {
                lineCap: void 0 !== i ? i : Fr,
                lineDash:
                  1 === this.pixelRatio_
                    ? l
                    : l.map((t) => t * this.pixelRatio_),
                lineDashOffset: (s || 0) * this.pixelRatio_,
                lineJoin: void 0 !== r ? r : Tr,
                lineWidth: (void 0 !== o ? o : 1) * this.pixelRatio_,
                miterLimit: void 0 !== a ? a : 10,
                strokeStyle: kr(t || Dr),
              };
            } else this.strokeState_ = null;
          }
          setImageStyle(t) {
            let e;
            if (!t || !(e = t.getSize())) return void (this.image_ = null);
            const i = t.getPixelRatio(this.pixelRatio_),
              n = t.getAnchor(),
              s = t.getOrigin();
            (this.image_ = t.getImage(this.pixelRatio_)),
              (this.imageAnchorX_ = n[0] * i),
              (this.imageAnchorY_ = n[1] * i),
              (this.imageHeight_ = e[1] * i),
              (this.imageOpacity_ = t.getOpacity()),
              (this.imageOriginX_ = s[0]),
              (this.imageOriginY_ = s[1]),
              (this.imageRotateWithView_ = t.getRotateWithView()),
              (this.imageRotation_ = t.getRotation());
            const r = t.getScaleArray();
            (this.imageScale_ = [
              (r[0] * this.pixelRatio_) / i,
              (r[1] * this.pixelRatio_) / i,
            ]),
              (this.imageWidth_ = e[0] * i);
          }
          setTextStyle(t) {
            if (t) {
              const e = t.getFill();
              if (e) {
                const t = e.getColor();
                this.textFillState_ = { fillStyle: kr(t || Pr) };
              } else this.textFillState_ = null;
              const i = t.getStroke();
              if (i) {
                const t = i.getColor(),
                  e = i.getLineCap(),
                  n = i.getLineDash(),
                  s = i.getLineDashOffset(),
                  r = i.getLineJoin(),
                  o = i.getWidth(),
                  a = i.getMiterLimit();
                this.textStrokeState_ = {
                  lineCap: void 0 !== e ? e : Fr,
                  lineDash: n || Lr,
                  lineDashOffset: s || 0,
                  lineJoin: void 0 !== r ? r : Tr,
                  lineWidth: void 0 !== o ? o : 1,
                  miterLimit: void 0 !== a ? a : 10,
                  strokeStyle: kr(t || Dr),
                };
              } else this.textStrokeState_ = null;
              const n = t.getFont(),
                s = t.getOffsetX(),
                r = t.getOffsetY(),
                o = t.getRotateWithView(),
                a = t.getRotation(),
                l = t.getScaleArray(),
                h = t.getText(),
                c = t.getTextAlign(),
                u = t.getTextBaseline();
              (this.textState_ = {
                font: void 0 !== n ? n : Rr,
                textAlign: void 0 !== c ? c : Ar,
                textBaseline: void 0 !== u ? u : Or,
              }),
                (this.text_ =
                  void 0 !== h
                    ? Array.isArray(h)
                      ? h.reduce((t, e, i) => t + (i % 2 ? " " : e), "")
                      : h
                    : ""),
                (this.textOffsetX_ = void 0 !== s ? this.pixelRatio_ * s : 0),
                (this.textOffsetY_ = void 0 !== r ? this.pixelRatio_ * r : 0),
                (this.textRotateWithView_ = void 0 !== o && o),
                (this.textRotation_ = void 0 !== a ? a : 0),
                (this.textScale_ = [
                  this.pixelRatio_ * l[0],
                  this.pixelRatio_ * l[1],
                ]);
            } else this.text_ = "";
          }
        },
        il = 0.5;
      const nl = 0.5,
        sl = {
          Point: function (t, e, i, n, s, r) {
            const o = i.getImage(),
              a = i.getText(),
              l = a && a.getText(),
              h = r && o && l ? {} : void 0;
            if (o) {
              if (o.getImageState() != Ns.LOADED) return;
              const r = t.getBuilder(i.getZIndex(), "Image");
              r.setImageStyle(o, h), r.drawPoint(e, n, s);
            }
            if (l) {
              const r = t.getBuilder(i.getZIndex(), "Text");
              r.setTextStyle(a, h), r.drawText(e, n, s);
            }
          },
          LineString: function (t, e, i, n, s) {
            const r = i.getStroke();
            if (r) {
              const o = t.getBuilder(i.getZIndex(), "LineString");
              o.setFillStrokeStyle(null, r), o.drawLineString(e, n, s);
            }
            const o = i.getText();
            if (o && o.getText()) {
              const r = t.getBuilder(i.getZIndex(), "Text");
              r.setTextStyle(o), r.drawText(e, n, s);
            }
          },
          Polygon: function (t, e, i, n, s) {
            const r = i.getFill(),
              o = i.getStroke();
            if (r || o) {
              const a = t.getBuilder(i.getZIndex(), "Polygon");
              a.setFillStrokeStyle(r, o), a.drawPolygon(e, n, s);
            }
            const a = i.getText();
            if (a && a.getText()) {
              const r = t.getBuilder(i.getZIndex(), "Text");
              r.setTextStyle(a), r.drawText(e, n, s);
            }
          },
          MultiPoint: function (t, e, i, n, s, r) {
            const o = i.getImage(),
              a = o && 0 !== o.getOpacity(),
              l = i.getText(),
              h = l && l.getText(),
              c = r && a && h ? {} : void 0;
            if (a) {
              if (o.getImageState() != Ns.LOADED) return;
              const r = t.getBuilder(i.getZIndex(), "Image");
              r.setImageStyle(o, c), r.drawMultiPoint(e, n, s);
            }
            if (h) {
              const r = t.getBuilder(i.getZIndex(), "Text");
              r.setTextStyle(l, c), r.drawText(e, n, s);
            }
          },
          MultiLineString: function (t, e, i, n, s) {
            const r = i.getStroke();
            if (r) {
              const o = t.getBuilder(i.getZIndex(), "LineString");
              o.setFillStrokeStyle(null, r), o.drawMultiLineString(e, n, s);
            }
            const o = i.getText();
            if (o && o.getText()) {
              const r = t.getBuilder(i.getZIndex(), "Text");
              r.setTextStyle(o), r.drawText(e, n, s);
            }
          },
          MultiPolygon: function (t, e, i, n, s) {
            const r = i.getFill(),
              o = i.getStroke();
            if (o || r) {
              const a = t.getBuilder(i.getZIndex(), "Polygon");
              a.setFillStrokeStyle(r, o), a.drawMultiPolygon(e, n, s);
            }
            const a = i.getText();
            if (a && a.getText()) {
              const r = t.getBuilder(i.getZIndex(), "Text");
              r.setTextStyle(a), r.drawText(e, n, s);
            }
          },
          GeometryCollection: function (t, e, i, n, s, r) {
            const o = e.getGeometriesArray();
            let a, l;
            for (a = 0, l = o.length; a < l; ++a) {
              (0, sl[o[a].getType()])(t, o[a], i, n, s, r);
            }
          },
          Circle: function (t, e, i, n, s) {
            const r = i.getFill(),
              o = i.getStroke();
            if (r || o) {
              const a = t.getBuilder(i.getZIndex(), "Circle");
              a.setFillStrokeStyle(r, o), a.drawCircle(e, n, s);
            }
            const a = i.getText();
            if (a && a.getText()) {
              const s = t.getBuilder(i.getZIndex(), "Text");
              s.setTextStyle(a), s.drawText(e, n);
            }
          },
        };
      function rl(t, e) {
        return parseInt(F(t), 10) - parseInt(F(e), 10);
      }
      function ol(t, e) {
        const i = al(t, e);
        return i * i;
      }
      function al(t, e) {
        return (nl * t) / e;
      }
      function ll(t, e, i, n, s, r, o, a) {
        const l = [],
          h = i.getImage();
        if (h) {
          let t = !0;
          const e = h.getImageState();
          e == Ns.LOADED || e == Ns.ERROR ? (t = !1) : e == Ns.IDLE && h.load(),
            t && l.push(h.ready());
        }
        const c = i.getFill();
        c && c.loading() && l.push(c.ready());
        const u = l.length > 0;
        return (
          u && Promise.all(l).then(() => s(null)),
          (function (t, e, i, n, s, r, o) {
            const a = i.getGeometryFunction()(e);
            if (!a) return;
            const l = a.simplifyTransformed(n, s),
              h = i.getRenderer();
            if (h) hl(t, l, i, e, o);
            else {
              (0, sl[l.getType()])(t, l, i, e, o, r);
            }
          })(t, e, i, n, r, o, a),
          u
        );
      }
      function hl(t, e, i, n, s) {
        if ("GeometryCollection" == e.getType()) {
          const r = e.getGeometries();
          for (let e = 0, o = r.length; e < o; ++e) hl(t, r[e], i, n, s);
          return;
        }
        t.getBuilder(i.getZIndex(), "Default").drawCustom(
          e,
          n,
          i.getRenderer(),
          i.getHitDetectionRenderer(),
          s
        );
      }
      const cl = class extends Ga {
        constructor(t) {
          super(t),
            (this.boundHandleStyleImageChange_ =
              this.handleStyleImageChange_.bind(this)),
            this.animatingOrInteracting_,
            (this.hitDetectionImageData_ = null),
            (this.clipped_ = !1),
            (this.renderedFeatures_ = null),
            (this.renderedRevision_ = -1),
            (this.renderedResolution_ = NaN),
            (this.renderedExtent_ = [1 / 0, 1 / 0, -1 / 0, -1 / 0]),
            (this.wrappedRenderedExtent_ = [1 / 0, 1 / 0, -1 / 0, -1 / 0]),
            this.renderedRotation_,
            (this.renderedCenter_ = null),
            (this.renderedProjection_ = null),
            (this.renderedPixelRatio_ = 1),
            (this.renderedRenderOrder_ = null),
            this.renderedFrameDeclutter_,
            (this.replayGroup_ = null),
            (this.replayGroupChanged = !0),
            (this.clipping = !0),
            (this.targetContext_ = null),
            (this.opacity_ = 1);
        }
        renderWorlds(t, e, i) {
          const n = e.extent,
            s = e.viewState,
            r = s.center,
            o = s.resolution,
            a = s.projection,
            l = s.rotation,
            h = a.getExtent(),
            c = this.getLayer().getSource(),
            u = this.getLayer().getDeclutter(),
            d = e.pixelRatio,
            g = e.viewHints,
            f = !(g[ks] || g[Ms]),
            p = this.context,
            m = Math.round((Ft(n) / o) * d),
            _ = Math.round((Et(n) / o) * d),
            y = c.getWrapX() && a.canWrapX(),
            x = y ? Ft(h) : null,
            v = y ? Math.ceil((n[2] - h[2]) / x) + 1 : 1;
          let w = y ? Math.floor((n[0] - h[0]) / x) : 0;
          do {
            let n = this.getRenderTransform(r, o, 0, d, m, _, w * x);
            e.declutter && (n = n.slice(0)),
              t.execute(
                p,
                [p.canvas.width, p.canvas.height],
                n,
                l,
                f,
                void 0 === i ? Ha : i ? Ka : Ja,
                i ? u && e.declutter[u] : void 0
              );
          } while (++w < v);
        }
        setDrawContext_() {
          1 !== this.opacity_ &&
            ((this.targetContext_ = this.context),
            (this.context = pr(
              this.context.canvas.width,
              this.context.canvas.height,
              Oa
            )));
        }
        resetDrawContext_() {
          if (1 !== this.opacity_) {
            const t = this.targetContext_.globalAlpha;
            (this.targetContext_.globalAlpha = this.opacity_),
              this.targetContext_.drawImage(this.context.canvas, 0, 0),
              (this.targetContext_.globalAlpha = t),
              (function (t) {
                const e = t.canvas;
                (e.width = 1), (e.height = 1), t.clearRect(0, 0, 1, 1);
              })(this.context),
              Oa.push(this.context.canvas),
              (this.context = this.targetContext_),
              (this.targetContext_ = null);
          }
        }
        renderDeclutter(t) {
          this.replayGroup_ &&
            this.getLayer().getDeclutter() &&
            this.renderWorlds(this.replayGroup_, t, !0);
        }
        renderDeferredInternal(t) {
          this.replayGroup_ &&
            (this.replayGroup_.renderDeferred(),
            this.clipped_ && this.context.restore(),
            this.resetDrawContext_());
        }
        renderFrame(t, e) {
          const i = t.layerStatesArray[t.layerIndex];
          this.opacity_ = i.opacity;
          const n = t.viewState;
          this.prepareContainer(t, e);
          const s = this.context,
            r = this.replayGroup_;
          let o = r && !r.isEmpty();
          if (!o) {
            if (
              !(
                this.getLayer().hasListener(Ss) ||
                this.getLayer().hasListener(Cs)
              )
            )
              return null;
          }
          this.setDrawContext_(), this.preRender(s, t);
          const a = n.projection;
          if (((this.clipped_ = !1), o && i.extent && this.clipping)) {
            const e = qe(i.extent, a);
            (o = Lt(e, t.extent)),
              (this.clipped_ = o && !ct(e, t.extent)),
              this.clipped_ && this.clipUnrotated(s, t, e);
          }
          return (
            o &&
              this.renderWorlds(
                r,
                t,
                !this.getLayer().getDeclutter() && void 0
              ),
            !t.declutter && this.clipped_ && s.restore(),
            this.postRender(s, t),
            this.renderedRotation_ !== n.rotation &&
              ((this.renderedRotation_ = n.rotation),
              (this.hitDetectionImageData_ = null)),
            t.declutter || this.resetDrawContext_(),
            this.container
          );
        }
        getFeatures(t) {
          return new Promise((e) => {
            if (
              this.frameState &&
              !this.hitDetectionImageData_ &&
              !this.animatingOrInteracting_
            ) {
              const t = this.frameState.size.slice(),
                e = this.renderedCenter_,
                i = this.renderedResolution_,
                n = this.renderedRotation_,
                s = this.renderedProjection_,
                r = this.wrappedRenderedExtent_,
                o = this.getLayer(),
                a = [],
                l = t[0] * il,
                c = t[1] * il;
              a.push(this.getRenderTransform(e, i, n, il, l, c, 0).slice());
              const u = o.getSource(),
                d = s.getExtent();
              if (u.getWrapX() && s.canWrapX() && !ct(d, r)) {
                let t = r[0];
                const s = Ft(d);
                let o,
                  h = 0;
                for (; t < d[0]; )
                  --h,
                    (o = s * h),
                    a.push(
                      this.getRenderTransform(e, i, n, il, l, c, o).slice()
                    ),
                    (t += s);
                for (h = 0, t = r[2]; t > d[2]; )
                  ++h,
                    (o = s * h),
                    a.push(
                      this.getRenderTransform(e, i, n, il, l, c, o).slice()
                    ),
                    (t -= s);
              }
              const g = We();
              this.hitDetectionImageData_ = (function (
                t,
                e,
                i,
                n,
                s,
                r,
                o,
                a,
                l
              ) {
                const c = l ? Ve(s, l) : s,
                  u = pr(t[0] * il, t[1] * il);
                u.imageSmoothingEnabled = !1;
                const d = u.canvas,
                  g = new el(u, il, s, null, o, a, l ? Ge(We(), l) : null),
                  f = i.length,
                  p = Math.floor(16777215 / f),
                  m = {};
                for (let h = 1; h <= f; ++h) {
                  const t = i[h - 1],
                    e = t.getStyleFunction() || n;
                  if (!e) continue;
                  let s = e(t, r);
                  if (!s) continue;
                  Array.isArray(s) || (s = [s]);
                  const o = (h * p).toString(16).padStart(7, "#00000");
                  for (let i = 0, n = s.length; i < n; ++i) {
                    const e = s[i],
                      n = e.getGeometryFunction()(t);
                    if (!n || !Lt(c, n.getExtent())) continue;
                    const r = e.clone(),
                      a = r.getFill();
                    a && a.setColor(o);
                    const l = r.getStroke();
                    l && (l.setColor(o), l.setLineDash(null)),
                      r.setText(void 0);
                    const h = e.getImage();
                    if (h) {
                      const t = h.getImageSize();
                      if (!t) continue;
                      const e = pr(t[0], t[1], void 0, { alpha: !1 }),
                        i = e.canvas;
                      (e.fillStyle = o),
                        e.fillRect(0, 0, i.width, i.height),
                        r.setImage(
                          new co({
                            img: i,
                            anchor: h.getAnchor(),
                            anchorXUnits: "pixels",
                            anchorYUnits: "pixels",
                            offset: h.getOrigin(),
                            opacity: 1,
                            size: h.getSize(),
                            scale: h.getScale(),
                            rotation: h.getRotation(),
                            rotateWithView: h.getRotateWithView(),
                          })
                        );
                    }
                    const u = r.getZIndex() || 0;
                    let d = m[u];
                    d ||
                      ((d = {}),
                      (m[u] = d),
                      (d.Polygon = []),
                      (d.Circle = []),
                      (d.LineString = []),
                      (d.Point = []));
                    const g = n.getType();
                    if ("GeometryCollection" === g) {
                      const t = n.getGeometriesArrayRecursive();
                      for (let e = 0, i = t.length; e < i; ++e) {
                        const i = t[e];
                        d[i.getType().replace("Multi", "")].push(i, r);
                      }
                    } else d[g.replace("Multi", "")].push(n, r);
                  }
                }
                const _ = Object.keys(m).map(Number).sort(h);
                for (let h = 0, y = _.length; h < y; ++h) {
                  const t = m[_[h]];
                  for (const i in t) {
                    const n = t[i];
                    for (let t = 0, i = n.length; t < i; t += 2) {
                      g.setStyle(n[t + 1]);
                      for (let i = 0, s = e.length; i < s; ++i)
                        g.setTransform(e[i]), g.drawGeometry(n[t]);
                    }
                  }
                }
                return u.getImageData(0, 0, d.width, d.height);
              })(
                t,
                a,
                this.renderedFeatures_,
                o.getStyleFunction(),
                r,
                i,
                n,
                ol(i, this.renderedPixelRatio_),
                g ? s : null
              );
            }
            e(
              (function (t, e, i) {
                const n = [];
                if (i) {
                  const s = Math.floor(Math.round(t[0]) * il),
                    r = Math.floor(Math.round(t[1]) * il),
                    o =
                      4 *
                      (Nt(s, 0, i.width - 1) +
                        Nt(r, 0, i.height - 1) * i.width),
                    a = i.data[o],
                    l = i.data[o + 1],
                    h = i.data[o + 2] + 256 * (l + 256 * a),
                    c = Math.floor(16777215 / e.length);
                  h && h % c === 0 && n.push(e[h / c - 1]);
                }
                return n;
              })(t, this.renderedFeatures_, this.hitDetectionImageData_)
            );
          });
        }
        forEachFeatureAtCoordinate(t, e, i, n, s) {
          if (!this.replayGroup_) return;
          const r = e.viewState.resolution,
            o = e.viewState.rotation,
            a = this.getLayer(),
            l = {},
            h = function (t, e, i) {
              const r = F(t),
                o = l[r];
              if (o) {
                if (!0 !== o && i < o.distanceSq) {
                  if (0 === i)
                    return (
                      (l[r] = !0), s.splice(s.lastIndexOf(o), 1), n(t, a, e)
                    );
                  (o.geometry = e), (o.distanceSq = i);
                }
              } else {
                if (0 === i) return (l[r] = !0), n(t, a, e);
                s.push(
                  (l[r] = {
                    feature: t,
                    layer: a,
                    geometry: e,
                    distanceSq: i,
                    callback: n,
                  })
                );
              }
            };
          let c;
          const u = [this.replayGroup_],
            d = this.getLayer().getDeclutter();
          return (
            u.some(
              (n) =>
                (c = n.forEachFeatureAtCoordinate(
                  t,
                  r,
                  o,
                  i,
                  h,
                  d && e.declutter[d]
                    ? e.declutter[d].all().map((t) => t.value)
                    : null
                ))
            ),
            c
          );
        }
        handleFontsChanged() {
          const t = this.getLayer();
          t.getVisible() && this.replayGroup_ && t.changed();
        }
        handleStyleImageChange_(t) {
          this.renderIfReadyAndVisible();
        }
        prepareFrame(t) {
          const e = this.getLayer(),
            i = e.getSource();
          if (!i) return !1;
          const n = t.viewHints[ks],
            s = t.viewHints[Ms],
            r = e.getUpdateWhileAnimating(),
            o = e.getUpdateWhileInteracting();
          if ((this.ready && !r && n) || (!o && s))
            return (this.animatingOrInteracting_ = !0), !0;
          this.animatingOrInteracting_ = !1;
          const a = t.extent,
            l = t.viewState,
            h = l.projection,
            c = l.resolution,
            u = t.pixelRatio,
            d = e.getRevision(),
            f = e.getRenderBuffer();
          let p = e.getRenderOrder();
          void 0 === p && (p = rl);
          const m = l.center.slice(),
            _ = at(a, f * c),
            y = _.slice(),
            x = [_.slice()],
            v = h.getExtent();
          if (i.getWrapX() && h.canWrapX() && !ct(v, t.extent)) {
            const t = Ft(v),
              e = Math.max(Ft(_) / 2, t);
            (_[0] = v[0] - e), (_[2] = v[2] + e), Ie(m, h);
            const i = At(x[0], h);
            i[0] < v[0] && i[2] < v[2]
              ? x.push([i[0] + t, i[1], i[2] + t, i[3]])
              : i[0] > v[0] &&
                i[2] > v[2] &&
                x.push([i[0] - t, i[1], i[2] - t, i[3]]);
          }
          if (
            this.ready &&
            this.renderedResolution_ == c &&
            this.renderedRevision_ == d &&
            this.renderedRenderOrder_ == p &&
            this.renderedFrameDeclutter_ === !!t.declutter &&
            ct(this.wrappedRenderedExtent_, _)
          )
            return (
              g(this.renderedExtent_, y) ||
                ((this.hitDetectionImageData_ = null),
                (this.renderedExtent_ = y)),
              (this.renderedCenter_ = m),
              (this.replayGroupChanged = !1),
              !0
            );
          this.replayGroup_ = null;
          const w = new La(al(c, u), _, c, u),
            S = We();
          let C;
          if (S) {
            for (let t = 0, e = x.length; t < e; ++t) {
              const e = Ve(x[t], h);
              i.loadFeatures(e, $e(c, h), S);
            }
            C = Ge(S, h);
          } else
            for (let g = 0, F = x.length; g < F; ++g)
              i.loadFeatures(x[g], c, h);
          const b = ol(c, u);
          let k = !0;
          const M = (t, i) => {
              let n;
              const s = t.getStyleFunction() || e.getStyleFunction();
              if ((s && (n = s(t, c)), n)) {
                const e = this.renderFeature(
                  t,
                  b,
                  n,
                  w,
                  C,
                  this.getLayer().getDeclutter(),
                  i
                );
                k = k && !e;
              }
            },
            I = Ve(_, h),
            E = i.getFeaturesInExtent(I);
          p && E.sort(p);
          for (let g = 0, F = E.length; g < F; ++g) M(E[g], g);
          (this.renderedFeatures_ = E), (this.ready = k);
          const R = w.finish(),
            P = new tl(
              _,
              c,
              u,
              i.getOverlaps(),
              R,
              e.getRenderBuffer(),
              !!t.declutter
            );
          return (
            (this.renderedResolution_ = c),
            (this.renderedRevision_ = d),
            (this.renderedRenderOrder_ = p),
            (this.renderedFrameDeclutter_ = !!t.declutter),
            (this.renderedExtent_ = y),
            (this.wrappedRenderedExtent_ = _),
            (this.renderedCenter_ = m),
            (this.renderedProjection_ = h),
            (this.renderedPixelRatio_ = u),
            (this.replayGroup_ = P),
            (this.hitDetectionImageData_ = null),
            (this.replayGroupChanged = !0),
            !0
          );
        }
        renderFeature(t, e, i, n, s, r, o) {
          if (!i) return !1;
          let a = !1;
          if (Array.isArray(i))
            for (let l = 0, h = i.length; l < h; ++l)
              a =
                ll(n, t, i[l], e, this.boundHandleStyleImageChange_, s, r, o) ||
                a;
          else a = ll(n, t, i, e, this.boundHandleStyleImageChange_, s, r, o);
          return a;
        }
      };
      const ul = class extends pa {
        constructor(t) {
          super(t);
        }
        createRenderer() {
          return new cl(this);
        }
      };
      const dl = f,
        gl = p,
        fl = function (t) {
          const e = t.originalEvent;
          return !e.altKey && !(e.metaKey || e.ctrlKey) && !e.shiftKey;
        },
        pl = function (t) {
          const e = t.originalEvent;
          return !e.altKey && !(e.metaKey || e.ctrlKey) && e.shiftKey;
        },
        ml = function (t) {
          const e = t.originalEvent;
          return (
            D(
              void 0 !== e,
              "mapBrowserEvent must originate from a pointer event"
            ),
            e.isPrimary && 0 === e.button
          );
        },
        _l = "drawstart",
        yl = "drawend",
        xl = "drawabort";
      class vl extends o {
        constructor(t, e) {
          super(t), (this.feature = e);
        }
      }
      function wl(t, e) {
        return Xt(t[0], t[1], e[0], e[1]);
      }
      function Sl(t, e) {
        const i = t.length;
        return e < 0 ? t[e + i] : e >= i ? t[e - i] : t[e];
      }
      function Cl(t, e, i) {
        let n, s;
        e < i ? ((n = e), (s = i)) : ((n = i), (s = e));
        const r = Math.ceil(n),
          o = Math.floor(s);
        if (r > o) {
          return wl(Rl(t, n), Rl(t, s));
        }
        let a = 0;
        if (n < r) {
          a += wl(Rl(t, n), Sl(t, r));
        }
        if (o < s) {
          a += wl(Sl(t, o), Rl(t, s));
        }
        for (let l = r; l < o - 1; ++l) {
          a += wl(Sl(t, l), Sl(t, l + 1));
        }
        return a;
      }
      function bl(t, e, i) {
        if (e instanceof Hi) Ml(t, e.getCoordinates(), !1, i);
        else if (e instanceof hn) {
          const n = e.getCoordinates();
          for (let e = 0, s = n.length; e < s; ++e) Ml(t, n[e], !1, i);
        } else if (e instanceof nn) {
          const n = e.getCoordinates();
          for (let e = 0, s = n.length; e < s; ++e) Ml(t, n[e], !0, i);
        } else if (e instanceof un) {
          const n = e.getCoordinates();
          for (let e = 0, s = n.length; e < s; ++e) {
            const s = n[e];
            for (let e = 0, n = s.length; e < n; ++e) Ml(t, s[e], !0, i);
          }
        } else if (e instanceof fn) {
          const n = e.getGeometries();
          for (let e = 0; e < n.length; ++e) bl(t, n[e], i);
        } else;
      }
      const kl = { index: -1, endIndex: NaN };
      function Ml(t, e, i, n) {
        const s = t[0],
          r = t[1];
        for (let o = 0, a = e.length - 1; o < a; ++o) {
          const t = El(s, r, e[o], e[o + 1]);
          if (0 === t.squaredDistance) {
            const s = o + t.along;
            return void n.push({
              coordinates: e,
              ring: i,
              startIndex: s,
              endIndex: s,
            });
          }
        }
      }
      const Il = { along: 0, squaredDistance: 0 };
      function El(t, e, i, n) {
        const s = i[0],
          r = i[1],
          o = n[0] - s,
          a = n[1] - r;
        let l = 0,
          h = s,
          c = r;
        return (
          (0 === o && 0 === a) ||
            ((l = Nt(((t - s) * o + (e - r) * a) / (o * o + a * a), 0, 1)),
            (h += o * l),
            (c += a * l)),
          (Il.along = l),
          (Il.squaredDistance = $t(Xt(t, e, h, c), 10)),
          Il
        );
      }
      function Rl(t, e) {
        const i = t.length;
        let n = Math.floor(e);
        const s = e - n;
        n >= i ? (n -= i) : n < 0 && (n += i);
        let r = n + 1;
        r >= i && (r -= i);
        const o = t[n],
          a = o[0],
          l = o[1],
          h = t[r];
        return [a + (h[0] - a) * s, l + (h[1] - l) * s];
      }
      function Pl() {
        const t = ro();
        return function (e, i) {
          return t[e.getGeometry().getType()];
        };
      }
      const Fl = class extends cs {
        constructor(t) {
          const e = t;
          e.stopDown || (e.stopDown = p),
            super(e),
            this.on,
            this.once,
            this.un,
            (this.shouldHandle_ = !1),
            (this.downPx_ = null),
            this.downTimeout_,
            this.lastDragTime_,
            this.pointerType_,
            (this.freehand_ = !1),
            (this.source_ = t.source ? t.source : null),
            (this.features_ = t.features ? t.features : null),
            (this.snapTolerance_ = t.snapTolerance ? t.snapTolerance : 12),
            (this.type_ = t.type),
            (this.mode_ = (function (t) {
              switch (t) {
                case "Point":
                case "MultiPoint":
                  return "Point";
                case "LineString":
                case "MultiLineString":
                  return "LineString";
                case "Polygon":
                case "MultiPolygon":
                  return "Polygon";
                case "Circle":
                  return "Circle";
                default:
                  throw new Error("Invalid type: " + t);
              }
            })(this.type_)),
            (this.stopClick_ = !!t.stopClick),
            (this.minPoints_ = t.minPoints
              ? t.minPoints
              : "Polygon" === this.mode_
              ? 3
              : 2),
            (this.maxPoints_ =
              "Circle" === this.mode_ ? 2 : t.maxPoints ? t.maxPoints : 1 / 0),
            (this.finishCondition_ = t.finishCondition ? t.finishCondition : f),
            (this.geometryLayout_ = t.geometryLayout ? t.geometryLayout : "XY");
          let i = t.geometryFunction;
          if (!i) {
            const t = this.mode_;
            if ("Circle" === t)
              i = (t, e, i) => {
                const n = e || new Qn([NaN, NaN]),
                  s = Ye(t[0], i),
                  r = ke(s, Ye(t[t.length - 1], i));
                n.setCenterAndRadius(s, Math.sqrt(r), this.geometryLayout_);
                const o = We();
                return o && n.transform(i, o), n;
              };
            else {
              let e;
              "Point" === t
                ? (e = Oi)
                : "LineString" === t
                ? (e = Hi)
                : "Polygon" === t && (e = nn),
                (i = (i, n, s) => (
                  n
                    ? "Polygon" === t
                      ? i[0].length
                        ? n.setCoordinates(
                            [i[0].concat([i[0][0]])],
                            this.geometryLayout_
                          )
                        : n.setCoordinates([], this.geometryLayout_)
                      : n.setCoordinates(i, this.geometryLayout_)
                    : (n = new e(i, this.geometryLayout_)),
                  n
                ));
            }
          }
          (this.geometryFunction_ = i),
            (this.dragVertexDelay_ =
              void 0 !== t.dragVertexDelay ? t.dragVertexDelay : 500),
            (this.finishCoordinate_ = null),
            (this.sketchFeature_ = null),
            (this.sketchPoint_ = null),
            (this.sketchCoords_ = null),
            (this.sketchLine_ = null),
            (this.sketchLineCoords_ = null),
            (this.squaredClickTolerance_ = t.clickTolerance
              ? t.clickTolerance * t.clickTolerance
              : 36),
            (this.overlay_ = new ul({
              source: new Ci({
                useSpatialIndex: !1,
                wrapX: !!t.wrapX && t.wrapX,
              }),
              style: t.style ? t.style : Pl(),
              updateWhileInteracting: !0,
            })),
            (this.geometryName_ = t.geometryName),
            (this.condition_ = t.condition ? t.condition : fl),
            this.freehandCondition_,
            t.freehand
              ? (this.freehandCondition_ = dl)
              : (this.freehandCondition_ = t.freehandCondition
                  ? t.freehandCondition
                  : pl),
            this.traceCondition_,
            this.setTrace(t.trace || !1),
            (this.traceState_ = { active: !1 }),
            (this.traceSource_ = t.traceSource || t.source || null),
            this.addChangeListener(ts, this.updateState_);
        }
        setTrace(t) {
          let e;
          (e = t ? (!0 === t ? dl : t) : gl), (this.traceCondition_ = e);
        }
        setMap(t) {
          super.setMap(t), this.updateState_();
        }
        getOverlay() {
          return this.overlay_;
        }
        handleEvent(t) {
          t.originalEvent.type === S && t.originalEvent.preventDefault(),
            (this.freehand_ =
              "Point" !== this.mode_ && this.freehandCondition_(t));
          let e = t.type === os,
            i = !0;
          if (!this.freehand_ && this.lastDragTime_ && t.type === rs) {
            Date.now() - this.lastDragTime_ >= this.dragVertexDelay_
              ? ((this.downPx_ = t.pixel),
                (this.shouldHandle_ = !this.freehand_),
                (e = !0))
              : (this.lastDragTime_ = void 0),
              this.shouldHandle_ &&
                void 0 !== this.downTimeout_ &&
                (clearTimeout(this.downTimeout_), (this.downTimeout_ = void 0));
          }
          return (
            this.freehand_ && t.type === rs && null !== this.sketchFeature_
              ? (this.addToDrawing_(t.coordinate), (i = !1))
              : this.freehand_ && t.type === as
              ? (i = !1)
              : e && this.getPointerCount() < 2
              ? ((i = t.type === os),
                i && this.freehand_
                  ? (this.handlePointerMove_(t),
                    this.shouldHandle_ && t.originalEvent.preventDefault())
                  : ("mouse" === t.originalEvent.pointerType ||
                      (t.type === rs && void 0 === this.downTimeout_)) &&
                    this.handlePointerMove_(t))
              : t.type === ss && (i = !1),
            super.handleEvent(t) && i
          );
        }
        handleDownEvent(t) {
          return (
            (this.shouldHandle_ = !this.freehand_),
            this.freehand_
              ? ((this.downPx_ = t.pixel),
                this.finishCoordinate_ || this.startDrawing_(t.coordinate),
                !0)
              : this.condition_(t)
              ? ((this.lastDragTime_ = Date.now()),
                (this.downTimeout_ = setTimeout(() => {
                  this.handlePointerMove_(
                    new is(os, t.map, t.originalEvent, !1, t.frameState)
                  );
                }, this.dragVertexDelay_)),
                (this.downPx_ = t.pixel),
                !0)
              : ((this.lastDragTime_ = void 0), !1)
          );
        }
        deactivateTrace_() {
          this.traceState_ = { active: !1 };
        }
        toggleTraceState_(t) {
          if (!this.traceSource_ || !this.traceCondition_(t)) return;
          if (this.traceState_.active) return void this.deactivateTrace_();
          const e = this.getMap(),
            i = ot([
              e.getCoordinateFromPixel([
                t.pixel[0] - this.snapTolerance_,
                t.pixel[1] + this.snapTolerance_,
              ]),
              e.getCoordinateFromPixel([
                t.pixel[0] + this.snapTolerance_,
                t.pixel[1] - this.snapTolerance_,
              ]),
            ]),
            n = this.traceSource_.getFeaturesInExtent(i);
          if (0 === n.length) return;
          const s = (function (t, e) {
            const i = [];
            for (let n = 0; n < e.length; ++n) bl(t, e[n].getGeometry(), i);
            return i;
          })(t.coordinate, n);
          s.length &&
            (this.traceState_ = {
              active: !0,
              startPx: t.pixel.slice(),
              targets: s,
              targetIndex: -1,
            });
        }
        addOrRemoveTracedCoordinates_(t, e) {
          const i = t.startIndex <= t.endIndex;
          i === t.startIndex <= e
            ? (i && e > t.endIndex) || (!i && e < t.endIndex)
              ? this.addTracedCoordinates_(t, t.endIndex, e)
              : ((i && e < t.endIndex) || (!i && e > t.endIndex)) &&
                this.removeTracedCoordinates_(e, t.endIndex)
            : (this.removeTracedCoordinates_(t.startIndex, t.endIndex),
              this.addTracedCoordinates_(t, t.startIndex, e));
        }
        removeTracedCoordinates_(t, e) {
          if (t === e) return;
          let i = 0;
          if (t < e) {
            const n = Math.ceil(t);
            let s = Math.floor(e);
            s === e && (s -= 1), (i = s - n + 1);
          } else {
            const n = Math.floor(t);
            let s = Math.ceil(e);
            s === e && (s += 1), (i = n - s + 1);
          }
          i > 0 && this.removeLastPoints_(i);
        }
        addTracedCoordinates_(t, e, i) {
          if (e === i) return;
          const n = [];
          if (e < i) {
            const s = Math.ceil(e);
            let r = Math.floor(i);
            r === i && (r -= 1);
            for (let e = s; e <= r; ++e) n.push(Sl(t.coordinates, e));
          } else {
            const s = Math.floor(e);
            let r = Math.ceil(i);
            r === i && (r += 1);
            for (let e = s; e >= r; --e) n.push(Sl(t.coordinates, e));
          }
          n.length && this.appendCoordinates(n);
        }
        updateTrace_(t) {
          const e = this.traceState_;
          if (!e.active) return;
          if (
            -1 === e.targetIndex &&
            Me(e.startPx, t.pixel) < this.snapTolerance_
          )
            return;
          const i = (function (t, e, i, n) {
            const s = t[0],
              r = t[1];
            let o = 1 / 0,
              a = -1,
              l = NaN;
            for (let u = 0; u < e.targets.length; ++u) {
              const t = e.targets[u],
                i = t.coordinates;
              let n,
                h = 1 / 0;
              for (let e = 0; e < i.length - 1; ++e) {
                const t = El(s, r, i[e], i[e + 1]);
                t.squaredDistance < h &&
                  ((h = t.squaredDistance), (n = e + t.along));
              }
              h < o &&
                ((o = h),
                t.ring &&
                  e.targetIndex === u &&
                  (t.endIndex > t.startIndex
                    ? n < t.startIndex && (n += i.length)
                    : t.endIndex < t.startIndex &&
                      n > t.startIndex &&
                      (n -= i.length)),
                (l = n),
                (a = u));
            }
            const h = e.targets[a];
            let c = h.ring;
            if (e.targetIndex === a && c) {
              const t = Rl(h.coordinates, l);
              Me(i.getPixelFromCoordinate(t), e.startPx) > n && (c = !1);
            }
            if (c) {
              const t = h.coordinates,
                e = t.length,
                i = h.startIndex,
                n = l;
              if (i < n) {
                const s = Cl(t, i, n);
                Cl(t, i, n - e) < s && (l -= e);
              } else {
                const s = Cl(t, i, n);
                Cl(t, i, n + e) < s && (l += e);
              }
            }
            return (kl.index = a), (kl.endIndex = l), kl;
          })(t.coordinate, e, this.getMap(), this.snapTolerance_);
          if (e.targetIndex !== i.index) {
            if (-1 !== e.targetIndex) {
              const t = e.targets[e.targetIndex];
              this.removeTracedCoordinates_(t.startIndex, t.endIndex);
            }
            const t = e.targets[i.index];
            this.addTracedCoordinates_(t, t.startIndex, i.endIndex);
          } else {
            const t = e.targets[e.targetIndex];
            this.addOrRemoveTracedCoordinates_(t, i.endIndex);
          }
          e.targetIndex = i.index;
          const n = e.targets[e.targetIndex];
          n.endIndex = i.endIndex;
          const s = Rl(n.coordinates, n.endIndex),
            r = this.getMap().getPixelFromCoordinate(s);
          (t.coordinate = s), (t.pixel = [Math.round(r[0]), Math.round(r[1])]);
        }
        handleUpEvent(t) {
          let e = !0;
          if (0 === this.getPointerCount()) {
            this.downTimeout_ &&
              (clearTimeout(this.downTimeout_), (this.downTimeout_ = void 0)),
              this.handlePointerMove_(t);
            const i = this.traceState_.active;
            if ((this.toggleTraceState_(t), this.shouldHandle_)) {
              const n = !this.finishCoordinate_;
              n && this.startDrawing_(t.coordinate),
                !n && this.freehand_
                  ? this.finishDrawing()
                  : this.freehand_ ||
                    (n && "Point" !== this.mode_) ||
                    (this.atFinish_(t.pixel, i)
                      ? this.finishCondition_(t) && this.finishDrawing()
                      : this.addToDrawing_(t.coordinate)),
                (e = !1);
            } else this.freehand_ && this.abortDrawing();
          }
          return !e && this.stopClick_ && t.preventDefault(), e;
        }
        handlePointerMove_(t) {
          if (
            ((this.pointerType_ = t.originalEvent.pointerType),
            this.downPx_ &&
              ((!this.freehand_ && this.shouldHandle_) ||
                (this.freehand_ && !this.shouldHandle_)))
          ) {
            const e = this.downPx_,
              i = t.pixel,
              n = e[0] - i[0],
              s = e[1] - i[1],
              r = n * n + s * s;
            if (
              ((this.shouldHandle_ = this.freehand_
                ? r > this.squaredClickTolerance_
                : r <= this.squaredClickTolerance_),
              !this.shouldHandle_)
            )
              return;
          }
          this.finishCoordinate_
            ? (this.updateTrace_(t), this.modifyDrawing_(t.coordinate))
            : this.createOrUpdateSketchPoint_(t.coordinate.slice());
        }
        atFinish_(t, e) {
          let i = !1;
          if (this.sketchFeature_) {
            let n = !1,
              s = [this.finishCoordinate_];
            const r = this.mode_;
            if ("Point" === r) i = !0;
            else if ("Circle" === r) i = 2 === this.sketchCoords_.length;
            else if ("LineString" === r)
              n = !e && this.sketchCoords_.length > this.minPoints_;
            else if ("Polygon" === r) {
              const t = this.sketchCoords_;
              (n = t[0].length > this.minPoints_),
                (s = [t[0][0], t[0][t[0].length - 2]]),
                (s = e ? [t[0][0]] : [t[0][0], t[0][t[0].length - 2]]);
            }
            if (n) {
              const e = this.getMap();
              for (let n = 0, r = s.length; n < r; n++) {
                const r = s[n],
                  o = e.getPixelFromCoordinate(r),
                  a = t[0] - o[0],
                  l = t[1] - o[1],
                  h = this.freehand_ ? 1 : this.snapTolerance_;
                if (((i = Math.sqrt(a * a + l * l) <= h), i)) {
                  this.finishCoordinate_ = r;
                  break;
                }
              }
            }
          }
          return i;
        }
        createOrUpdateSketchPoint_(t) {
          if (this.sketchPoint_) {
            this.sketchPoint_.getGeometry().setCoordinates(t);
          } else
            (this.sketchPoint_ = new O(new Oi(t))),
              this.updateSketchFeatures_();
        }
        createOrUpdateCustomSketchLine_(t) {
          this.sketchLine_ || (this.sketchLine_ = new O());
          const e = t.getLinearRing(0);
          let i = this.sketchLine_.getGeometry();
          i
            ? (i.setFlatCoordinates(e.getLayout(), e.getFlatCoordinates()),
              i.changed())
            : ((i = new Hi(e.getFlatCoordinates(), e.getLayout())),
              this.sketchLine_.setGeometry(i));
        }
        startDrawing_(t) {
          const e = this.getMap().getView().getProjection(),
            i = Ri(this.geometryLayout_);
          for (; t.length < i; ) t.push(0);
          (this.finishCoordinate_ = t),
            "Point" === this.mode_
              ? (this.sketchCoords_ = t.slice())
              : "Polygon" === this.mode_
              ? ((this.sketchCoords_ = [[t.slice(), t.slice()]]),
                (this.sketchLineCoords_ = this.sketchCoords_[0]))
              : (this.sketchCoords_ = [t.slice(), t.slice()]),
            this.sketchLineCoords_ &&
              (this.sketchLine_ = new O(new Hi(this.sketchLineCoords_)));
          const n = this.geometryFunction_(this.sketchCoords_, void 0, e);
          (this.sketchFeature_ = new O()),
            this.geometryName_ &&
              this.sketchFeature_.setGeometryName(this.geometryName_),
            this.sketchFeature_.setGeometry(n),
            this.updateSketchFeatures_(),
            this.dispatchEvent(new vl(_l, this.sketchFeature_));
        }
        modifyDrawing_(t) {
          const e = this.getMap(),
            i = this.sketchFeature_.getGeometry(),
            n = e.getView().getProjection(),
            s = Ri(this.geometryLayout_);
          let r, o;
          for (; t.length < s; ) t.push(0);
          if (
            ("Point" === this.mode_
              ? (o = this.sketchCoords_)
              : "Polygon" === this.mode_
              ? ((r = this.sketchCoords_[0]),
                (o = r[r.length - 1]),
                this.atFinish_(e.getPixelFromCoordinate(t)) &&
                  (t = this.finishCoordinate_.slice()))
              : ((r = this.sketchCoords_), (o = r[r.length - 1])),
            (o[0] = t[0]),
            (o[1] = t[1]),
            this.geometryFunction_(this.sketchCoords_, i, n),
            this.sketchPoint_)
          ) {
            this.sketchPoint_.getGeometry().setCoordinates(t);
          }
          if ("Polygon" === i.getType() && "Polygon" !== this.mode_)
            this.createOrUpdateCustomSketchLine_(i);
          else if (this.sketchLineCoords_) {
            this.sketchLine_
              .getGeometry()
              .setCoordinates(this.sketchLineCoords_);
          }
          this.updateSketchFeatures_();
        }
        addToDrawing_(t) {
          const e = this.sketchFeature_.getGeometry(),
            i = this.getMap().getView().getProjection();
          let n, s;
          const r = this.mode_;
          return (
            "LineString" === r || "Circle" === r
              ? ((this.finishCoordinate_ = t.slice()),
                (s = this.sketchCoords_),
                s.length >= this.maxPoints_ &&
                  (this.freehand_ ? s.pop() : (n = !0)),
                s.push(t.slice()),
                this.geometryFunction_(s, e, i))
              : "Polygon" === r &&
                ((s = this.sketchCoords_[0]),
                s.length >= this.maxPoints_ &&
                  (this.freehand_ ? s.pop() : (n = !0)),
                s.push(t.slice()),
                n && (this.finishCoordinate_ = s[0]),
                this.geometryFunction_(this.sketchCoords_, e, i)),
            this.createOrUpdateSketchPoint_(t.slice()),
            this.updateSketchFeatures_(),
            n ? this.finishDrawing() : this.sketchFeature_
          );
        }
        removeLastPoints_(t) {
          if (!this.sketchFeature_) return;
          const e = this.sketchFeature_.getGeometry(),
            i = this.getMap().getView().getProjection(),
            n = this.mode_;
          for (let s = 0; s < t; ++s) {
            let t;
            if ("LineString" === n || "Circle" === n) {
              if (((t = this.sketchCoords_), t.splice(-2, 1), t.length >= 2)) {
                this.finishCoordinate_ = t[t.length - 2].slice();
                const e = this.finishCoordinate_.slice();
                (t[t.length - 1] = e), this.createOrUpdateSketchPoint_(e);
              }
              this.geometryFunction_(t, e, i),
                "Polygon" === e.getType() &&
                  this.sketchLine_ &&
                  this.createOrUpdateCustomSketchLine_(e);
            } else if ("Polygon" === n) {
              (t = this.sketchCoords_[0]), t.splice(-2, 1);
              const n = this.sketchLine_.getGeometry();
              if (t.length >= 2) {
                const e = t[t.length - 2].slice();
                (t[t.length - 1] = e), this.createOrUpdateSketchPoint_(e);
              }
              n.setCoordinates(t),
                this.geometryFunction_(this.sketchCoords_, e, i);
            }
            if (1 === t.length) {
              this.abortDrawing();
              break;
            }
          }
          this.updateSketchFeatures_();
        }
        removeLastPoint() {
          this.removeLastPoints_(1);
        }
        finishDrawing() {
          const t = this.abortDrawing_();
          if (!t) return null;
          let e = this.sketchCoords_;
          const i = t.getGeometry(),
            n = this.getMap().getView().getProjection();
          return (
            "LineString" === this.mode_
              ? (e.pop(), this.geometryFunction_(e, i, n))
              : "Polygon" === this.mode_ &&
                (e[0].pop(),
                this.geometryFunction_(e, i, n),
                (e = i.getCoordinates())),
            "MultiPoint" === this.type_
              ? t.setGeometry(new an([e]))
              : "MultiLineString" === this.type_
              ? t.setGeometry(new hn([e]))
              : "MultiPolygon" === this.type_ && t.setGeometry(new un([e])),
            this.dispatchEvent(new vl(yl, t)),
            this.features_ && this.features_.push(t),
            this.source_ && this.source_.addFeature(t),
            t
          );
        }
        abortDrawing_() {
          this.finishCoordinate_ = null;
          const t = this.sketchFeature_;
          return (
            (this.sketchFeature_ = null),
            (this.sketchPoint_ = null),
            (this.sketchLine_ = null),
            this.overlay_.getSource().clear(!0),
            this.deactivateTrace_(),
            t
          );
        }
        abortDrawing() {
          const t = this.abortDrawing_();
          t && this.dispatchEvent(new vl(xl, t));
        }
        appendCoordinates(t) {
          const e = this.mode_,
            i = !this.sketchFeature_;
          let n;
          if (
            (i && this.startDrawing_(t[0]),
            "LineString" === e || "Circle" === e)
          )
            n = this.sketchCoords_;
          else {
            if ("Polygon" !== e) return;
            n =
              this.sketchCoords_ && this.sketchCoords_.length
                ? this.sketchCoords_[0]
                : [];
          }
          i && n.shift(), n.pop();
          for (let r = 0; r < t.length; r++) this.addToDrawing_(t[r]);
          const s = t[t.length - 1];
          (this.sketchFeature_ = this.addToDrawing_(s)), this.modifyDrawing_(s);
        }
        extend(t) {
          const e = t.getGeometry();
          (this.sketchFeature_ = t), (this.sketchCoords_ = e.getCoordinates());
          const i = this.sketchCoords_[this.sketchCoords_.length - 1];
          (this.finishCoordinate_ = i.slice()),
            this.sketchCoords_.push(i.slice()),
            (this.sketchPoint_ = new O(new Oi(i))),
            this.updateSketchFeatures_(),
            this.dispatchEvent(new vl(_l, this.sketchFeature_));
        }
        updateSketchFeatures_() {
          const t = [];
          this.sketchFeature_ && t.push(this.sketchFeature_),
            this.sketchLine_ && t.push(this.sketchLine_),
            this.sketchPoint_ && t.push(this.sketchPoint_);
          const e = this.overlay_.getSource();
          e.clear(!0), e.addFeatures(t);
        }
        updateState_() {
          const t = this.getMap(),
            e = this.getActive();
          (t && e) || this.abortDrawing(), this.overlay_.setMap(e ? t : null);
        }
      };
      var Ll = i(89178);
      const Tl = [0, 0, 0, 0],
        Dl = [],
        Al = "modifystart",
        Ol = "modifyend";
      class jl extends o {
        constructor(t, e, i) {
          super(t), (this.features = e), (this.mapBrowserEvent = i);
        }
      }
      function Gl(t, e) {
        return t.index - e.index;
      }
      function Zl(t, e, i) {
        const n = e.geometry;
        if ("Circle" === n.getType()) {
          let s = n;
          if (1 === e.index) {
            const e = We();
            e && (s = s.clone().transform(e, i));
            const n = ke(s.getCenter(), Ye(t, i)),
              r = Math.sqrt(n) - s.getRadius();
            return r * r;
          }
        }
        const s = Ye(t, i);
        return (
          (Dl[0] = Ye(e.segment[0], i)),
          (Dl[1] = Ye(e.segment[1], i)),
          (function (t, e) {
            return ke(t, Ce(t, e));
          })(s, Dl)
        );
      }
      function zl(t, e, i) {
        const n = e.geometry;
        if ("Circle" === n.getType() && 1 === e.index) {
          let e = n;
          const s = We();
          return (
            s && (e = e.clone().transform(s, i)),
            Xe(e.getClosestPoint(Ye(t, i)), i)
          );
        }
        const s = Ye(t, i);
        return (
          (Dl[0] = Ye(e.segment[0], i)),
          (Dl[1] = Ye(e.segment[1], i)),
          Xe(Ce(s, Dl), i)
        );
      }
      function Bl() {
        const t = ro();
        return function (e, i) {
          return t.Point;
        };
      }
      const Nl = class extends cs {
          constructor(t) {
            let e;
            if (
              (super(t),
              this.on,
              this.once,
              this.un,
              (this.boundHandleFeatureChange_ =
                this.handleFeatureChange_.bind(this)),
              (this.condition_ = t.condition ? t.condition : ml),
              (this.defaultDeleteCondition_ = function (t) {
                return (
                  (function (t) {
                    const e = t.originalEvent;
                    return e.altKey && !(e.metaKey || e.ctrlKey) && !e.shiftKey;
                  })(t) &&
                  (function (t) {
                    return t.type == ns;
                  })(t)
                );
              }),
              (this.deleteCondition_ = t.deleteCondition
                ? t.deleteCondition
                : this.defaultDeleteCondition_),
              (this.insertVertexCondition_ = t.insertVertexCondition
                ? t.insertVertexCondition
                : dl),
              (this.vertexFeature_ = null),
              (this.vertexSegments_ = null),
              (this.lastPixel_ = [0, 0]),
              (this.ignoreNextSingleClick_ = !1),
              (this.featuresBeingModified_ = null),
              (this.rBush_ = new Ot()),
              (this.pixelTolerance_ =
                void 0 !== t.pixelTolerance ? t.pixelTolerance : 10),
              (this.snappedToVertex_ = !1),
              (this.changingFeature_ = !1),
              (this.dragSegments_ = []),
              (this.overlay_ = new ul({
                source: new Ci({ useSpatialIndex: !1, wrapX: !!t.wrapX }),
                style: t.style ? t.style : Bl(),
                updateWhileAnimating: !0,
                updateWhileInteracting: !0,
              })),
              (this.SEGMENT_WRITERS_ = {
                Point: this.writePointGeometry_.bind(this),
                LineString: this.writeLineStringGeometry_.bind(this),
                LinearRing: this.writeLineStringGeometry_.bind(this),
                Polygon: this.writePolygonGeometry_.bind(this),
                MultiPoint: this.writeMultiPointGeometry_.bind(this),
                MultiLineString: this.writeMultiLineStringGeometry_.bind(this),
                MultiPolygon: this.writeMultiPolygonGeometry_.bind(this),
                Circle: this.writeCircleGeometry_.bind(this),
                GeometryCollection:
                  this.writeGeometryCollectionGeometry_.bind(this),
              }),
              (this.source_ = null),
              (this.hitDetection_ = null),
              t.features
                ? (e = t.features)
                : t.source &&
                  ((this.source_ = t.source),
                  (e = new B(this.source_.getFeatures())),
                  this.source_.addEventListener(
                    ui,
                    this.handleSourceAdd_.bind(this)
                  ),
                  this.source_.addEventListener(
                    fi,
                    this.handleSourceRemove_.bind(this)
                  )),
              !e)
            )
              throw new Error(
                "The modify interaction requires features, a source or a layer"
              );
            t.hitDetection && (this.hitDetection_ = t.hitDetection),
              (this.features_ = e),
              this.features_.forEach(this.addFeature_.bind(this)),
              this.features_.addEventListener(
                j,
                this.handleFeatureAdd_.bind(this)
              ),
              this.features_.addEventListener(
                G,
                this.handleFeatureRemove_.bind(this)
              ),
              (this.lastPointerEvent_ = null),
              (this.delta_ = [0, 0]),
              (this.snapToPointer_ =
                void 0 === t.snapToPointer
                  ? !this.hitDetection_
                  : t.snapToPointer);
          }
          addFeature_(t) {
            const e = t.getGeometry();
            if (e) {
              const i = this.SEGMENT_WRITERS_[e.getType()];
              i && i(t, e);
            }
            const i = this.getMap();
            i &&
              i.isRendered() &&
              this.getActive() &&
              this.handlePointerAtPixel_(this.lastPixel_, i),
              t.addEventListener(w, this.boundHandleFeatureChange_);
          }
          willModifyFeatures_(t, e) {
            if (!this.featuresBeingModified_) {
              this.featuresBeingModified_ = new B();
              const i = this.featuresBeingModified_.getArray();
              for (let t = 0, n = e.length; t < n; ++t) {
                const n = e[t];
                for (let t = 0, e = n.length; t < e; ++t) {
                  const e = n[t].feature;
                  e && !i.includes(e) && this.featuresBeingModified_.push(e);
                }
              }
              0 === this.featuresBeingModified_.getLength()
                ? (this.featuresBeingModified_ = null)
                : this.dispatchEvent(
                    new jl(Al, this.featuresBeingModified_, t)
                  );
            }
          }
          removeFeature_(t) {
            this.removeFeatureSegmentData_(t),
              this.vertexFeature_ &&
                0 === this.features_.getLength() &&
                (this.overlay_.getSource().removeFeature(this.vertexFeature_),
                (this.vertexFeature_ = null)),
              t.removeEventListener(w, this.boundHandleFeatureChange_);
          }
          removeFeatureSegmentData_(t) {
            const e = this.rBush_,
              i = [];
            e.forEach(function (e) {
              t === e.feature && i.push(e);
            });
            for (let n = i.length - 1; n >= 0; --n) {
              const t = i[n];
              for (let e = this.dragSegments_.length - 1; e >= 0; --e)
                this.dragSegments_[e][0] === t &&
                  this.dragSegments_.splice(e, 1);
              e.remove(t);
            }
          }
          setActive(t) {
            this.vertexFeature_ &&
              !t &&
              (this.overlay_.getSource().removeFeature(this.vertexFeature_),
              (this.vertexFeature_ = null)),
              super.setActive(t);
          }
          setMap(t) {
            this.overlay_.setMap(t), super.setMap(t);
          }
          getOverlay() {
            return this.overlay_;
          }
          handleSourceAdd_(t) {
            t.feature && this.features_.push(t.feature);
          }
          handleSourceRemove_(t) {
            t.feature && this.features_.remove(t.feature);
          }
          handleFeatureAdd_(t) {
            this.addFeature_(t.element);
          }
          handleFeatureChange_(t) {
            if (!this.changingFeature_) {
              const e = t.target;
              this.removeFeature_(e), this.addFeature_(e);
            }
          }
          handleFeatureRemove_(t) {
            this.removeFeature_(t.element);
          }
          writePointGeometry_(t, e) {
            const i = e.getCoordinates(),
              n = { feature: t, geometry: e, segment: [i, i] };
            this.rBush_.insert(e.getExtent(), n);
          }
          writeMultiPointGeometry_(t, e) {
            const i = e.getCoordinates();
            for (let n = 0, s = i.length; n < s; ++n) {
              const s = i[n],
                r = {
                  feature: t,
                  geometry: e,
                  depth: [n],
                  index: n,
                  segment: [s, s],
                };
              this.rBush_.insert(e.getExtent(), r);
            }
          }
          writeLineStringGeometry_(t, e) {
            const i = e.getCoordinates();
            for (let n = 0, s = i.length - 1; n < s; ++n) {
              const s = i.slice(n, n + 2),
                r = { feature: t, geometry: e, index: n, segment: s };
              this.rBush_.insert(ot(s), r);
            }
          }
          writeMultiLineStringGeometry_(t, e) {
            const i = e.getCoordinates();
            for (let n = 0, s = i.length; n < s; ++n) {
              const s = i[n];
              for (let i = 0, r = s.length - 1; i < r; ++i) {
                const r = s.slice(i, i + 2),
                  o = {
                    feature: t,
                    geometry: e,
                    depth: [n],
                    index: i,
                    segment: r,
                  };
                this.rBush_.insert(ot(r), o);
              }
            }
          }
          writePolygonGeometry_(t, e) {
            const i = e.getCoordinates();
            for (let n = 0, s = i.length; n < s; ++n) {
              const s = i[n];
              for (let i = 0, r = s.length - 1; i < r; ++i) {
                const r = s.slice(i, i + 2),
                  o = {
                    feature: t,
                    geometry: e,
                    depth: [n],
                    index: i,
                    segment: r,
                  };
                this.rBush_.insert(ot(r), o);
              }
            }
          }
          writeMultiPolygonGeometry_(t, e) {
            const i = e.getCoordinates();
            for (let n = 0, s = i.length; n < s; ++n) {
              const s = i[n];
              for (let i = 0, r = s.length; i < r; ++i) {
                const r = s[i];
                for (let s = 0, o = r.length - 1; s < o; ++s) {
                  const o = r.slice(s, s + 2),
                    a = {
                      feature: t,
                      geometry: e,
                      depth: [i, n],
                      index: s,
                      segment: o,
                    };
                  this.rBush_.insert(ot(o), a);
                }
              }
            }
          }
          writeCircleGeometry_(t, e) {
            const i = e.getCenter(),
              n = { feature: t, geometry: e, index: 0, segment: [i, i] },
              s = { feature: t, geometry: e, index: 1, segment: [i, i] },
              r = [n, s];
            (n.featureSegments = r),
              (s.featureSegments = r),
              this.rBush_.insert(mt(i), n);
            let o = e;
            const a = We();
            if (a && this.getMap()) {
              const t = this.getMap().getView().getProjection();
              (o = o.clone().transform(a, t)), (o = rn(o).transform(t, a));
            }
            this.rBush_.insert(o.getExtent(), s);
          }
          writeGeometryCollectionGeometry_(t, e) {
            const i = e.getGeometriesArray();
            for (let n = 0; n < i.length; ++n) {
              const e = i[n];
              (0, this.SEGMENT_WRITERS_[e.getType()])(t, e);
            }
          }
          createOrUpdateVertexFeature_(t, e, i) {
            let n = this.vertexFeature_;
            if (n) {
              n.getGeometry().setCoordinates(t);
            } else
              (n = new O(new Oi(t))),
                (this.vertexFeature_ = n),
                this.overlay_.getSource().addFeature(n);
            return n.set("features", e), n.set("geometries", i), n;
          }
          handleEvent(t) {
            if (!t.originalEvent) return !0;
            let e;
            return (
              (this.lastPointerEvent_ = t),
              t.map.getView().getInteracting() ||
                t.type != os ||
                this.handlingDownUpSequence ||
                this.handlePointerMove_(t),
              this.vertexFeature_ &&
                this.deleteCondition_(t) &&
                (e =
                  !(t.type != ns || !this.ignoreNextSingleClick_) ||
                  this.removePoint()),
              t.type == ns && (this.ignoreNextSingleClick_ = !1),
              super.handleEvent(t) && !e
            );
          }
          handleDragEvent(t) {
            (this.ignoreNextSingleClick_ = !1),
              this.willModifyFeatures_(t, this.dragSegments_);
            const e = [
                t.coordinate[0] + this.delta_[0],
                t.coordinate[1] + this.delta_[1],
              ],
              i = [],
              n = [];
            for (let s = 0, r = this.dragSegments_.length; s < r; ++s) {
              const r = this.dragSegments_[s],
                o = r[0],
                a = o.feature;
              i.includes(a) || i.push(a);
              const l = o.geometry;
              n.includes(l) || n.push(l);
              const h = o.depth;
              let c;
              const u = o.segment,
                d = r[1];
              for (; e.length < l.getStride(); ) e.push(u[d][e.length]);
              switch (l.getType()) {
                case "Point":
                  (c = e), (u[0] = e), (u[1] = e);
                  break;
                case "MultiPoint":
                  (c = l.getCoordinates()),
                    (c[o.index] = e),
                    (u[0] = e),
                    (u[1] = e);
                  break;
                case "LineString":
                  (c = l.getCoordinates()), (c[o.index + d] = e), (u[d] = e);
                  break;
                case "MultiLineString":
                case "Polygon":
                  (c = l.getCoordinates()),
                    (c[h[0]][o.index + d] = e),
                    (u[d] = e);
                  break;
                case "MultiPolygon":
                  (c = l.getCoordinates()),
                    (c[h[1]][h[0]][o.index + d] = e),
                    (u[d] = e);
                  break;
                case "Circle":
                  if (((u[0] = e), (u[1] = e), 0 === o.index))
                    (this.changingFeature_ = !0),
                      l.setCenter(e),
                      (this.changingFeature_ = !1);
                  else {
                    this.changingFeature_ = !0;
                    const i = t.map.getView().getProjection();
                    let n = Me(Ye(l.getCenter(), i), Ye(e, i));
                    const s = We();
                    if (s) {
                      const t = l.clone().transform(s, i);
                      t.setRadius(n), (n = t.transform(i, s).getRadius());
                    }
                    l.setRadius(n), (this.changingFeature_ = !1);
                  }
              }
              c && this.setGeometryCoordinates_(l, c);
            }
            this.createOrUpdateVertexFeature_(e, i, n);
          }
          handleDownEvent(t) {
            if (!this.condition_(t)) return !1;
            const e = t.coordinate;
            this.handlePointerAtPixel_(t.pixel, t.map, e),
              (this.dragSegments_.length = 0),
              (this.featuresBeingModified_ = null);
            const i = this.vertexFeature_;
            if (i) {
              const n = t.map.getView().getProjection(),
                s = [],
                r = i.getGeometry().getCoordinates(),
                o = ot([r]),
                a = this.rBush_.getInExtent(o),
                l = {};
              a.sort(Gl);
              for (let i = 0, h = a.length; i < h; ++i) {
                const o = a[i],
                  h = o.segment;
                let c = F(o.geometry);
                const u = o.depth;
                if (
                  (u && (c += "-" + u.join("-")),
                  l[c] || (l[c] = new Array(2)),
                  "Circle" !== o.geometry.getType() || 1 !== o.index)
                )
                  if (!be(h[0], r) || l[c][0])
                    if (!be(h[1], r) || l[c][1])
                      F(h) in this.vertexSegments_ &&
                        !l[c][0] &&
                        !l[c][1] &&
                        this.insertVertexCondition_(t) &&
                        s.push(o);
                    else {
                      if (l[c][0] && 0 === l[c][0].index) {
                        let t = o.geometry.getCoordinates();
                        switch (o.geometry.getType()) {
                          case "LineString":
                          case "MultiLineString":
                            continue;
                          case "MultiPolygon":
                            t = t[u[1]];
                          case "Polygon":
                            if (o.index !== t[u[0]].length - 2) continue;
                        }
                      }
                      this.dragSegments_.push([o, 1]), (l[c][1] = o);
                    }
                  else this.dragSegments_.push([o, 0]), (l[c][0] = o);
                else {
                  be(zl(e, o, n), r) &&
                    !l[c][0] &&
                    (this.dragSegments_.push([o, 0]), (l[c][0] = o));
                }
              }
              s.length && this.willModifyFeatures_(t, [s]);
              for (let t = s.length - 1; t >= 0; --t)
                this.insertVertex_(s[t], r);
            }
            return !!this.vertexFeature_;
          }
          handleUpEvent(t) {
            for (let e = this.dragSegments_.length - 1; e >= 0; --e) {
              const i = this.dragSegments_[e][0],
                n = i.geometry;
              if ("Circle" === n.getType()) {
                const e = n.getCenter(),
                  s = i.featureSegments[0],
                  r = i.featureSegments[1];
                (s.segment[0] = e),
                  (s.segment[1] = e),
                  (r.segment[0] = e),
                  (r.segment[1] = e),
                  this.rBush_.update(mt(e), s);
                let o = n;
                const a = We();
                if (a) {
                  const e = t.map.getView().getProjection();
                  (o = o.clone().transform(a, e)), (o = rn(o).transform(e, a));
                }
                this.rBush_.update(o.getExtent(), r);
              } else this.rBush_.update(ot(i.segment), i);
            }
            return (
              this.featuresBeingModified_ &&
                (this.dispatchEvent(new jl(Ol, this.featuresBeingModified_, t)),
                (this.featuresBeingModified_ = null)),
              !1
            );
          }
          handlePointerMove_(t) {
            (this.lastPixel_ = t.pixel),
              this.handlePointerAtPixel_(t.pixel, t.map, t.coordinate);
          }
          handlePointerAtPixel_(t, e, i) {
            const n = i || e.getCoordinateFromPixel(t),
              s = e.getView().getProjection(),
              r = function (t, e) {
                return Zl(n, t, s) - Zl(n, e, s);
              };
            let o, a;
            if (this.hitDetection_) {
              const i =
                "object" === typeof this.hitDetection_
                  ? (t) => t === this.hitDetection_
                  : void 0;
              e.forEachFeatureAtPixel(
                t,
                (t, e, i) => {
                  i &&
                    "Point" === i.getType() &&
                    (i = new Oi(Xe(i.getCoordinates(), s)));
                  const n = i || t.getGeometry();
                  if (t instanceof O && this.features_.getArray().includes(t)) {
                    a = n;
                    const e = t.getGeometry().getFlatCoordinates().slice(0, 2);
                    o = [{ feature: t, geometry: a, segment: [e, e] }];
                  }
                  return !0;
                },
                { layerFilter: i }
              );
            }
            if (!o) {
              const t = Ve(
                at(
                  qe(mt(n, Tl), s),
                  e.getView().getResolution() * this.pixelTolerance_,
                  Tl
                ),
                s
              );
              o = this.rBush_.getInExtent(t);
            }
            if (o && o.length > 0) {
              const i = o.sort(r)[0],
                l = i.segment;
              let h = zl(n, i, s);
              const c = e.getPixelFromCoordinate(h);
              let u = Me(t, c);
              if (a || u <= this.pixelTolerance_) {
                const t = {};
                if (
                  ((t[F(l)] = !0),
                  this.snapToPointer_ ||
                    ((this.delta_[0] = h[0] - n[0]),
                    (this.delta_[1] = h[1] - n[1])),
                  "Circle" === i.geometry.getType() && 1 === i.index)
                )
                  (this.snappedToVertex_ = !0),
                    this.createOrUpdateVertexFeature_(
                      h,
                      [i.feature],
                      [i.geometry]
                    );
                else {
                  const n = e.getPixelFromCoordinate(l[0]),
                    s = e.getPixelFromCoordinate(l[1]),
                    r = ke(c, n),
                    a = ke(c, s);
                  (u = Math.sqrt(Math.min(r, a))),
                    (this.snappedToVertex_ = u <= this.pixelTolerance_),
                    this.snappedToVertex_ && (h = r > a ? l[1] : l[0]),
                    this.createOrUpdateVertexFeature_(
                      h,
                      [i.feature],
                      [i.geometry]
                    );
                  const d = {};
                  d[F(i.geometry)] = !0;
                  for (let e = 1, i = o.length; e < i; ++e) {
                    const i = o[e].segment;
                    if (
                      !(
                        (be(l[0], i[0]) && be(l[1], i[1])) ||
                        (be(l[0], i[1]) && be(l[1], i[0]))
                      )
                    )
                      break;
                    {
                      const n = F(o[e].geometry);
                      n in d || ((d[n] = !0), (t[F(i)] = !0));
                    }
                  }
                }
                return void (this.vertexSegments_ = t);
              }
            }
            this.vertexFeature_ &&
              (this.overlay_.getSource().removeFeature(this.vertexFeature_),
              (this.vertexFeature_ = null));
          }
          insertVertex_(t, e) {
            const i = t.segment,
              n = t.feature,
              s = t.geometry,
              r = t.depth,
              o = t.index;
            let a;
            for (; e.length < s.getStride(); ) e.push(0);
            switch (s.getType()) {
              case "MultiLineString":
              case "Polygon":
                (a = s.getCoordinates()), a[r[0]].splice(o + 1, 0, e);
                break;
              case "MultiPolygon":
                (a = s.getCoordinates()), a[r[1]][r[0]].splice(o + 1, 0, e);
                break;
              case "LineString":
                (a = s.getCoordinates()), a.splice(o + 1, 0, e);
                break;
              default:
                return;
            }
            this.setGeometryCoordinates_(s, a);
            const l = this.rBush_;
            l.remove(t), this.updateSegmentIndices_(s, o, r, 1);
            const h = {
              segment: [i[0], e],
              feature: n,
              geometry: s,
              depth: r,
              index: o,
            };
            l.insert(ot(h.segment), h), this.dragSegments_.push([h, 1]);
            const c = {
              segment: [e, i[1]],
              feature: n,
              geometry: s,
              depth: r,
              index: o + 1,
            };
            l.insert(ot(c.segment), c),
              this.dragSegments_.push([c, 0]),
              (this.ignoreNextSingleClick_ = !0);
          }
          removePoint() {
            if (this.lastPointerEvent_ && this.lastPointerEvent_.type != rs) {
              const t = this.lastPointerEvent_;
              this.willModifyFeatures_(t, this.dragSegments_);
              const e = this.removeVertex_();
              return (
                this.featuresBeingModified_ &&
                  this.dispatchEvent(
                    new jl(Ol, this.featuresBeingModified_, t)
                  ),
                (this.featuresBeingModified_ = null),
                e
              );
            }
            return !1;
          }
          removeVertex_() {
            const t = this.dragSegments_,
              e = {};
            let i,
              n,
              s,
              r,
              o,
              a,
              l,
              h,
              c,
              u,
              d,
              g = !1;
            for (o = t.length - 1; o >= 0; --o)
              (s = t[o]),
                (u = s[0]),
                (d = F(u.feature)),
                u.depth && (d += "-" + u.depth.join("-")),
                d in e || (e[d] = {}),
                0 === s[1]
                  ? ((e[d].right = u), (e[d].index = u.index))
                  : 1 == s[1] && ((e[d].left = u), (e[d].index = u.index + 1));
            for (d in e) {
              switch (
                ((c = e[d].right),
                (l = e[d].left),
                (a = e[d].index),
                (h = a - 1),
                (u = void 0 !== l ? l : c),
                h < 0 && (h = 0),
                (r = u.geometry),
                (n = r.getCoordinates()),
                (i = n),
                (g = !1),
                r.getType())
              ) {
                case "MultiLineString":
                  n[u.depth[0]].length > 2 &&
                    (n[u.depth[0]].splice(a, 1), (g = !0));
                  break;
                case "LineString":
                  n.length > 2 && (n.splice(a, 1), (g = !0));
                  break;
                case "MultiPolygon":
                  i = i[u.depth[1]];
                case "Polygon":
                  (i = i[u.depth[0]]),
                    i.length > 4 &&
                      (a == i.length - 1 && (a = 0),
                      i.splice(a, 1),
                      (g = !0),
                      0 === a && (i.pop(), i.push(i[0]), (h = i.length - 1)));
              }
              if (g) {
                this.setGeometryCoordinates_(r, n);
                const e = [];
                if (
                  (void 0 !== l &&
                    (this.rBush_.remove(l), e.push(l.segment[0])),
                  void 0 !== c && (this.rBush_.remove(c), e.push(c.segment[1])),
                  void 0 !== l && void 0 !== c)
                ) {
                  const t = {
                    depth: u.depth,
                    feature: u.feature,
                    geometry: u.geometry,
                    index: h,
                    segment: e,
                  };
                  this.rBush_.insert(ot(t.segment), t);
                }
                this.updateSegmentIndices_(r, a, u.depth, -1),
                  this.vertexFeature_ &&
                    (this.overlay_
                      .getSource()
                      .removeFeature(this.vertexFeature_),
                    (this.vertexFeature_ = null)),
                  (t.length = 0);
              }
            }
            return g;
          }
          setGeometryCoordinates_(t, e) {
            (this.changingFeature_ = !0),
              t.setCoordinates(e),
              (this.changingFeature_ = !1);
          }
          updateSegmentIndices_(t, e, i, n) {
            this.rBush_.forEachInExtent(t.getExtent(), function (s) {
              s.geometry === t &&
                (void 0 === i || void 0 === s.depth || g(s.depth, i)) &&
                s.index > e &&
                (s.index += n);
            });
          }
        },
        Wl = 6371008.8;
      function Xl(t, e, i) {
        i = i || Wl;
        const n = Yt(t[1]),
          s = Yt(e[1]),
          r = (s - n) / 2,
          o = Yt(e[0] - t[0]) / 2,
          a =
            Math.sin(r) * Math.sin(r) +
            Math.sin(o) * Math.sin(o) * Math.cos(n) * Math.cos(s);
        return 2 * i * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      }
      function Yl(t, e) {
        let i = 0;
        for (let n = 0, s = t.length; n < s - 1; ++n)
          i += Xl(t[n], t[n + 1], e);
        return i;
      }
      function Vl(t, e) {
        const i = (e = e || {}).radius || Wl,
          n = e.projection || "EPSG:3857",
          s = t.getType();
        "GeometryCollection" !== s && (t = t.clone().transform(n, "EPSG:4326"));
        let r,
          o,
          a,
          l,
          h,
          c,
          u = 0;
        switch (s) {
          case "Point":
          case "MultiPoint":
            break;
          case "LineString":
          case "LinearRing":
            (r = t.getCoordinates()), (u = Yl(r, i));
            break;
          case "MultiLineString":
          case "Polygon":
            for (r = t.getCoordinates(), a = 0, l = r.length; a < l; ++a)
              u += Yl(r[a], i);
            break;
          case "MultiPolygon":
            for (r = t.getCoordinates(), a = 0, l = r.length; a < l; ++a)
              for (o = r[a], h = 0, c = o.length; h < c; ++h) u += Yl(o[h], i);
            break;
          case "GeometryCollection": {
            const i = t.getGeometries();
            for (a = 0, l = i.length; a < l; ++a) u += Vl(i[a], e);
            break;
          }
          default:
            throw new Error("Unsupported geometry type: " + s);
        }
        return u;
      }
      function ql(t, e) {
        let i = 0;
        const n = t.length;
        let s = t[n - 1][0],
          r = t[n - 1][1];
        for (let o = 0; o < n; o++) {
          const e = t[o][0],
            n = t[o][1];
          (i += Yt(e - s) * (2 + Math.sin(Yt(r)) + Math.sin(Yt(n)))),
            (s = e),
            (r = n);
        }
        return (i * e * e) / 2;
      }
      function $l(t, e) {
        const i = (e = e || {}).radius || Wl,
          n = e.projection || "EPSG:3857",
          s = t.getType();
        "GeometryCollection" !== s && (t = t.clone().transform(n, "EPSG:4326"));
        let r,
          o,
          a,
          l,
          h,
          c,
          u = 0;
        switch (s) {
          case "Point":
          case "MultiPoint":
          case "LineString":
          case "MultiLineString":
          case "LinearRing":
            break;
          case "Polygon":
            for (
              r = t.getCoordinates(),
                u = Math.abs(ql(r[0], i)),
                a = 1,
                l = r.length;
              a < l;
              ++a
            )
              u -= Math.abs(ql(r[a], i));
            break;
          case "MultiPolygon":
            for (r = t.getCoordinates(), a = 0, l = r.length; a < l; ++a)
              for (
                o = r[a], u += Math.abs(ql(o[0], i)), h = 1, c = o.length;
                h < c;
                ++h
              )
                u -= Math.abs(ql(o[h], i));
            break;
          case "GeometryCollection": {
            const i = t.getGeometries();
            for (a = 0, l = i.length; a < l; ++a) u += $l(i[a], e);
            break;
          }
          default:
            throw new Error("Unsupported geometry type: " + s);
        }
        return u;
      }
      const Ul = new ao({
          text: new go({
            font: "14px Calibri,sans-serif",
            fill: new Qr({ color: "rgba(255, 255, 255, 1)" }),
            backgroundFill: new Qr({ color: "rgba(0, 0, 0, 0.7)" }),
            padding: [3, 3, 3, 3],
            textBaseline: "middle",
            offsetY: -15,
            textAlign: "center",
          }),
          image: new Ur({
            radius: 8,
            points: 3,
            angle: Math.PI,
            displacement: [0, 10],
            fill: new Qr({ color: "rgba(0, 0, 0, 0.7)" }),
          }),
        }),
        Hl = new ao({
          text: new go({
            font: "12px Calibri,sans-serif",
            fill: new Qr({ color: "rgba(255, 255, 255, 1)" }),
            backgroundFill: new Qr({ color: "rgba(0, 0, 0, 0.4)" }),
            padding: [2, 2, 2, 2],
            textAlign: "left",
            offsetX: 15,
          }),
        }),
        Kl = new ao({
          fill: new Qr({ color: "rgba(255, 255, 255, 0.2)" }),
          stroke: new eo({
            color: "rgba(0, 0, 0, 0.5)",
            lineDash: [10, 10],
            width: 2,
          }),
          image: new Kr({
            radius: 5,
            stroke: new eo({ color: "rgba(0, 0, 0, 0.7)" }),
            fill: new Qr({ color: "rgba(255, 255, 255, 0.2)" }),
          }),
        }),
        Jl = new ao({
          text: new go({
            font: "12px Calibri,sans-serif",
            fill: new Qr({ color: "rgba(255, 255, 255, 1)" }),
            backgroundFill: new Qr({ color: "rgba(0, 0, 0, 0.4)" }),
            padding: [2, 2, 2, 2],
            textBaseline: "bottom",
            offsetY: -12,
          }),
          image: new Ur({
            radius: 6,
            points: 3,
            angle: Math.PI,
            displacement: [0, 8],
            fill: new Qr({ color: "rgba(0, 0, 0, 0.4)" }),
          }),
        }),
        Ql = new Nl({
          source: new Ci(),
          style: new ao({
            image: new Kr({
              radius: 5,
              stroke: new eo({ color: "rgba(0, 0, 0, 0.7)" }),
              fill: new Qr({ color: "rgba(0, 0, 0, 0.4)" }),
            }),
            text: new go({
              text: "Drag to modify",
              font: "12px Calibri,sans-serif",
              fill: new Qr({ color: "rgba(255, 255, 255, 1)" }),
              backgroundFill: new Qr({ color: "rgba(0, 0, 0, 0.7)" }),
              padding: [2, 2, 2, 2],
              textAlign: "left",
              offsetX: 15,
            }),
          }),
        }),
        th = [Jl],
        eh = (t) => {
          const e = Vl(t);
          return e > 1e3 ? `${(e / 1e3).toFixed(2)} km` : `${e.toFixed(2)} m`;
        },
        ih = (t) => {
          const e = $l(t);
          return e > 1e4
            ? `${(e / 1e6).toFixed(2)} km\xb2`
            : `${e.toFixed(2)} m\xb2`;
        };
      function nh(t, e, i, n) {
        const s = [],
          r = t.getGeometry();
        if (!r) return s;
        const o = r.getType();
        let a, l, h;
        if ((s.push(Kl), !i || i === o || "Point" === o))
          if ("Polygon" === o)
            r instanceof nn && ((a = r.getInteriorPoint()), (l = ih(r)));
          else if ("LineString" === o && r instanceof Hi) {
            h = r;
            const t = h.getCoordinates(),
              e = t[Math.floor(t.length / 2)];
            (a = new Oi(e)), (l = eh(h));
          }
        if (e && h) {
          let t = 0;
          h.forEachSegment((e, i) => {
            const n = new Hi([e, i]),
              r = eh(n);
            th.length - 1 < t && th.push(Jl.clone());
            const o = new Oi(n.getCoordinateAt(0.5));
            th[t].setGeometry(o);
            const a = th[t].getText();
            a && a.setText(r), s.push(th[t]), t++;
          });
        }
        if (l) {
          const t = Ul.clone();
          if ("LineString" === o && h) {
            const e = h.getCoordinates();
            if (e.length > 1) {
              const i = e[0],
                n = e[e.length - 1],
                s = [(i[0] + n[0]) / 2, (i[1] + n[1]) / 2];
              t.setGeometry(new Oi(s));
            }
          } else a && t.setGeometry(a);
          const e = t.getText();
          e && e.setText(l), s.push(t);
        }
        if (
          n &&
          "Point" === o &&
          0 === Ql?.getOverlay()?.getSource()?.getFeatures()?.length
        ) {
          const t = Hl.getText();
          t && t.setText(n), s.push(Hl);
        }
        return s;
      }
      var sh = i(46226);
      const rh = ({
        map: t,
        vectorSource: e,
        popupVisible: i,
        setPopupVisible: r,
        iconPosition: o,
      }) => {
        const a = (0, s.useRef)(null),
          l = (i) => {
            ((i) => {
              t &&
                e &&
                (a.current &&
                  (t.removeInteraction(a.current), (a.current = null)),
                (a.current = new Fl({
                  source: e,
                  type: "LineString" == i ? "LineString" : "Polygon",
                  style: (t) =>
                    nh(
                      t,
                      !0,
                      "LineString" == i ? "LineString" : "Polygon",
                      "Click to start measuring"
                    ),
                })),
                a.current.on("drawend", function (t) {
                  const e = t.feature;
                  e &&
                    e.setStyle(
                      nh(
                        e,
                        !0,
                        "LineString" == i ? "LineString" : "Polygon",
                        "Click to start measuring"
                      )
                    );
                }),
                t.addInteraction(a.current));
            })(i);
          },
          h = {
            position: "absolute",
            top: o.top + 10,
            left: o.left + 60,
            zIndex: 1e3,
            display: "flex",
            flexDirection: "row",
          };
        return n.jsx(n.Fragment, {
          children:
            i &&
            (0, n.jsxs)(Ll.Z, {
              style: h,
              children: [
                n.jsx(Mn.Z, {
                  onClick: () => l("LineString"),
                  children: n.jsx(sh.default, {
                    src: "/roller.png",
                    alt: "delete",
                    width: 22,
                    height: 24,
                    style: { cursor: "pointer" },
                  }),
                }),
                n.jsx(Mn.Z, {
                  onClick: () => l("Polygon"),
                  children: n.jsx(sh.default, {
                    src: "/area.png",
                    alt: "area",
                    width: 30,
                    height: 24,
                    style: { cursor: "pointer" },
                  }),
                }),
                n.jsx(Mn.Z, {
                  onClick: () => {
                    t &&
                      a.current &&
                      e &&
                      (t.removeInteraction(a.current),
                      (a.current = null),
                      e.clear()),
                      r(!1);
                  },
                  children: n.jsx(sh.default, {
                    src: "/delete.png",
                    alt: "delete",
                    width: 19,
                    height: 19,
                    style: { cursor: "pointer" },
                  }),
                }),
              ],
            }),
        });
      };
      var oh = i(81256),
        ah = i(90541),
        lh = i(42265),
        hh = i(23743),
        ch = i(71772);
      const uh = ({
        open: t,
        onClose: e,
        onSearch: i,
        geoCodeFeatures: r,
        iconPosition: o,
      }) => {
        const [a, l] = (0, s.useState)(r[0]),
          [h, c] = (0, s.useState)("000"),
          [u, d] = (0, s.useState)("000"),
          g = (0, hh.Z)(),
          f = (0, ch.Z)(g.breakpoints.down("sm"));
        (0, s.useEffect)(() => {
          null === a && r.length > 0 && l(r[0]);
        }, [r]);
        const p = {
          position: "absolute",
          top: f ? "20%" : o.top + 10,
          right: f ? "5%" : window.innerWidth - o.right + 80,
          zIndex: 1e3,
          padding: f ? "8px" : "16px",
          width: f ? "90%" : "350px",
          display: "flex",
          flexDirection: "column",
          backgroundColor: "#fff",
        };
        return n.jsx(n.Fragment, {
          children:
            t &&
            (0, n.jsxs)(Ll.Z, {
              style: p,
              children: [
                (0, n.jsxs)(kn.Z, {
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  paddingBottom: "15px",
                  children: [
                    n.jsx(In.Z, {
                      variant: "body1",
                      color: g.palette.primary.main,
                      children: "Search Geocode",
                    }),
                    n.jsx(Mn.Z, {
                      edge: "end",
                      color: "inherit",
                      onClick: e,
                      "aria-label": "close",
                      children: n.jsx(ki, {}),
                    }),
                  ],
                }),
                n.jsx(oh.Z, {
                  value: a,
                  onChange: (t, e) => {
                    console.log("Selected Feature", t), l(e);
                  },
                  options: r,
                  getOptionLabel: (t) =>
                    ((t) =>
                      "object" === typeof t &&
                      null !== t &&
                      "id" in t &&
                      "libelle" in t)(t)
                      ? t.libelle || "Unknown"
                      : t,
                  renderInput: (t) =>
                    n.jsx(ah.Z, {
                      ...t,
                      label: "Base Grid",
                      variant: "outlined",
                      fullWidth: !0,
                      InputProps: {
                        ...t.InputProps,
                        style: {
                          height: 40,
                          padding: "16px",
                          marginBottom: "16px",
                        },
                      },
                      InputLabelProps: { style: { lineHeight: 1.5 } },
                    }),
                }),
                (0, n.jsxs)(kn.Z, {
                  display: "flex",
                  justifyContent: "space-between",
                  gap: "16px",
                  children: [
                    n.jsx(ah.Z, {
                      fullWidth: !0,
                      margin: "normal",
                      label: "Abscissa",
                      placeholder: "000",
                      value: h,
                      onChange: (t) => c(t.target.value.slice(0, 3)),
                      InputProps: { style: { height: 40 } },
                      InputLabelProps: { style: { lineHeight: 1.5 } },
                    }),
                    n.jsx(ah.Z, {
                      fullWidth: !0,
                      margin: "normal",
                      label: "Ordinate",
                      placeholder: "000",
                      value: u,
                      onChange: (t) => d(t.target.value.slice(0, 3)),
                      InputProps: { style: { height: 40 } },
                      InputLabelProps: { style: { lineHeight: 1.5 } },
                    }),
                  ],
                }),
                n.jsx(lh.default, {
                  onClick: () => {
                    i(a, h, u), e();
                  },
                  color: "primary",
                  variant: "contained",
                  style: { marginTop: "16px" },
                  children: "Search",
                }),
              ],
            }),
        });
      };
      var dh = i(95894),
        gh = i(41135),
        fh = i(88634),
        ph = i(91703),
        mh = i(2791),
        _h = i(71685),
        yh = i(97898);
      function xh(t) {
        return (0, yh.ZP)("MuiCardMedia", t);
      }
      (0, _h.Z)("MuiCardMedia", ["root", "media", "img"]);
      const vh = (0, ph.ZP)("div", {
          name: "MuiCardMedia",
          slot: "Root",
          overridesResolver: (t, e) => {
            const { ownerState: i } = t,
              { isMediaComponent: n, isImageComponent: s } = i;
            return [e.root, n && e.media, s && e.img];
          },
        })({
          display: "block",
          backgroundSize: "cover",
          backgroundRepeat: "no-repeat",
          backgroundPosition: "center",
          variants: [
            { props: { isMediaComponent: !0 }, style: { width: "100%" } },
            { props: { isImageComponent: !0 }, style: { objectFit: "cover" } },
          ],
        }),
        wh = ["video", "audio", "picture", "iframe", "img"],
        Sh = ["picture", "img"],
        Ch = s.forwardRef(function (t, e) {
          const i = (0, mh.i)({ props: t, name: "MuiCardMedia" }),
            {
              children: s,
              className: r,
              component: o = "div",
              image: a,
              src: l,
              style: h,
              ...c
            } = i,
            u = wh.includes(o),
            d = !u && a ? { backgroundImage: `url("${a}")`, ...h } : h,
            g = {
              ...i,
              component: o,
              isMediaComponent: u,
              isImageComponent: Sh.includes(o),
            },
            f = ((t) => {
              const {
                  classes: e,
                  isMediaComponent: i,
                  isImageComponent: n,
                } = t,
                s = { root: ["root", i && "media", n && "img"] };
              return (0, fh.Z)(s, xh, e);
            })(g);
          return (0,
          n.jsx)(vh, { className: (0, gh.Z)(f.root, r), as: o, role: !u && a ? "img" : void 0, ref: e, style: d, ownerState: g, src: u ? a || l : void 0, ...c, children: s });
        }),
        bh = Ch;
      var kh = i(61832),
        Mh = i(47749),
        Ih = i(69800),
        Eh = i(34963),
        Rh = i(18680),
        Ph = i(45176),
        Fh = i(72823),
        Lh = i(64263),
        Th = i(63212),
        Dh = i(11987);
      const Ah = {
        border: 0,
        clip: "rect(0 0 0 0)",
        height: "1px",
        margin: "-1px",
        overflow: "hidden",
        padding: 0,
        position: "absolute",
        whiteSpace: "nowrap",
        width: "1px",
      };
      var Oh = i(90010);
      const jh = function (t, e, i = (t, e) => t === e) {
        return t.length === e.length && t.every((t, n) => i(t, e[n]));
      };
      function Gh(t, e) {
        return t - e;
      }
      function Zh(t, e) {
        const { index: i } =
          t.reduce((t, i, n) => {
            const s = Math.abs(e - i);
            return null === t || s < t.distance || s === t.distance
              ? { distance: s, index: n }
              : t;
          }, null) ?? {};
        return i;
      }
      function zh(t, e) {
        if (void 0 !== e.current && t.changedTouches) {
          const i = t;
          for (let t = 0; t < i.changedTouches.length; t += 1) {
            const n = i.changedTouches[t];
            if (n.identifier === e.current)
              return { x: n.clientX, y: n.clientY };
          }
          return !1;
        }
        return { x: t.clientX, y: t.clientY };
      }
      function Bh(t, e, i) {
        return (100 * (t - e)) / (i - e);
      }
      function Nh(t, e, i) {
        const n = Math.round((t - i) / e) * e + i;
        return Number(
          n.toFixed(
            (function (t) {
              if (Math.abs(t) < 1) {
                const e = t.toExponential().split("e-"),
                  i = e[0].split(".")[1];
                return (i ? i.length : 0) + parseInt(e[1], 10);
              }
              const e = t.toString().split(".")[1];
              return e ? e.length : 0;
            })(e)
          )
        );
      }
      function Wh({ values: t, newValue: e, index: i }) {
        const n = t.slice();
        return (n[i] = e), n.sort(Gh);
      }
      function Xh({ sliderRef: t, activeIndex: e, setActive: i }) {
        const n = (0, Eh.Z)(t.current);
        (t.current?.contains(n.activeElement) &&
          Number(n?.activeElement?.getAttribute("data-index")) === e) ||
          t.current?.querySelector(`[type="range"][data-index="${e}"]`).focus(),
          i && i(e);
      }
      function Yh(t, e) {
        return "number" === typeof t && "number" === typeof e
          ? t === e
          : "object" === typeof t && "object" === typeof e && jh(t, e);
      }
      const Vh = {
          horizontal: {
            offset: (t) => ({ left: `${t}%` }),
            leap: (t) => ({ width: `${t}%` }),
          },
          "horizontal-reverse": {
            offset: (t) => ({ right: `${t}%` }),
            leap: (t) => ({ width: `${t}%` }),
          },
          vertical: {
            offset: (t) => ({ bottom: `${t}%` }),
            leap: (t) => ({ height: `${t}%` }),
          },
        },
        qh = (t) => t;
      let $h;
      function Uh() {
        return (
          void 0 === $h &&
            ($h =
              "undefined" === typeof CSS ||
              "function" !== typeof CSS.supports ||
              CSS.supports("touch-action", "none")),
          $h
        );
      }
      function Hh(t) {
        const {
            "aria-labelledby": e,
            defaultValue: i,
            disabled: n = !1,
            disableSwap: r = !1,
            isRtl: o = !1,
            marks: a = !1,
            max: l = 100,
            min: h = 0,
            name: c,
            onChange: u,
            onChangeCommitted: d,
            orientation: g = "horizontal",
            rootRef: f,
            scale: p = qh,
            step: m = 1,
            shiftStep: _ = 10,
            tabIndex: y,
            value: x,
          } = t,
          v = s.useRef(void 0),
          [w, S] = s.useState(-1),
          [C, b] = s.useState(-1),
          [k, M] = s.useState(!1),
          I = s.useRef(0),
          [E, R] = (0, Rh.Z)({
            controlled: x,
            default: i ?? h,
            name: "Slider",
          }),
          P =
            u &&
            ((t, e, i) => {
              const n = t.nativeEvent || t,
                s = new n.constructor(n.type, n);
              Object.defineProperty(s, "target", {
                writable: !0,
                value: { value: e, name: c },
              }),
                u(s, e, i);
            }),
          F = Array.isArray(E);
        let L = F ? E.slice().sort(Gh) : [E];
        L = L.map((t) => (null == t ? h : (0, Ph.Z)(t, h, l)));
        const T =
            !0 === a && null !== m
              ? [...Array(Math.floor((l - h) / m) + 1)].map((t, e) => ({
                  value: h + m * e,
                }))
              : a || [],
          D = T.map((t) => t.value),
          [A, O] = s.useState(-1),
          j = s.useRef(null),
          G = (0, Fh.Z)(f, j),
          Z = (t) => (e) => {
            const i = Number(e.currentTarget.getAttribute("data-index"));
            (0, Lh.Z)(e.target) && O(i), b(i), t?.onFocus?.(e);
          },
          z = (t) => (e) => {
            (0, Lh.Z)(e.target) || O(-1), b(-1), t?.onBlur?.(e);
          },
          B = (t, e) => {
            const i = Number(t.currentTarget.getAttribute("data-index")),
              n = L[i],
              s = D.indexOf(n);
            let o = e;
            if (T && null == m) {
              const t = D[D.length - 1];
              o = o > t ? t : o < D[0] ? D[0] : o < n ? D[s - 1] : D[s + 1];
            }
            if (((o = (0, Ph.Z)(o, h, l)), F)) {
              r && (o = (0, Ph.Z)(o, L[i - 1] || -1 / 0, L[i + 1] || 1 / 0));
              const t = o;
              o = Wh({ values: L, newValue: o, index: i });
              let e = i;
              r || (e = o.indexOf(t)), Xh({ sliderRef: j, activeIndex: e });
            }
            R(o), O(i), P && !Yh(o, E) && P(t, o, i), d && d(t, o);
          },
          N = (t) => (e) => {
            if (null !== m) {
              const t = Number(e.currentTarget.getAttribute("data-index")),
                i = L[t];
              let n = null;
              (("ArrowLeft" === e.key || "ArrowDown" === e.key) &&
                e.shiftKey) ||
              "PageDown" === e.key
                ? (n = Math.max(i - _, h))
                : ((("ArrowRight" === e.key || "ArrowUp" === e.key) &&
                    e.shiftKey) ||
                    "PageUp" === e.key) &&
                  (n = Math.min(i + _, l)),
                null !== n && (B(e, n), e.preventDefault());
            }
            t?.onKeyDown?.(e);
          };
        (0, Th.Z)(() => {
          n &&
            j.current.contains(document.activeElement) &&
            document.activeElement?.blur();
        }, [n]),
          n && -1 !== w && S(-1),
          n && -1 !== A && O(-1);
        const W = s.useRef(void 0);
        let X = g;
        o && "horizontal" === g && (X += "-reverse");
        const Y = ({ finger: t, move: e = !1 }) => {
            const { current: i } = j,
              {
                width: n,
                height: s,
                bottom: o,
                left: a,
              } = i.getBoundingClientRect();
            let c, u;
            if (
              ((c = X.startsWith("vertical") ? (o - t.y) / s : (t.x - a) / n),
              X.includes("-reverse") && (c = 1 - c),
              (u = (function (t, e, i) {
                return (i - e) * t + e;
              })(c, h, l)),
              m)
            )
              u = Nh(u, m, h);
            else {
              const t = Zh(D, u);
              u = D[t];
            }
            u = (0, Ph.Z)(u, h, l);
            let d = 0;
            if (F) {
              (d = e ? W.current : Zh(L, u)),
                r && (u = (0, Ph.Z)(u, L[d - 1] || -1 / 0, L[d + 1] || 1 / 0));
              const t = u;
              (u = Wh({ values: L, newValue: u, index: d })),
                (r && e) || ((d = u.indexOf(t)), (W.current = d));
            }
            return { newValue: u, activeIndex: d };
          },
          V = (0, Dh.Z)((t) => {
            const e = zh(t, v);
            if (!e) return;
            if (((I.current += 1), "mousemove" === t.type && 0 === t.buttons))
              return void q(t);
            const { newValue: i, activeIndex: n } = Y({ finger: e, move: !0 });
            Xh({ sliderRef: j, activeIndex: n, setActive: S }),
              R(i),
              !k && I.current > 2 && M(!0),
              P && !Yh(i, E) && P(t, i, n);
          }),
          q = (0, Dh.Z)((t) => {
            const e = zh(t, v);
            if ((M(!1), !e)) return;
            const { newValue: i } = Y({ finger: e, move: !0 });
            S(-1),
              "touchend" === t.type && b(-1),
              d && d(t, i),
              (v.current = void 0),
              U();
          }),
          $ = (0, Dh.Z)((t) => {
            if (n) return;
            Uh() || t.preventDefault();
            const e = t.changedTouches[0];
            null != e && (v.current = e.identifier);
            const i = zh(t, v);
            if (!1 !== i) {
              const { newValue: e, activeIndex: n } = Y({ finger: i });
              Xh({ sliderRef: j, activeIndex: n, setActive: S }),
                R(e),
                P && !Yh(e, E) && P(t, e, n);
            }
            I.current = 0;
            const s = (0, Eh.Z)(j.current);
            s.addEventListener("touchmove", V, { passive: !0 }),
              s.addEventListener("touchend", q, { passive: !0 });
          }),
          U = s.useCallback(() => {
            const t = (0, Eh.Z)(j.current);
            t.removeEventListener("mousemove", V),
              t.removeEventListener("mouseup", q),
              t.removeEventListener("touchmove", V),
              t.removeEventListener("touchend", q);
          }, [q, V]);
        s.useEffect(() => {
          const { current: t } = j;
          return (
            t.addEventListener("touchstart", $, { passive: Uh() }),
            () => {
              t.removeEventListener("touchstart", $), U();
            }
          );
        }, [U, $]),
          s.useEffect(() => {
            n && U();
          }, [n, U]);
        const H = Bh(F ? L[0] : h, h, l),
          K = Bh(L[L.length - 1], h, l) - H,
          J = (t) => (e) => {
            t.onMouseLeave?.(e), b(-1);
          };
        return {
          active: w,
          axis: X,
          axisProps: Vh,
          dragging: k,
          focusedThumbIndex: A,
          getHiddenInputProps: (i = {}) => {
            const s = (0, Oh.Z)(i),
              r = {
                onChange:
                  ((a = s || {}),
                  (t) => {
                    a.onChange?.(t), B(t, t.target.valueAsNumber);
                  }),
                onFocus: Z(s || {}),
                onBlur: z(s || {}),
                onKeyDown: N(s || {}),
              };
            var a;
            const u = { ...s, ...r };
            return {
              tabIndex: y,
              "aria-labelledby": e,
              "aria-orientation": g,
              "aria-valuemax": p(l),
              "aria-valuemin": p(h),
              name: c,
              type: "range",
              min: t.min,
              max: t.max,
              step: null === t.step && t.marks ? "any" : t.step ?? void 0,
              disabled: n,
              ...i,
              ...u,
              style: {
                ...Ah,
                direction: o ? "rtl" : "ltr",
                width: "100%",
                height: "100%",
              },
            };
          },
          getRootProps: (t = {}) => {
            const e = (0, Oh.Z)(t),
              i = {
                onMouseDown:
                  ((s = e || {}),
                  (t) => {
                    if ((s.onMouseDown?.(t), n)) return;
                    if (t.defaultPrevented) return;
                    if (0 !== t.button) return;
                    t.preventDefault();
                    const e = zh(t, v);
                    if (!1 !== e) {
                      const { newValue: i, activeIndex: n } = Y({ finger: e });
                      Xh({ sliderRef: j, activeIndex: n, setActive: S }),
                        R(i),
                        P && !Yh(i, E) && P(t, i, n);
                    }
                    I.current = 0;
                    const i = (0, Eh.Z)(j.current);
                    i.addEventListener("mousemove", V, { passive: !0 }),
                      i.addEventListener("mouseup", q);
                  }),
              };
            var s;
            const r = { ...e, ...i };
            return { ...t, ref: G, ...r };
          },
          getThumbProps: (t = {}) => {
            const e = (0, Oh.Z)(t),
              i = {
                onMouseOver:
                  ((n = e || {}),
                  (t) => {
                    n.onMouseOver?.(t);
                    const e = Number(
                      t.currentTarget.getAttribute("data-index")
                    );
                    b(e);
                  }),
                onMouseLeave: J(e || {}),
              };
            var n;
            return { ...t, ...e, ...i };
          },
          marks: T,
          open: C,
          range: F,
          rootRef: G,
          trackLeap: K,
          trackOffset: H,
          values: L,
          getThumbStyle: (t) => ({
            pointerEvents: -1 !== w && w !== t ? "none" : void 0,
          }),
        };
      }
      var Kh = i(81341),
        Jh = i(5637),
        Qh = i(5193);
      const tc = (t) => !t || !(0, Kh.Z)(t);
      var ec = i(54641),
        ic = i(40955);
      function nc(t) {
        return (0, yh.ZP)("MuiSlider", t);
      }
      const sc = (0, _h.Z)("MuiSlider", [
        "root",
        "active",
        "colorPrimary",
        "colorSecondary",
        "colorError",
        "colorInfo",
        "colorSuccess",
        "colorWarning",
        "disabled",
        "dragging",
        "focusVisible",
        "mark",
        "markActive",
        "marked",
        "markLabel",
        "markLabelActive",
        "rail",
        "sizeSmall",
        "thumb",
        "thumbColorPrimary",
        "thumbColorSecondary",
        "thumbColorError",
        "thumbColorSuccess",
        "thumbColorInfo",
        "thumbColorWarning",
        "track",
        "trackInverted",
        "trackFalse",
        "thumbSizeSmall",
        "valueLabel",
        "valueLabelOpen",
        "valueLabelCircle",
        "valueLabelLabel",
        "vertical",
      ]);
      function rc(t) {
        return t;
      }
      const oc = (0, ph.ZP)("span", {
          name: "MuiSlider",
          slot: "Root",
          overridesResolver: (t, e) => {
            const { ownerState: i } = t;
            return [
              e.root,
              e[`color${(0, ec.Z)(i.color)}`],
              "medium" !== i.size && e[`size${(0, ec.Z)(i.size)}`],
              i.marked && e.marked,
              "vertical" === i.orientation && e.vertical,
              "inverted" === i.track && e.trackInverted,
              !1 === i.track && e.trackFalse,
            ];
          },
        })(
          (0, Jh.Z)(({ theme: t }) => ({
            borderRadius: 12,
            boxSizing: "content-box",
            display: "inline-block",
            position: "relative",
            cursor: "pointer",
            touchAction: "none",
            WebkitTapHighlightColor: "transparent",
            "@media print": { colorAdjust: "exact" },
            [`&.${sc.disabled}`]: {
              pointerEvents: "none",
              cursor: "default",
              color: (t.vars || t).palette.grey[400],
            },
            [`&.${sc.dragging}`]: {
              [`& .${sc.thumb}, & .${sc.track}`]: { transition: "none" },
            },
            variants: [
              ...Object.entries(t.palette)
                .filter((0, ic.Z)())
                .map(([e]) => ({
                  props: { color: e },
                  style: { color: (t.vars || t).palette[e].main },
                })),
              {
                props: { orientation: "horizontal" },
                style: {
                  height: 4,
                  width: "100%",
                  padding: "13px 0",
                  "@media (pointer: coarse)": { padding: "20px 0" },
                },
              },
              {
                props: { orientation: "horizontal", size: "small" },
                style: { height: 2 },
              },
              {
                props: { orientation: "horizontal", marked: !0 },
                style: { marginBottom: 20 },
              },
              {
                props: { orientation: "vertical" },
                style: {
                  height: "100%",
                  width: 4,
                  padding: "0 13px",
                  "@media (pointer: coarse)": { padding: "0 20px" },
                },
              },
              {
                props: { orientation: "vertical", size: "small" },
                style: { width: 2 },
              },
              {
                props: { orientation: "vertical", marked: !0 },
                style: { marginRight: 44 },
              },
            ],
          }))
        ),
        ac = (0, ph.ZP)("span", {
          name: "MuiSlider",
          slot: "Rail",
          overridesResolver: (t, e) => e.rail,
        })({
          display: "block",
          position: "absolute",
          borderRadius: "inherit",
          backgroundColor: "currentColor",
          opacity: 0.38,
          variants: [
            {
              props: { orientation: "horizontal" },
              style: {
                width: "100%",
                height: "inherit",
                top: "50%",
                transform: "translateY(-50%)",
              },
            },
            {
              props: { orientation: "vertical" },
              style: {
                height: "100%",
                width: "inherit",
                left: "50%",
                transform: "translateX(-50%)",
              },
            },
            { props: { track: "inverted" }, style: { opacity: 1 } },
          ],
        }),
        lc = (0, ph.ZP)("span", {
          name: "MuiSlider",
          slot: "Track",
          overridesResolver: (t, e) => e.track,
        })(
          (0, Jh.Z)(({ theme: t }) => ({
            display: "block",
            position: "absolute",
            borderRadius: "inherit",
            border: "1px solid currentColor",
            backgroundColor: "currentColor",
            transition: t.transitions.create(
              ["left", "width", "bottom", "height"],
              { duration: t.transitions.duration.shortest }
            ),
            variants: [
              { props: { size: "small" }, style: { border: "none" } },
              {
                props: { orientation: "horizontal" },
                style: {
                  height: "inherit",
                  top: "50%",
                  transform: "translateY(-50%)",
                },
              },
              {
                props: { orientation: "vertical" },
                style: {
                  width: "inherit",
                  left: "50%",
                  transform: "translateX(-50%)",
                },
              },
              { props: { track: !1 }, style: { display: "none" } },
              ...Object.entries(t.palette)
                .filter((0, ic.Z)())
                .map(([e]) => ({
                  props: { color: e, track: "inverted" },
                  style: {
                    ...(t.vars
                      ? {
                          backgroundColor: t.vars.palette.Slider[`${e}Track`],
                          borderColor: t.vars.palette.Slider[`${e}Track`],
                        }
                      : {
                          backgroundColor: (0, kh.$n)(t.palette[e].main, 0.62),
                          borderColor: (0, kh.$n)(t.palette[e].main, 0.62),
                          ...t.applyStyles("dark", {
                            backgroundColor: (0, kh._j)(t.palette[e].main, 0.5),
                          }),
                          ...t.applyStyles("dark", {
                            borderColor: (0, kh._j)(t.palette[e].main, 0.5),
                          }),
                        }),
                  },
                })),
            ],
          }))
        ),
        hc = (0, ph.ZP)("span", {
          name: "MuiSlider",
          slot: "Thumb",
          overridesResolver: (t, e) => {
            const { ownerState: i } = t;
            return [
              e.thumb,
              e[`thumbColor${(0, ec.Z)(i.color)}`],
              "medium" !== i.size && e[`thumbSize${(0, ec.Z)(i.size)}`],
            ];
          },
        })(
          (0, Jh.Z)(({ theme: t }) => ({
            position: "absolute",
            width: 20,
            height: 20,
            boxSizing: "border-box",
            borderRadius: "50%",
            outline: 0,
            backgroundColor: "currentColor",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            transition: t.transitions.create(["box-shadow", "left", "bottom"], {
              duration: t.transitions.duration.shortest,
            }),
            "&::before": {
              position: "absolute",
              content: '""',
              borderRadius: "inherit",
              width: "100%",
              height: "100%",
              boxShadow: (t.vars || t).shadows[2],
            },
            "&::after": {
              position: "absolute",
              content: '""',
              borderRadius: "50%",
              width: 42,
              height: 42,
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
            },
            [`&.${sc.disabled}`]: { "&:hover": { boxShadow: "none" } },
            variants: [
              {
                props: { size: "small" },
                style: {
                  width: 12,
                  height: 12,
                  "&::before": { boxShadow: "none" },
                },
              },
              {
                props: { orientation: "horizontal" },
                style: { top: "50%", transform: "translate(-50%, -50%)" },
              },
              {
                props: { orientation: "vertical" },
                style: { left: "50%", transform: "translate(-50%, 50%)" },
              },
              ...Object.entries(t.palette)
                .filter((0, ic.Z)())
                .map(([e]) => ({
                  props: { color: e },
                  style: {
                    [`&:hover, &.${sc.focusVisible}`]: {
                      ...(t.vars
                        ? {
                            boxShadow: `0px 0px 0px 8px rgba(${t.vars.palette[e].mainChannel} / 0.16)`,
                          }
                        : {
                            boxShadow: `0px 0px 0px 8px ${(0, kh.Fq)(
                              t.palette[e].main,
                              0.16
                            )}`,
                          }),
                      "@media (hover: none)": { boxShadow: "none" },
                    },
                    [`&.${sc.active}`]: {
                      ...(t.vars
                        ? {
                            boxShadow: `0px 0px 0px 14px rgba(${t.vars.palette[e].mainChannel} / 0.16)`,
                          }
                        : {
                            boxShadow: `0px 0px 0px 14px ${(0, kh.Fq)(
                              t.palette[e].main,
                              0.16
                            )}`,
                          }),
                    },
                  },
                })),
            ],
          }))
        ),
        cc = (0, ph.ZP)(
          function (t) {
            const { children: e, className: i, value: r } = t,
              o = ((t) => {
                const { open: e } = t;
                return {
                  offset: (0, gh.Z)(e && sc.valueLabelOpen),
                  circle: sc.valueLabelCircle,
                  label: sc.valueLabelLabel,
                };
              })(t);
            return e
              ? s.cloneElement(
                  e,
                  { className: (0, gh.Z)(e.props.className) },
                  (0, n.jsxs)(s.Fragment, {
                    children: [
                      e.props.children,
                      (0, n.jsx)("span", {
                        className: (0, gh.Z)(o.offset, i),
                        "aria-hidden": !0,
                        children: (0, n.jsx)("span", {
                          className: o.circle,
                          children: (0, n.jsx)("span", {
                            className: o.label,
                            children: r,
                          }),
                        }),
                      }),
                    ],
                  })
                )
              : null;
          },
          {
            name: "MuiSlider",
            slot: "ValueLabel",
            overridesResolver: (t, e) => e.valueLabel,
          }
        )(
          (0, Jh.Z)(({ theme: t }) => ({
            zIndex: 1,
            whiteSpace: "nowrap",
            ...t.typography.body2,
            fontWeight: 500,
            transition: t.transitions.create(["transform"], {
              duration: t.transitions.duration.shortest,
            }),
            position: "absolute",
            backgroundColor: (t.vars || t).palette.grey[600],
            borderRadius: 2,
            color: (t.vars || t).palette.common.white,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "0.25rem 0.75rem",
            variants: [
              {
                props: { orientation: "horizontal" },
                style: {
                  transform: "translateY(-100%) scale(0)",
                  top: "-10px",
                  transformOrigin: "bottom center",
                  "&::before": {
                    position: "absolute",
                    content: '""',
                    width: 8,
                    height: 8,
                    transform: "translate(-50%, 50%) rotate(45deg)",
                    backgroundColor: "inherit",
                    bottom: 0,
                    left: "50%",
                  },
                  [`&.${sc.valueLabelOpen}`]: {
                    transform: "translateY(-100%) scale(1)",
                  },
                },
              },
              {
                props: { orientation: "vertical" },
                style: {
                  transform: "translateY(-50%) scale(0)",
                  right: "30px",
                  top: "50%",
                  transformOrigin: "right center",
                  "&::before": {
                    position: "absolute",
                    content: '""',
                    width: 8,
                    height: 8,
                    transform: "translate(-50%, -50%) rotate(45deg)",
                    backgroundColor: "inherit",
                    right: -8,
                    top: "50%",
                  },
                  [`&.${sc.valueLabelOpen}`]: {
                    transform: "translateY(-50%) scale(1)",
                  },
                },
              },
              {
                props: { size: "small" },
                style: {
                  fontSize: t.typography.pxToRem(12),
                  padding: "0.25rem 0.5rem",
                },
              },
              {
                props: { orientation: "vertical", size: "small" },
                style: { right: "20px" },
              },
            ],
          }))
        ),
        uc = (0, ph.ZP)("span", {
          name: "MuiSlider",
          slot: "Mark",
          shouldForwardProp: (t) => (0, Qh.Z)(t) && "markActive" !== t,
          overridesResolver: (t, e) => {
            const { markActive: i } = t;
            return [e.mark, i && e.markActive];
          },
        })(
          (0, Jh.Z)(({ theme: t }) => ({
            position: "absolute",
            width: 2,
            height: 2,
            borderRadius: 1,
            backgroundColor: "currentColor",
            variants: [
              {
                props: { orientation: "horizontal" },
                style: { top: "50%", transform: "translate(-1px, -50%)" },
              },
              {
                props: { orientation: "vertical" },
                style: { left: "50%", transform: "translate(-50%, 1px)" },
              },
              {
                props: { markActive: !0 },
                style: {
                  backgroundColor: (t.vars || t).palette.background.paper,
                  opacity: 0.8,
                },
              },
            ],
          }))
        ),
        dc = (0, ph.ZP)("span", {
          name: "MuiSlider",
          slot: "MarkLabel",
          shouldForwardProp: (t) => (0, Qh.Z)(t) && "markLabelActive" !== t,
          overridesResolver: (t, e) => e.markLabel,
        })(
          (0, Jh.Z)(({ theme: t }) => ({
            ...t.typography.body2,
            color: (t.vars || t).palette.text.secondary,
            position: "absolute",
            whiteSpace: "nowrap",
            variants: [
              {
                props: { orientation: "horizontal" },
                style: {
                  top: 30,
                  transform: "translateX(-50%)",
                  "@media (pointer: coarse)": { top: 40 },
                },
              },
              {
                props: { orientation: "vertical" },
                style: {
                  left: 36,
                  transform: "translateY(50%)",
                  "@media (pointer: coarse)": { left: 44 },
                },
              },
              {
                props: { markLabelActive: !0 },
                style: { color: (t.vars || t).palette.text.primary },
              },
            ],
          }))
        ),
        gc = ({ children: t }) => t,
        fc = s.forwardRef(function (t, e) {
          const i = (0, mh.i)({ props: t, name: "MuiSlider" }),
            r = (0, Mh.V)(),
            {
              "aria-label": o,
              "aria-valuetext": a,
              "aria-labelledby": l,
              component: h = "span",
              components: c = {},
              componentsProps: u = {},
              color: d = "primary",
              classes: g,
              className: f,
              disableSwap: p = !1,
              disabled: m = !1,
              getAriaLabel: _,
              getAriaValueText: y,
              marks: x = !1,
              max: v = 100,
              min: w = 0,
              name: S,
              onChange: C,
              onChangeCommitted: b,
              orientation: k = "horizontal",
              shiftStep: M = 10,
              size: I = "medium",
              step: E = 1,
              scale: R = rc,
              slotProps: P,
              slots: F,
              tabIndex: L,
              track: T = "normal",
              value: D,
              valueLabelDisplay: A = "off",
              valueLabelFormat: O = rc,
              ...j
            } = i,
            G = {
              ...i,
              isRtl: r,
              max: v,
              min: w,
              classes: g,
              disabled: m,
              disableSwap: p,
              orientation: k,
              marks: x,
              color: d,
              size: I,
              step: E,
              shiftStep: M,
              scale: R,
              track: T,
              valueLabelDisplay: A,
              valueLabelFormat: O,
            },
            {
              axisProps: Z,
              getRootProps: z,
              getHiddenInputProps: B,
              getThumbProps: N,
              open: W,
              active: X,
              axis: Y,
              focusedThumbIndex: V,
              range: q,
              dragging: $,
              marks: U,
              values: H,
              trackOffset: K,
              trackLeap: J,
              getThumbStyle: Q,
            } = Hh({ ...G, rootRef: e });
          (G.marked = U.length > 0 && U.some((t) => t.label)),
            (G.dragging = $),
            (G.focusedThumbIndex = V);
          const tt = ((t) => {
              const {
                  disabled: e,
                  dragging: i,
                  marked: n,
                  orientation: s,
                  track: r,
                  classes: o,
                  color: a,
                  size: l,
                } = t,
                h = {
                  root: [
                    "root",
                    e && "disabled",
                    i && "dragging",
                    n && "marked",
                    "vertical" === s && "vertical",
                    "inverted" === r && "trackInverted",
                    !1 === r && "trackFalse",
                    a && `color${(0, ec.Z)(a)}`,
                    l && `size${(0, ec.Z)(l)}`,
                  ],
                  rail: ["rail"],
                  track: ["track"],
                  mark: ["mark"],
                  markActive: ["markActive"],
                  markLabel: ["markLabel"],
                  markLabelActive: ["markLabelActive"],
                  valueLabel: ["valueLabel"],
                  thumb: [
                    "thumb",
                    e && "disabled",
                    l && `thumbSize${(0, ec.Z)(l)}`,
                    a && `thumbColor${(0, ec.Z)(a)}`,
                  ],
                  active: ["active"],
                  disabled: ["disabled"],
                  focusVisible: ["focusVisible"],
                };
              return (0, fh.Z)(h, nc, o);
            })(G),
            et = F?.root ?? c.Root ?? oc,
            it = F?.rail ?? c.Rail ?? ac,
            nt = F?.track ?? c.Track ?? lc,
            st = F?.thumb ?? c.Thumb ?? hc,
            rt = F?.valueLabel ?? c.ValueLabel ?? cc,
            ot = F?.mark ?? c.Mark ?? uc,
            at = F?.markLabel ?? c.MarkLabel ?? dc,
            lt = F?.input ?? c.Input ?? "input",
            ht = P?.root ?? u.root,
            ct = P?.rail ?? u.rail,
            ut = P?.track ?? u.track,
            dt = P?.thumb ?? u.thumb,
            gt = P?.valueLabel ?? u.valueLabel,
            ft = P?.mark ?? u.mark,
            pt = P?.markLabel ?? u.markLabel,
            mt = P?.input ?? u.input,
            _t = (0, Ih.Z)({
              elementType: et,
              getSlotProps: z,
              externalSlotProps: ht,
              externalForwardedProps: j,
              additionalProps: { ...(tc(et) && { as: h }) },
              ownerState: { ...G, ...ht?.ownerState },
              className: [tt.root, f],
            }),
            yt = (0, Ih.Z)({
              elementType: it,
              externalSlotProps: ct,
              ownerState: G,
              className: tt.rail,
            }),
            xt = (0, Ih.Z)({
              elementType: nt,
              externalSlotProps: ut,
              additionalProps: {
                style: { ...Z[Y].offset(K), ...Z[Y].leap(J) },
              },
              ownerState: { ...G, ...ut?.ownerState },
              className: tt.track,
            }),
            vt = (0, Ih.Z)({
              elementType: st,
              getSlotProps: N,
              externalSlotProps: dt,
              ownerState: { ...G, ...dt?.ownerState },
              className: tt.thumb,
            }),
            wt = (0, Ih.Z)({
              elementType: rt,
              externalSlotProps: gt,
              ownerState: { ...G, ...gt?.ownerState },
              className: tt.valueLabel,
            }),
            St = (0, Ih.Z)({
              elementType: ot,
              externalSlotProps: ft,
              ownerState: G,
              className: tt.mark,
            }),
            Ct = (0, Ih.Z)({
              elementType: at,
              externalSlotProps: pt,
              ownerState: G,
              className: tt.markLabel,
            }),
            bt = (0, Ih.Z)({
              elementType: lt,
              getSlotProps: B,
              externalSlotProps: mt,
              ownerState: G,
            });
          return (0, n.jsxs)(et, {
            ..._t,
            children: [
              (0, n.jsx)(it, { ...yt }),
              (0, n.jsx)(nt, { ...xt }),
              U.filter((t) => t.value >= w && t.value <= v).map((t, e) => {
                const i = Bh(t.value, w, v),
                  r = Z[Y].offset(i);
                let o;
                return (
                  (o =
                    !1 === T
                      ? H.includes(t.value)
                      : ("normal" === T &&
                          (q
                            ? t.value >= H[0] && t.value <= H[H.length - 1]
                            : t.value <= H[0])) ||
                        ("inverted" === T &&
                          (q
                            ? t.value <= H[0] || t.value >= H[H.length - 1]
                            : t.value >= H[0]))),
                  (0, n.jsxs)(
                    s.Fragment,
                    {
                      children: [
                        (0, n.jsx)(ot, {
                          "data-index": e,
                          ...St,
                          ...(!(0, Kh.Z)(ot) && { markActive: o }),
                          style: { ...r, ...St.style },
                          className: (0, gh.Z)(
                            St.className,
                            o && tt.markActive
                          ),
                        }),
                        null != t.label
                          ? (0, n.jsx)(at, {
                              "aria-hidden": !0,
                              "data-index": e,
                              ...Ct,
                              ...(!(0, Kh.Z)(at) && { markLabelActive: o }),
                              style: { ...r, ...Ct.style },
                              className: (0, gh.Z)(
                                tt.markLabel,
                                Ct.className,
                                o && tt.markLabelActive
                              ),
                              children: t.label,
                            })
                          : null,
                      ],
                    },
                    e
                  )
                );
              }),
              H.map((t, e) => {
                const i = Bh(t, w, v),
                  s = Z[Y].offset(i),
                  r = "off" === A ? gc : rt;
                return (0, n.jsx)(
                  r,
                  {
                    ...(!(0, Kh.Z)(r) && {
                      valueLabelFormat: O,
                      valueLabelDisplay: A,
                      value: "function" === typeof O ? O(R(t), e) : O,
                      index: e,
                      open: W === e || X === e || "on" === A,
                      disabled: m,
                    }),
                    ...wt,
                    children: (0, n.jsx)(st, {
                      "data-index": e,
                      ...vt,
                      className: (0, gh.Z)(
                        tt.thumb,
                        vt.className,
                        X === e && tt.active,
                        V === e && tt.focusVisible
                      ),
                      style: { ...s, ...Q(e), ...vt.style },
                      children: (0, n.jsx)(lt, {
                        "data-index": e,
                        "aria-label": _ ? _(e) : o,
                        "aria-valuenow": R(t),
                        "aria-labelledby": l,
                        "aria-valuetext": y ? y(R(t), e) : a,
                        value: H[e],
                        ...bt,
                      }),
                    }),
                  },
                  e
                );
              }),
            ],
          });
        }),
        pc = fc,
        mc = ({ iconPosition: t, onToggleLayer: e, onOpacityChange: i }) => {
          const [r, o] = (0, s.useState)(!0),
            [a, l] = (0, s.useState)(!1),
            [h, c] = (0, s.useState)(!1),
            [u, d] = (0, s.useState)(50),
            [g, f] = (0, s.useState)(50),
            [p, m] = (0, s.useState)(50),
            _ = (t) => {
              switch (t) {
                case "osm":
                  o(!r), e("osm", !r);
                  break;
                case "road":
                  l(!a), e("road", !a);
                  break;
                case "arial":
                  c(!h), e("arial", !h);
              }
            },
            y = (t, e) => {
              switch (t) {
                case "osm":
                  d(e), i("osm", e);
                  break;
                case "road":
                  f(e), i("road", e);
                  break;
                case "arial":
                  m(e), i("arial", e);
              }
            },
            x = {
              position: "absolute",
              top: t.top + 10,
              left: 80,
              zIndex: 1e3,
              backgroundColor: "#fff",
              borderRadius: "8px",
              boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
              padding: "16px",
              display: "flex",
              flexDirection: "row",
              gap: "16px",
            };
          return n.jsx(kn.Z, {
            style: x,
            children: (0, n.jsxs)(kn.Z, {
              style: {
                width: "100%",
                display: "flex",
                flexDirection: "row",
                gap: "12px",
              },
              children: [
                (0, n.jsxs)(kn.Z, {
                  display: "flex",
                  flexDirection: "column",
                  sx: { width: "100%" },
                  children: [
                    (0, n.jsxs)(kn.Z, {
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "space-between",
                      alignItems: "center",
                      children: [
                        n.jsx(In.Z, {
                          variant: "body1",
                          style: { fontSize: "12px" },
                          children: "OSM",
                        }),
                        n.jsx(dh.Z, {
                          checked: r,
                          onChange: () => _("osm"),
                          color: "primary",
                        }),
                      ],
                    }),
                    n.jsx(bh, {
                      component: "img",
                      height: "80",
                      image: "/osm.png",
                      alt: "OSM",
                      style: { objectFit: "fill" },
                    }),
                    n.jsx(pc, {
                      value: u,
                      onChange: (t, e) => y("osm", Number(e)),
                      "aria-labelledby": "osm-opacity-slider",
                      style: { marginTop: "8px" },
                      sx: {
                        marginTop: "8px",
                        height: 4,
                        "& .MuiSlider-thumb": { height: 12, width: 12 },
                      },
                    }),
                  ],
                }),
                n.jsx(qn.Z, { flexItem: !0 }),
                (0, n.jsxs)(kn.Z, {
                  display: "flex",
                  flexDirection: "column",
                  sx: { width: "100%" },
                  children: [
                    (0, n.jsxs)(kn.Z, {
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "space-between",
                      alignItems: "center",
                      children: [
                        n.jsx(In.Z, {
                          variant: "body1",
                          style: { fontSize: "12px" },
                          children: "Road",
                        }),
                        n.jsx(dh.Z, {
                          checked: a,
                          onChange: () => _("road"),
                          color: "primary",
                        }),
                      ],
                    }),
                    n.jsx(bh, {
                      component: "img",
                      height: "80",
                      image: "/road.png",
                      alt: "Road",
                      style: { objectFit: "fill" },
                    }),
                    n.jsx(pc, {
                      value: g,
                      onChange: (t, e) => y("road", Number(e)),
                      "aria-labelledby": "road-opacity-slider",
                      style: { marginTop: "8px" },
                    }),
                  ],
                }),
                n.jsx(qn.Z, { flexItem: !0 }),
                (0, n.jsxs)(kn.Z, {
                  display: "flex",
                  flexDirection: "column",
                  sx: { width: "100%" },
                  children: [
                    (0, n.jsxs)(kn.Z, {
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "space-between",
                      alignItems: "center",
                      children: [
                        n.jsx(In.Z, {
                          variant: "body1",
                          style: { fontSize: "12px" },
                          children: "Arial Maps",
                        }),
                        n.jsx(dh.Z, {
                          checked: h,
                          onChange: () => _("arial"),
                          color: "primary",
                        }),
                      ],
                    }),
                    n.jsx(bh, {
                      component: "img",
                      height: "80",
                      image: "/aerial.png",
                      alt: "Aerial Maps",
                      style: { objectFit: "fill" },
                    }),
                    n.jsx(pc, {
                      value: p,
                      onChange: (t, e) => y("arial", Number(e)),
                      "aria-labelledby": "arial-opacity-slider",
                      style: { marginTop: "8px" },
                    }),
                  ],
                }),
              ],
            }),
          });
        };
      var _c = i(57329),
        yc = i(56009);
      const xc = (0, bi.Z)(
          (0, n.jsx)("path", {
            d: "M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14",
          }),
          "Search"
        ),
        vc = (0, bi.Z)(
          (0, n.jsx)("path", {
            d: "M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7m0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5",
          }),
          "LocationOn"
        ),
        wc = (0, bi.Z)(
          (0, n.jsx)("path", { d: "M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z" }),
          "Home"
        ),
        Sc = (0, bi.Z)(
          (0, n.jsx)("path", {
            d: "m20.5 3-.16.03L15 5.1 9 3 3.36 4.9c-.21.07-.36.25-.36.48V20.5c0 .28.22.5.5.5l.16-.03L9 18.9l6 2.1 5.64-1.9c.21-.07.36-.25.36-.48V3.5c0-.28-.22-.5-.5-.5M15 19l-6-2.11V5l6 2.11z",
          }),
          "Map"
        ),
        Cc = (0, bi.Z)(
          (0, n.jsx)("path", { d: "M14.4 6 14 4H5v17h2v-7h5.6l.4 2h7V6z" }),
          "Flag"
        ),
        bc = (0, bi.Z)(
          (0, n.jsx)("path", {
            d: "M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7m0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5",
          }),
          "Place"
        ),
        kc = (0, bi.Z)(
          (0, n.jsx)("path", {
            d: "M18 8c0-3.31-2.69-6-6-6S6 4.69 6 8c0 4.5 6 11 6 11s6-6.5 6-11m-8 0c0-1.1.9-2 2-2s2 .9 2 2-.89 2-2 2c-1.1 0-2-.9-2-2M5 20v2h14v-2z",
          }),
          "PinDrop"
        ),
        Mc = (0, bi.Z)(
          (0, n.jsx)("path", {
            d: "M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12zm-1 4 6 6v10c0 1.1-.9 2-2 2H7.99C6.89 23 6 22.1 6 21l.01-14c0-1.1.89-2 1.99-2zm-1 7h5.5L14 6.5z",
          }),
          "FileCopy"
        ),
        Ic = ({ icon: t, label: e, value: i }) =>
          (0, n.jsxs)(n.Fragment, {
            children: [
              (0, n.jsxs)(kn.Z, {
                display: "flex",
                alignItems: "center",
                paddingY: 1,
                children: [
                  t &&
                    n.jsx(kn.Z, {
                      marginRight: 2,
                      display: "flex",
                      alignItems: "center",
                      children: t,
                    }),
                  (0, n.jsxs)(kn.Z, {
                    children: [
                      n.jsx(In.Z, {
                        variant: "caption",
                        color: "textSecondary",
                        children: e,
                      }),
                      n.jsx(In.Z, {
                        variant: "body1",
                        color: "primary",
                        children: i,
                      }),
                    ],
                  }),
                ],
              }),
              n.jsx(qn.Z, {}),
            ],
          });
      var Ec = i(73926);
      const Rc = ({
        feature: t,
        coordinates: e,
        geocode: i,
        options: r,
        isLoading: o,
        onSearchGeoCodeClick: a,
      }) => {
        const l = o ? "..." : "Unknown Street",
          h = o ? "..." : t?.pr_name || "Unknown Region",
          c = o ? "..." : t?.pc_name || "Unknown District",
          u = o ? "..." : t?.pc_name || "Unknown Community",
          d = o ? "..." : t?.pr_name || "Unknown Postal Area",
          g = o ? "..." : t?.pc_code || "000000",
          [f, p] = (0, s.useState)(!1),
          m = (t, e) => {
            "clickaway" !== e && p(!1);
          },
          _ = (t) =>
            "object" === typeof t && null !== t && "id" in t && "libelle" in t;
        return (0, n.jsxs)(kn.Z, {
          padding: 2,
          bgcolor: "#f5f5f5",
          borderRadius: 2,
          children: [
            n.jsx(kn.Z, {
              marginBottom: 2,
              children: n.jsx(oh.Z, {
                freeSolo: !0,
                getOptionKey: (t) =>
                  _(t)
                    ? t.id && t.key
                      ? `${t.id}-${t.key}`
                      : `geoFeature-${Math.random()}`
                    : t
                    ? `nonGeo-${t}`
                    : `nonGeo-unknown-${Math.random()}`,
                options: r,
                onChange: async (t, e) => {
                  e && _(e) && a(e);
                },
                getOptionLabel: (t) => (_(t) ? t.libelle || "Unknown" : t),
                renderInput: (t) =>
                  n.jsx(ah.Z, {
                    ...t,
                    fullWidth: !0,
                    variant: "outlined",
                    placeholder: "Search Address, Places, Coordinates",
                    InputProps: {
                      ...t.InputProps,
                      endAdornment: n.jsx(_c.Z, {
                        position: "end",
                        children: n.jsx(xc, { sx: { color: "white" } }),
                      }),
                    },
                  }),
              }),
            }),
            o &&
              (0, n.jsxs)(kn.Z, {
                sx: {
                  textAlign: "center",
                  display: "flex",
                  flexDirection: "row",
                  alignItems: "center",
                  alignSelf: "center",
                  justifyContent: "center",
                },
                children: [
                  n.jsx(En.Z, {
                    size: 24,
                    sx: { color: $n.Z.palette.primary.main },
                  }),
                  n.jsx(In.Z, {
                    variant: "body1",
                    sx: { ml: 1, color: $n.Z.palette.primary.main },
                    children: "Loading...",
                  }),
                ],
              }),
            n.jsx(In.Z, {
              variant: "caption",
              color: "textSecondary",
              marginBottom: 1,
              marginTop: o ? 4 : 0,
              children: "Geocode",
            }),
            (0, n.jsxs)(kn.Z, {
              padding: 2,
              borderRadius: 2,
              bgcolor: "#e3f2fd",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: 2,
              children: [
                (0, n.jsxs)(kn.Z, {
                  display: "flex",
                  alignItems: "center",
                  children: [
                    n.jsx(vc, { color: "primary" }),
                    n.jsx(In.Z, {
                      variant: "h6",
                      color: "primary",
                      marginLeft: 1,
                      children: o ? "..." : 0 === i.length ? "Unknown" : i,
                    }),
                  ],
                }),
                i &&
                  !o &&
                  i.length > 5 &&
                  n.jsx(Mn.Z, {
                    onClick: () => {
                      navigator.clipboard
                        .writeText(i)
                        .then(() => {
                          p(!0);
                        })
                        .catch((t) => {
                          console.error("Could not copy text: ", t);
                        });
                    },
                    size: "small",
                    children: n.jsx(Mc, { color: "primary" }),
                  }),
                n.jsx(yc.Z, {
                  open: f,
                  autoHideDuration: 3e3,
                  onClose: m,
                  message: "Geocode copied to clipboard!",
                  anchorOrigin: { vertical: "top", horizontal: "center" },
                }),
              ],
            }),
            n.jsx(In.Z, {
              variant: "caption",
              color: "textSecondary",
              marginBottom: 1,
              children: "Address Info",
            }),
            n.jsx(Ic, {
              icon: n.jsx(wc, { color: "primary" }),
              label: "Street Name",
              value: l,
            }),
            n.jsx(Ic, {
              icon: n.jsx(Ec.Z, { icon: "mdi:code-tags", fontSize: 20 }),
              label: "Region",
              value: h,
            }),
            n.jsx(Ic, {
              icon: n.jsx(Sc, { color: "primary" }),
              label: "District",
              value: c,
            }),
            n.jsx(Ic, {
              icon: n.jsx(Cc, { color: "primary" }),
              label: "Community",
              value: u,
            }),
            n.jsx(Ic, {
              icon: n.jsx(bc, { color: "primary" }),
              label: "Postal Area",
              value: d,
            }),
            n.jsx(Ic, {
              icon: n.jsx(kc, { color: "primary" }),
              label: "Post Code",
              value: g,
            }),
            n.jsx(Ic, {
              icon: n.jsx(vc, { color: "primary" }),
              label: "Latitude, Longitude",
              value: `${e[0].toFixed(6)}, ${e[1].toFixed(6)}`,
            }),
            n.jsx(yc.Z, {
              open: f,
              autoHideDuration: 3e3,
              onClose: m,
              message: "Geocode copied to clipboard!",
              anchorOrigin: { vertical: "top", horizontal: "center" },
            }),
          ],
        });
      };
      function Pc(t) {
        return (0, yh.ZP)("MuiAppBar", t);
      }
      (0, _h.Z)("MuiAppBar", [
        "root",
        "positionFixed",
        "positionAbsolute",
        "positionSticky",
        "positionStatic",
        "positionRelative",
        "colorDefault",
        "colorPrimary",
        "colorSecondary",
        "colorInherit",
        "colorTransparent",
        "colorError",
        "colorInfo",
        "colorSuccess",
        "colorWarning",
      ]);
      const Fc = (t, e) => (t ? `${t?.replace(")", "")}, ${e})` : e),
        Lc = (0, ph.ZP)(Ll.Z, {
          name: "MuiAppBar",
          slot: "Root",
          overridesResolver: (t, e) => {
            const { ownerState: i } = t;
            return [
              e.root,
              e[`position${(0, ec.Z)(i.position)}`],
              e[`color${(0, ec.Z)(i.color)}`],
            ];
          },
        })(
          (0, Jh.Z)(({ theme: t }) => ({
            display: "flex",
            flexDirection: "column",
            width: "100%",
            boxSizing: "border-box",
            flexShrink: 0,
            variants: [
              {
                props: { position: "fixed" },
                style: {
                  position: "fixed",
                  zIndex: (t.vars || t).zIndex.appBar,
                  top: 0,
                  left: "auto",
                  right: 0,
                  "@media print": { position: "absolute" },
                },
              },
              {
                props: { position: "absolute" },
                style: {
                  position: "absolute",
                  zIndex: (t.vars || t).zIndex.appBar,
                  top: 0,
                  left: "auto",
                  right: 0,
                },
              },
              {
                props: { position: "sticky" },
                style: {
                  position: "sticky",
                  zIndex: (t.vars || t).zIndex.appBar,
                  top: 0,
                  left: "auto",
                  right: 0,
                },
              },
              { props: { position: "static" }, style: { position: "static" } },
              {
                props: { position: "relative" },
                style: { position: "relative" },
              },
              {
                props: { color: "inherit" },
                style: { "--AppBar-color": "inherit" },
              },
              {
                props: { color: "default" },
                style: {
                  "--AppBar-background": t.vars
                    ? t.vars.palette.AppBar.defaultBg
                    : t.palette.grey[100],
                  "--AppBar-color": t.vars
                    ? t.vars.palette.text.primary
                    : t.palette.getContrastText(t.palette.grey[100]),
                  ...t.applyStyles("dark", {
                    "--AppBar-background": t.vars
                      ? t.vars.palette.AppBar.defaultBg
                      : t.palette.grey[900],
                    "--AppBar-color": t.vars
                      ? t.vars.palette.text.primary
                      : t.palette.getContrastText(t.palette.grey[900]),
                  }),
                },
              },
              ...Object.entries(t.palette)
                .filter((0, ic.Z)(["contrastText"]))
                .map(([e]) => ({
                  props: { color: e },
                  style: {
                    "--AppBar-background": (t.vars ?? t).palette[e].main,
                    "--AppBar-color": (t.vars ?? t).palette[e].contrastText,
                  },
                })),
              {
                props: (t) =>
                  !0 === t.enableColorOnDark &&
                  !["inherit", "transparent"].includes(t.color),
                style: {
                  backgroundColor: "var(--AppBar-background)",
                  color: "var(--AppBar-color)",
                },
              },
              {
                props: (t) =>
                  !1 === t.enableColorOnDark &&
                  !["inherit", "transparent"].includes(t.color),
                style: {
                  backgroundColor: "var(--AppBar-background)",
                  color: "var(--AppBar-color)",
                  ...t.applyStyles("dark", {
                    backgroundColor: t.vars
                      ? Fc(
                          t.vars.palette.AppBar.darkBg,
                          "var(--AppBar-background)"
                        )
                      : null,
                    color: t.vars
                      ? Fc(
                          t.vars.palette.AppBar.darkColor,
                          "var(--AppBar-color)"
                        )
                      : null,
                  }),
                },
              },
              {
                props: { color: "transparent" },
                style: {
                  "--AppBar-background": "transparent",
                  "--AppBar-color": "inherit",
                  backgroundColor: "var(--AppBar-background)",
                  color: "var(--AppBar-color)",
                  ...t.applyStyles("dark", { backgroundImage: "none" }),
                },
              },
            ],
          }))
        ),
        Tc = s.forwardRef(function (t, e) {
          const i = (0, mh.i)({ props: t, name: "MuiAppBar" }),
            {
              className: s,
              color: r = "primary",
              enableColorOnDark: o = !1,
              position: a = "fixed",
              ...l
            } = i,
            h = { ...i, color: r, position: a, enableColorOnDark: o },
            c = ((t) => {
              const { color: e, position: i, classes: n } = t,
                s = {
                  root: [
                    "root",
                    `color${(0, ec.Z)(e)}`,
                    `position${(0, ec.Z)(i)}`,
                  ],
                };
              return (0, fh.Z)(s, Pc, n);
            })(h);
          return (0,
          n.jsx)(Lc, { square: !0, component: "header", ownerState: h, elevation: 4, className: (0, gh.Z)(c.root, s, "fixed" === a && "mui-fixed"), ref: e, ...l });
        });
      var Dc = i(87841),
        Ac = i(16111),
        Oc = i(37841);
      const jc = (0, bi.Z)(
        (0, n.jsx)("path", {
          d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 4c1.93 0 3.5 1.57 3.5 3.5S13.93 13 12 13s-3.5-1.57-3.5-3.5S10.07 6 12 6m0 14c-2.03 0-4.43-.82-6.14-2.88C7.55 15.8 9.68 15 12 15s4.45.8 6.14 2.12C16.43 19.18 14.03 20 12 20",
        }),
        "AccountCircle"
      );
      var Gc = i(35047),
        Zc = i(44099);
      const zc = () => {
          const [t, e] = (0, s.useState)(null),
            [i, r] = (0, s.useState)(null),
            o = (0, Gc.useRouter)();
          (0, s.useEffect)(() => {
            const t = localStorage.getItem("user");
            t && r(JSON.parse(t));
          }, []);
          const a = () => {
              e(null);
            },
            l = Boolean(t);
          return (0, n.jsxs)(n.Fragment, {
            children: [
              n.jsx(Mn.Z, {
                color: "inherit",
                "aria-label": "account",
                onClick: (t) => {
                  e(t.currentTarget);
                },
                children: n.jsx(jc, { fontSize: "large" }),
              }),
              (0, n.jsxs)(Ac.Z, {
                anchorEl: t,
                open: l,
                onClose: a,
                PaperProps: { sx: { width: "200px" } },
                children: [
                  i
                    ? (0, n.jsxs)("div", {
                        children: [
                          n.jsx(Oc.Z, {
                            onClick: a,
                            children: n.jsx(In.Z, {
                              variant: "body1",
                              children: i.email,
                            }),
                          }),
                          n.jsx(Oc.Z, {
                            onClick: a,
                            children: (0, n.jsxs)(In.Z, {
                              variant: "body2",
                              children: ["Role: ", i.role],
                            }),
                          }),
                          n.jsx(qn.Z, {}),
                          "admin" === i.role &&
                            n.jsx(Oc.Z, {
                              onClick: () => {
                                window.open("/admin", "_blank"), a();
                              },
                              children: "Admin Panel",
                            }),
                          n.jsx(qn.Z, {}),
                        ],
                      })
                    : n.jsx(Oc.Z, {
                        children: n.jsx(In.Z, {
                          variant: "body2",
                          children: "Loading...",
                        }),
                      }),
                  n.jsx(Oc.Z, {
                    onClick: async () => {
                      try {
                        const t = await Zc.Z.post(
                          "/api/auth/logout",
                          {},
                          { withCredentials: !0 }
                        );
                        console.log("Logout response:", t),
                          200 === t.status
                            ? (console.log("Logout successful"),
                              localStorage.removeItem("token"),
                              localStorage.removeItem("user"),
                              o.push("/"))
                            : console.error("Logout failed", t.data);
                      } catch (t) {
                        console.error("Error during logout:", t);
                      }
                    },
                    children: "Logout",
                  }),
                ],
              }),
            ],
          });
        },
        Bc = (0, bi.Z)(
          (0, n.jsx)("path", { d: "M3 18h18v-2H3zm0-5h18v-2H3zm0-7v2h18V6z" }),
          "Menu"
        ),
        Nc = ({ toggleDrawer: t, isForAdminPanel: e }) =>
          n.jsx(Tc, {
            position: "static",
            children: (0, n.jsxs)(Dc.Z, {
              children: [
                n.jsx(Mn.Z, {
                  edge: "start",
                  color: "inherit",
                  "aria-label": "menu",
                  sx: { mr: 2 },
                  children: n.jsx("img", {
                    src: "/app_logo.png",
                    alt: "app_logo",
                    height: 30,
                  }),
                }),
                n.jsx(kn.Z, { sx: { flexGrow: 1 } }),
                0 == e &&
                  (0, n.jsxs)(n.Fragment, {
                    children: [
                      n.jsx(zc, {}),
                      (0, n.jsxs)(Mn.Z, {
                        color: "inherit",
                        "aria-label": "menu",
                        onClick: () => {
                          t(!0);
                        },
                        children: [n.jsx(Bc, { fontSize: "large" }), " "],
                      }),
                    ],
                  }),
              ],
            }),
          });
      var Wc = i(31870);
      i(5551);
      function Xc() {
        const [t, e] = (0, s.useState)(0),
          [i, r] = (0, s.useState)(!1),
          [o, a] = (0, s.useState)(null),
          [l, h] = (0, s.useState)([]),
          [c, u] = (0, s.useState)(),
          [d, g] =
            ((0, s.useRef)(null), (0, s.useRef)(null), (0, s.useState)([])),
          [f, p] = ((0, Gc.useSearchParams)(), (0, s.useState)(!1)),
          [m, _] = (0, s.useState)(!1),
          [y, x] = (0, s.useState)(!1),
          [v, w] = (0, s.useState)(!0),
          [S, C] = (0, s.useState)(null),
          [b, k] = ((0, Wc.tm)(), (0, s.useState)(void 0)),
          [M, I] = (0, s.useState)(!1),
          E = (0, s.useRef)(null),
          [R, P] = (0, s.useState)(void 0),
          F = (0, s.useRef)(null),
          [L, T] = (0, s.useState)(void 0),
          D = (0, s.useRef)(null),
          [A, j] = (0, s.useState)(!1),
          [G, Z] = (0, s.useState)(null),
          [z, B] = (0, s.useState)(null),
          [N, W] = (0, s.useState)(null),
          X = (0, s.useRef)([]),
          Y = () => {
            if (y) x(!1);
            else {
              if (E.current) {
                const t = E.current.getBoundingClientRect();
                k(t);
              }
              x(!0), j(!1), _(!1), r(!1);
            }
          },
          V = () => {
            if (A) j(!1);
            else {
              if (D.current) {
                const t = D.current.getBoundingClientRect();
                T(t);
              }
              x(!1), j(!0), _(!1);
            }
          },
          q = () => {
            if (m) _(!1);
            else {
              if (F.current) {
                const t = F.current.getBoundingClientRect();
                P(t);
              }
              _(!0), x(!1), j(!1);
            }
          },
          $ = (0, s.useRef)(new Ci({ format: new bn(), strategy: xi })),
          U = (0, s.useRef)(new Ci({ format: new bn(), strategy: xi })),
          H = (0, s.useRef)(new Ci({ format: new bn(), strategy: xi }));
        const K = async (t, e = !0) => {
            I(!0);
            const i = ze(t.coordinate, "EPSG:3857", "EPSG:4326");
            C({ feature: null, coordinates: i, geocode: "" });
            const n = i[1],
              s = i[0];
            if (1 == e) {
              const t = new O({
                geometry: new Oi(
                  ((r = [i[0], i[1]]),
                  Fe(),
                  ze(r, "EPSG:4326", void 0 !== o ? o : "EPSG:3857"))
                ),
              });
              null != H.current && (H.current.clear(), H.current.addFeature(t));
            }
            var r, o;
            try {
              const t = await (async (t, e) => {
                try {
                  return (
                    console.log("fetchWFSFeatures lat", t),
                    console.log("fetchWFSFeatures long", e),
                    await (0, Xn.bF)(t, e)
                  );
                } catch (i) {
                  throw (
                    (console.error("Error fetching features:", i),
                    new Error(
                      "Could not fetch geocode features. Please try again later."
                    ))
                  );
                }
              })(n, s);
              I(!1),
                t.length > 0
                  ? t.forEach((t) => {
                      const e = t.properties.tooltip,
                        n = t.properties;
                      let s = i[0] + "",
                        r = i[1] + "";
                      (s = s.substr(4, 3)),
                        (r = r.substr(5, 3)),
                        null != e &&
                          (w(!0),
                          C({
                            feature: n,
                            coordinates: i,
                            geocode: `${e}-${r}${s}`,
                          }));
                    })
                  : console.log("No features found at the clicked location.");
            } catch (a) {
              console.error("Error loading geocode features:", a);
            }
          },
          [J, Q] = (0, s.useState)({}),
          [tt, et] = (0, s.useState)({}),
          it = async (t) => {
            let e = "";
            e = (t.extent && t.extent.length, Xn.vK);
            const i = `maxFeatures=1&featureID=${t.table}.${t.id}`;
            nt(
              {
                layerName: t.table || "",
                idLayer: t.id.toString(),
                wfsUrl:
                  "http://196.13.104.124/tomcat/geoserver/zambia/ows?service=WFS",
                name: t.libelle || "",
              },
              i,
              e
            );
          },
          nt = async (t, e, i) => {
            const n = `http://196.13.104.124/tomcat/geoserver/zambia/ows?service=WFS&version=1.1.0&request=GetFeature&typename=zambie:${t.layerName}&outputFormat=application/json`;
            console.log("baseUrl", n);
            const s = e.length > 0 ? `${n}&${e}` : n;
            X.current.push(s);
            try {
              if ((rt(), tt[t.idLayer] && $.current && 0 === e.length)) {
                const e = $.current.getFeatures(),
                  i = tt[t.idLayer],
                  n = e.includes(i[0]);
                return (
                  console.log("isVisible", n),
                  n
                    ? ($.current.removeFeatures(tt[t.idLayer]),
                      h((e) => e.filter((e) => e.idLayer !== t.idLayer)),
                      console.log(`Layer ${t.idLayer} hidden.`))
                    : ($.current.addFeatures(tt[t.idLayer]),
                      h((e) => [...e, t]),
                      console.log(`Layer ${t.idLayer} shown.`)),
                  void ot()
                );
              }
              const i = await fetch(s),
                n = await i.json();
              if (
                (console.log("res data", n),
                ot(),
                n && n.features && n.features.length > 0)
              ) {
                if (!$.current)
                  return void console.error("Map is not initialized.");
                const i = new bn().readFeatures(n, {
                  featureProjection: "EPSG:3857",
                });
                if (
                  (i.forEach((e) => {
                    e.set("layerId", t.idLayer);
                  }),
                  tt[t.idLayer] && $.current && 0 === e.length)
                )
                  return void console.log("Layer already loaded.");
                if (
                  (console.log("Layer loaded", t.idLayer),
                  $.current.addFeatures(i),
                  e.length > 0)
                ) {
                  const t = [1 / 0, 1 / 0, -1 / 0, -1 / 0];
                  i.forEach((e) => {
                    xt(t, e.getGeometry().getExtent());
                  }),
                    c
                      ?.getView()
                      .fit(t, {
                        padding: [50, 50, 50, 50],
                        duration: 1e3,
                        maxZoom: 16,
                      }),
                    e.length > 0 &&
                      setTimeout(() => {
                        ((t) => {
                          const e = c.getPixelFromCoordinate(t);
                          K({ pixel: e, coordinate: t });
                        })(c?.getView().getCenter() ?? [0, 0]);
                      }, 2e3);
                }
                (J[t.idLayer] = t.zoomLevels || []),
                  Q({ ...J }),
                  (tt[t.idLayer] = i),
                  et({ ...tt }),
                  h((e) => [...e, t]);
              } else console.log("No features found.");
            } catch (r) {
              console.error("Error fetching data:", r);
            } finally {
              (X.current = X.current.filter((t) => t !== s)), ot();
            }
          },
          st = () => () => {
            x(!1), j(!1), _(!1), r(!i);
          },
          rt = () => e((t) => t + 1),
          ot = () => e((t) => Math.max(t - 1, 0)),
          at = t > 0;
        return (0, n.jsxs)(n.Fragment, {
          children: [
            n.jsx(Nc, {
              isForAdminPanel: !1,
              toggleDrawer: () => {
                r(!i);
              },
            }),
            R &&
              n.jsx(uh, {
                iconPosition: R,
                open: m,
                onClose: () => {
                  _(!1);
                },
                onSearch: (t, e, i) => {
                  console.log("abscissa", e),
                    console.log("ordinate", i),
                    t && it(t);
                },
                geoCodeFeatures: d.filter((t) => "pc_subareas" === t.table),
              }),
            (0, n.jsxs)(kn.Z, {
              sx: {
                display: "flex",
                flexDirection: "row",
                height: "calc(100vh - 64px)",
              },
              children: [
                (0, n.jsxs)(kn.Z, {
                  sx: { flexGrow: 1, transition: "margin-left 0.3s ease" },
                  children: [
                    n.jsx("div", {
                      id: "map",
                      style: { height: "100%", width: "100%" },
                    }),
                    (0, n.jsxs)(kn.Z, {
                      sx: {
                        position: "absolute",
                        left: 20,
                        top: 100,
                        width: 150,
                        display: "flex",
                        flexDirection: "column",
                      },
                      children: [
                        n.jsx("div", {
                          ref: E,
                          children: n.jsx(sh.default, {
                            src: y ? "/measure_active.png" : "/measure.png",
                            alt: y ? "measure_active" : "measure",
                            width: 64,
                            height: 64,
                            onClick: Y,
                            style: { cursor: "pointer" },
                          }),
                        }),
                        n.jsx("div", {
                          ref: D,
                          children: n.jsx(sh.default, {
                            src: A ? "/layers_active.png" : "/layers.png",
                            alt: A ? "layers_active" : "layers",
                            width: 64,
                            height: 64,
                            style: { cursor: "pointer" },
                            onClick: V,
                          }),
                        }),
                        n.jsx(sh.default, {
                          src: "/legend.png",
                          alt: "Legend",
                          width: 64,
                          height: 64,
                          style: { cursor: "pointer" },
                          onClick: st(),
                        }),
                      ],
                    }),
                    n.jsx(kn.Z, {
                      sx: {
                        position: "absolute",
                        right: { xs: "10px", md: "20%" },
                        top: 100,
                        width: 80,
                        display: "flex",
                        flexDirection: "column",
                      },
                      children: n.jsx("div", {
                        ref: F,
                        children: n.jsx(sh.default, {
                          src: "/icon_ geocode.png",
                          alt: "icon_ geocode",
                          width: 64,
                          height: 64,
                          onClick: q,
                          style: { cursor: "pointer" },
                        }),
                      }),
                    }),
                    b &&
                      c &&
                      n.jsx(rh, {
                        map: c,
                        popupVisible: y,
                        setPopupVisible: x,
                        iconPosition: b,
                        vectorSource: U.current,
                      }),
                    L &&
                      1 == A &&
                      n.jsx(mc, {
                        iconPosition: L,
                        onToggleLayer: (t, e) => {
                          switch (t) {
                            case "osm":
                              G && G.setVisible(e);
                              break;
                            case "road":
                              z && z.setVisible(e);
                              break;
                            case "arial":
                              N && N.setVisible(e);
                          }
                        },
                        onOpacityChange: (t, e) => {
                          const i = e / 100;
                          switch (t) {
                            case "osm":
                              G && G.setOpacity(i);
                              break;
                            case "road":
                              z && z.setOpacity(i);
                              break;
                            case "arial":
                              N && N.setOpacity(i);
                          }
                        },
                      }),
                    at &&
                      (0, n.jsxs)(kn.Z, {
                        sx: {
                          position: "absolute",
                          top: "100px",
                          left: "50%",
                          transform: "translateX(-50%)",
                          zIndex: 1e3,
                          textAlign: "center",
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "center",
                        },
                        children: [
                          n.jsx(En.Z, {
                            size: 24,
                            sx: { color: $n.Z.palette.primary.main },
                          }),
                          n.jsx(In.Z, {
                            variant: "body1",
                            sx: { ml: 1, color: $n.Z.palette.primary.main },
                            children: "Loading...",
                          }),
                        ],
                      }),
                  ],
                }),
                n.jsx(kn.Z, {
                  sx: {
                    width: i ? "20%" : "0",
                    transition: "width 0.3s ease",
                    overflow: "hidden",
                    position: "absolute",
                    height: "100%",
                    minWidth: i ? "250px" : "0",
                    backgroundColor: "white",
                    boxShadow: i ? "2px 0 5px rgba(0, 0, 0, 0.5)" : "none",
                  },
                  children: (0, n.jsxs)(kn.Z, {
                    sx: {
                      position: "absolute",
                      top: 0,
                      left: 0,
                      height: "100%",
                      width: "100%",
                      display: "flex",
                      flexDirection: "column",
                    },
                    children: [
                      (0, n.jsxs)(kn.Z, {
                        sx: {
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                          marginBottom: "5px",
                          backgroundColor: "#f5f5f5",
                          padding: "16px",
                          height: "34px",
                        },
                        children: [
                          n.jsx(In.Z, {
                            variant: "h6",
                            component: "div",
                            color: $n.Z.palette.primary.main,
                            children: "Legend",
                          }),
                          n.jsx(Mn.Z, {
                            edge: "end",
                            color: "inherit",
                            onClick: st(),
                            children: n.jsx(ki, {}),
                          }),
                        ],
                      }),
                      o &&
                        n.jsx(Kn, {
                          thematics: o.thematics,
                          onLayerClick: (t) => {
                            nt(t, "", Xn.vK);
                          },
                          loadedLayers: l,
                        }),
                    ],
                  }),
                }),
                (() => {
                  const t = () => {
                    p(!f);
                  };
                  Nn({
                    onSwipedDown: () => p(!1),
                    preventDefaultTouchmoveEvent: !0,
                    trackMouse: !0,
                  });
                  return (0, n.jsxs)(n.Fragment, {
                    children: [
                      n.jsx(kn.Z, {
                        sx: {
                          position: "fixed",
                          bottom: "20px",
                          right: "20px",
                          zIndex: 1e3,
                          display: { xs: "block", md: "none" },
                        },
                        children: n.jsx(Mn.Z, {
                          onClick: t,
                          sx: {
                            backgroundColor: "#fff",
                            boxShadow: "0px 2px 10px rgba(0, 0, 0, 0.2)",
                          },
                          children: n.jsx(Ec.Z, {
                            icon: "mdi:menu",
                            fontSize: 24,
                          }),
                        }),
                      }),
                      n.jsx(kn.Z, {
                        sx: {
                          position: { xs: "fixed", md: "relative" },
                          bottom: { xs: 0, md: "auto" },
                          right: { xs: 0, md: 0 },
                          height: { xs: f ? "40vh" : "0", md: "100%" },
                          width: { xs: "100%", md: v ? "20%" : "0" },
                          backgroundColor: "#f5f5f5",
                          boxShadow: {
                            xs: f ? "0px -2px 5px rgba(0, 0, 0, 0.5)" : "none",
                            md: v ? "2px -2px 5px rgba(0, 0, 0, 0.5)" : "none",
                          },
                          transition: "height 0.3s ease, width 0.3s ease",
                          overflowY: "auto",
                          zIndex: 999,
                        },
                        children: n.jsx(Rc, {
                          isLoading: M,
                          feature: S ? S.feature : null,
                          coordinates: S ? S.coordinates : [0, 0],
                          geocode: S ? S.geocode : "",
                          options: d,
                          onSearchGeoCodeClick: (e) => {
                            t(), it(e);
                          },
                        }),
                      }),
                    ],
                  });
                })(),
              ],
            }),
          ],
        });
      }
      const Yc = () =>
        (0, n.jsxs)(s.Suspense, {
          fallback: n.jsx(Wn, {}),
          children: [" ", n.jsx(Xc, {})],
        });
    },
    31870: (t, e, i) => {
      "use strict";
      i.d(e, { CG: () => o, TL: () => r, tm: () => a });
      var n = i(25842),
        s = i(17577);
      const r = () => (0, n.I0)(),
        o = n.v9;
      function a() {
        const t = (0, s.useRef)(!0);
        return (0, s.useCallback)(() => t.current, []);
      }
    },
    7132: (t, e, i) => {
      "use strict";
      i.d(e, { Z: () => n });
      const n = (0, i(75669).Z)({
        palette: {
          primary: {
            main: "#31317F",
            light: "#63a4ff",
            dark: "#004ba0",
            contrastText: "#fff",
          },
          secondary: {
            main: "#dc004e",
            light: "#ff616f",
            dark: "#9a0036",
            contrastText: "#fff",
          },
          background: { default: "#f5f5f5" },
          text: { primary: "#000", secondary: "#555" },
        },
        typography: {
          fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
          h1: { fontSize: "2.2rem" },
          h2: { fontSize: "1.8rem" },
        },
      });
    },
    66485: (t, e, i) => {
      "use strict";
      i.r(e), i.d(e, { default: () => n });
      const n = (0, i(54965).createProxy)(
        String.raw`/Users/sunny/Developer/LiveBird-Project/rapidus/rapidus/src/app/map/layout.tsx#default`
      );
    },
    30746: (t, e, i) => {
      "use strict";
      i.r(e), i.d(e, { default: () => n });
      const n = (0, i(54965).createProxy)(
        String.raw`/Users/sunny/Developer/LiveBird-Project/rapidus/rapidus/src/app/map/page.tsx#default`
      );
    },
    73914: () => {},
  };
  var e = require("../../webpack-runtime.js");
  e.C(t);
  var i = e.X(0, [948, 678, 703, 271, 537, 548, 393], () => {
    return (t = 31772), e((e.s = t));
    var t;
  });
  module.exports = i;
})();

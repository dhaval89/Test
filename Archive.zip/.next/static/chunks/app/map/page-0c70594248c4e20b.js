(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [5883],
  {
    68032: function (e, t, n) {
      Promise.resolve().then(n.bind(n, 62710));
    },
    62710: function (e, t, n) {
      "use strict";
      n.r(t),
        n.d(t, {
          default: function () {
            return Be;
          },
        });
      var o = n(57437),
        r = n(2265),
        i = (n(67026), n(88226)),
        a = n(98280),
        l = n(73693),
        s = n(31747),
        c = n(38869),
        d = n(13440),
        u = n(31711),
        g = n(88395),
        x = n(22373),
        p = n(19337),
        h = n(59479),
        f = n(17156),
        m = n(60335),
        y = n(83719),
        Z = n(40468),
        b = n(34366),
        w = n(38660),
        j = n(57206);
      const v = () =>
        (0, o.jsx)("div", {
          style: { textAlign: "center", padding: "20px" },
          children: (0, o.jsx)("h2", { children: "Loading..." }),
        });
      var k = n(72160),
        S = n(70742),
        C = n(11929),
        L = n(54349),
        F = n(14595),
        P = n(21949);
      const I = (e) => {
          let { stroke: t, type: n, lineDash: r, image: i } = e;
          if ("point" === n) {
            const e = "rgba("
                .concat(i.r, ", ")
                .concat(i.g, ", ")
                .concat(i.b, ", 1)"),
              t = i.radius;
            return (0, o.jsx)("svg", {
              width: "20",
              height: "20",
              viewBox: "0 0 20 20",
              children: (0, o.jsx)("circle", {
                cx: "10",
                cy: "10",
                r: t,
                fill: e,
              }),
            });
          }
          if (!t) return null;
          const a = "rgba("
              .concat(t.r, ", ")
              .concat(t.g, ", ")
              .concat(t.b, ", ")
              .concat(t.a, ")"),
            l = {
              fill: "polygon" === n ? a : "none",
              stroke: "polygon" === n ? "rgba(53,53,53,1)" : a,
              strokeWidth: t.width || 2,
              strokeOpacity: t.opacity || 1,
              strokeDasharray: r ? "4,4" : "none",
            };
          switch (n) {
            case "line":
              return (0, o.jsx)("svg", {
                width: "30",
                height: "30",
                viewBox: "0 0 30 30",
                children: (0, o.jsx)("line", {
                  x1: "0",
                  y1: "15",
                  x2: "30",
                  y2: "15",
                  style: l,
                }),
              });
            case "polygon":
              return (0, o.jsx)("svg", {
                width: "25",
                height: "25",
                viewBox: "0 0 30 30",
                children: (0, o.jsx)("rect", {
                  x: "5",
                  y: "5",
                  width: "20",
                  height: "20",
                  style: l,
                }),
              });
            case "dash-square":
              return (0, o.jsx)("svg", {
                width: "30",
                height: "30",
                viewBox: "0 0 30 30",
                children: (0, o.jsx)("rect", {
                  x: "5",
                  y: "5",
                  width: "20",
                  height: "20",
                  style: { ...l, strokeDasharray: "4,4" },
                }),
              });
            default:
              return null;
          }
        },
        E = (e) => {
          let { thematics: t, onLayerClick: n, loadedLayers: i } = e;
          const a = (0, r.useRef)(!1);
          (0, r.useEffect)(() => {
            if (t.length > 0 && !a.current) {
              console.log("First call made"), (a.current = !0);
              for (const e of t)
                for (const t of e.layers) "pc_areas" === t.idLayer && n(t);
            }
          }, [t]);
          const l = (e) => {
            const t = e.type;
            if (!t) throw new Error("Layer type must be defined and valid.");
            return {
              stroke: e.stroke
                ? {
                    r: parseFloat(e.stroke.r),
                    g: parseFloat(e.stroke.g),
                    b: parseFloat(e.stroke.b),
                    a: parseFloat(e.stroke.a),
                    width: e.stroke.width,
                    opacity: e.stroke.opacity,
                  }
                : void 0,
              type: t,
              lineDash: void 0 !== e.lineDash ? e.lineDash > 0 : void 0,
              image: e.image,
            };
          };
          return (0, o.jsx)(f.Z, {
            sx: { padding: 2 },
            children:
              t &&
              t.map((e, a) =>
                (0, o.jsxs)(
                  f.Z,
                  {
                    sx: { marginBottom: 1 },
                    children: [
                      e.nom.length > 0 &&
                        (0, o.jsxs)(f.Z, {
                          sx: {
                            display: "flex",
                            flexDirection: "row",
                            alignItems: "center",
                          },
                          children: [
                            (0, o.jsx)(C.Z, {
                              checked: !1,
                              sx: {
                                padding: 0,
                                color: "grey",
                                "&.Mui-checked": {
                                  color: P.Z.palette.primary.main,
                                },
                              },
                              disableRipple: !0,
                            }),
                            (0, o.jsxs)(f.Z, {
                              sx: { display: "flex", alignItems: "center" },
                              children: [
                                (0, o.jsx)(f.Z, {
                                  sx: { marginRight: "5px", marginLeft: "5px" },
                                  children: I(l(e.layers[0])),
                                }),
                                (0, o.jsx)(y.Z, {
                                  variant: "body1",
                                  children: e.nom,
                                }),
                              ],
                            }),
                          ],
                        }),
                      e.layers.map((t) => {
                        const a = i.some((e) => e.idLayer === t.idLayer);
                        return (0, o.jsx)(
                          r.Fragment,
                          {
                            children: (0, o.jsxs)(f.Z, {
                              sx: {
                                display: "flex",
                                alignItems: "center",
                                marginTop: e.nom.length > 0 ? 1 : 0,
                                cursor: "pointer",
                                paddingLeft: e.nom.length > 0 ? 2 : 0,
                                borderRadius: 1,
                                "&:hover": { backgroundColor: L.Z[200] },
                              },
                              onClick: () => n(t),
                              children: [
                                (0, o.jsx)(C.Z, {
                                  checked: a,
                                  sx: {
                                    padding: 0,
                                    color: "grey",
                                    "&.Mui-checked": {
                                      color: P.Z.palette.primary.main,
                                    },
                                  },
                                  disableRipple: !0,
                                }),
                                (0, o.jsxs)(f.Z, {
                                  sx: { display: "flex", alignItems: "center" },
                                  children: [
                                    (0, o.jsx)(f.Z, {
                                      sx: {
                                        marginRight: "5px",
                                        marginLeft: "5px",
                                      },
                                      children: I(l(t)),
                                    }),
                                    (0, o.jsx)(y.Z, {
                                      variant: "body2",
                                      children: t.name,
                                    }),
                                  ],
                                }),
                              ],
                            }),
                          },
                          t.idLayer
                        );
                      }),
                      a < t.length - 1 &&
                        (0, o.jsx)(F.Z, { sx: { marginY: 1.2 } }),
                    ],
                  },
                  e.nom + e.layers.length + a
                )
              ),
          });
        };
      var _ = r.memo(E),
        D = n(46068),
        R = n(48836),
        z = n(32351),
        T = n(75787),
        A = n(70428),
        G = n(9180),
        M = n(28027),
        N = n(13245),
        O = n(29003),
        B = n(85250),
        W = n(49118),
        V = n(21166),
        U = n(64672),
        H = n(63600);
      const Y = new D.ZP({
          text: new N.Z({
            font: "14px Calibri,sans-serif",
            fill: new R.Z({ color: "rgba(255, 255, 255, 1)" }),
            backgroundFill: new R.Z({ color: "rgba(0, 0, 0, 0.7)" }),
            padding: [3, 3, 3, 3],
            textBaseline: "middle",
            offsetY: -15,
            textAlign: "center",
          }),
          image: new O.Z({
            radius: 8,
            points: 3,
            angle: Math.PI,
            displacement: [0, 10],
            fill: new R.Z({ color: "rgba(0, 0, 0, 0.7)" }),
          }),
        }),
        q = new D.ZP({
          text: new N.Z({
            font: "12px Calibri,sans-serif",
            fill: new R.Z({ color: "rgba(255, 255, 255, 1)" }),
            backgroundFill: new R.Z({ color: "rgba(0, 0, 0, 0.4)" }),
            padding: [2, 2, 2, 2],
            textAlign: "left",
            offsetX: 15,
          }),
        }),
        J = new D.ZP({
          fill: new R.Z({ color: "rgba(255, 255, 255, 0.2)" }),
          stroke: new z.Z({
            color: "rgba(0, 0, 0, 0.5)",
            lineDash: [10, 10],
            width: 2,
          }),
          image: new T.Z({
            radius: 5,
            stroke: new z.Z({ color: "rgba(0, 0, 0, 0.7)" }),
            fill: new R.Z({ color: "rgba(255, 255, 255, 0.2)" }),
          }),
        }),
        K = new D.ZP({
          text: new N.Z({
            font: "12px Calibri,sans-serif",
            fill: new R.Z({ color: "rgba(255, 255, 255, 1)" }),
            backgroundFill: new R.Z({ color: "rgba(0, 0, 0, 0.4)" }),
            padding: [2, 2, 2, 2],
            textBaseline: "bottom",
            offsetY: -12,
          }),
          image: new O.Z({
            radius: 6,
            points: 3,
            angle: Math.PI,
            displacement: [0, 8],
            fill: new R.Z({ color: "rgba(0, 0, 0, 0.4)" }),
          }),
        }),
        Q = new g.Z(),
        X = new D.ZP({
          image: new T.Z({
            radius: 5,
            stroke: new z.Z({ color: "rgba(0, 0, 0, 0.7)" }),
            fill: new R.Z({ color: "rgba(0, 0, 0, 0.4)" }),
          }),
          text: new N.Z({
            text: "Drag to modify",
            font: "12px Calibri,sans-serif",
            fill: new R.Z({ color: "rgba(255, 255, 255, 1)" }),
            backgroundFill: new R.Z({ color: "rgba(0, 0, 0, 0.7)" }),
            padding: [2, 2, 2, 2],
            textAlign: "left",
            offsetX: 15,
          }),
        }),
        $ = new U.Z({ source: Q, style: X }),
        ee = [K],
        te = (e) => {
          const t = (0, H.xA)(e);
          return t > 1e3
            ? "".concat((t / 1e3).toFixed(2), " km")
            : "".concat(t.toFixed(2), " m");
        };
      function ne(e, t, n, o) {
        const r = [],
          i = e.getGeometry();
        if (!i) return r;
        const a = i.getType();
        let l, s, c;
        if ((r.push(J), !n || n === a || "Point" === a))
          if ("Polygon" === a)
            i instanceof B.ZP &&
              ((l = i.getInteriorPoint()),
              (s = ((e) => {
                const t = (0, H.bg)(e);
                return t > 1e4
                  ? "".concat((t / 1e6).toFixed(2), " km\xb2")
                  : "".concat(t.toFixed(2), " m\xb2");
              })(i)));
          else if ("LineString" === a && i instanceof W.Z) {
            c = i;
            const e = c.getCoordinates(),
              t = e[Math.floor(e.length / 2)];
            (l = new V.Z(t)), (s = te(c));
          }
        if (t && c) {
          let e = 0;
          c.forEachSegment((t, n) => {
            const o = new W.Z([t, n]),
              i = te(o);
            ee.length - 1 < e && ee.push(K.clone());
            const a = new V.Z(o.getCoordinateAt(0.5));
            ee[e].setGeometry(a);
            const l = ee[e].getText();
            l && l.setText(i), r.push(ee[e]), e++;
          });
        }
        if (s) {
          const e = Y.clone();
          if ("LineString" === a && c) {
            const t = c.getCoordinates();
            if (t.length > 1) {
              const n = t[0],
                o = t[t.length - 1],
                r = [(n[0] + o[0]) / 2, (n[1] + o[1]) / 2];
              e.setGeometry(new V.Z(r));
            }
          } else l && e.setGeometry(l);
          const t = e.getText();
          t && t.setText(s), r.push(e);
        }
        var d, u, g;
        if (
          o &&
          "Point" === a &&
          0 ===
            (null === $ ||
            void 0 === $ ||
            null === (g = $.getOverlay()) ||
            void 0 === g ||
            null === (u = g.getSource()) ||
            void 0 === u ||
            null === (d = u.getFeatures()) ||
            void 0 === d
              ? void 0
              : d.length)
        ) {
          const e = q.getText();
          e && e.setText(o), r.push(q);
        }
        return r;
      }
      var oe = n(66648);
      var re = (e) => {
          let {
            map: t,
            vectorSource: n,
            popupVisible: i,
            setPopupVisible: a,
            iconPosition: l,
          } = e;
          const s = (0, r.useRef)(null),
            c = (e) => {
              ((e) => {
                t &&
                  n &&
                  (s.current &&
                    (t.removeInteraction(s.current), (s.current = null)),
                  (s.current = new G.ZP({
                    source: n,
                    type: "LineString" == e ? "LineString" : "Polygon",
                    style: (t) =>
                      ne(
                        t,
                        !0,
                        "LineString" == e ? "LineString" : "Polygon",
                        "Click to start measuring"
                      ),
                  })),
                  s.current.on("drawend", function (t) {
                    const n = t.feature;
                    n &&
                      n.setStyle(
                        ne(
                          n,
                          !0,
                          "LineString" == e ? "LineString" : "Polygon",
                          "Click to start measuring"
                        )
                      );
                  }),
                  t.addInteraction(s.current));
              })(e);
            },
            d = {
              position: "absolute",
              top: l.top + 10,
              left: l.left + 60,
              zIndex: 1e3,
              display: "flex",
              flexDirection: "row",
            };
          return (0, o.jsx)(o.Fragment, {
            children:
              i &&
              (0, o.jsxs)(M.Z, {
                style: d,
                children: [
                  (0, o.jsx)(m.Z, {
                    onClick: () => c("LineString"),
                    children: (0, o.jsx)(oe.default, {
                      src: "/roller.png",
                      alt: "delete",
                      width: 22,
                      height: 24,
                      style: { cursor: "pointer" },
                    }),
                  }),
                  (0, o.jsx)(m.Z, {
                    onClick: () => c("Polygon"),
                    children: (0, o.jsx)(oe.default, {
                      src: "/area.png",
                      alt: "area",
                      width: 30,
                      height: 24,
                      style: { cursor: "pointer" },
                    }),
                  }),
                  (0, o.jsx)(m.Z, {
                    onClick: () => {
                      t &&
                        s.current &&
                        n &&
                        (t.removeInteraction(s.current),
                        (s.current = null),
                        n.clear()),
                        a(!1);
                    },
                    children: (0, o.jsx)(oe.default, {
                      src: "/delete.png",
                      alt: "delete",
                      width: 19,
                      height: 19,
                      style: { cursor: "pointer" },
                    }),
                  }),
                ],
              }),
          });
        },
        ie = n(21530),
        ae = n(43154),
        le = n(23983),
        se = n(76548),
        ce = n(22960),
        de = n(79647);
      var ue = (e) => {
          let {
            open: t,
            onClose: n,
            onSearch: i,
            geoCodeFeatures: a,
            iconPosition: l,
          } = e;
          const [s, c] = (0, r.useState)(a[0]),
            [d, u] = (0, r.useState)("000"),
            [g, x] = (0, r.useState)("000"),
            h = (0, ce.Z)(),
            Z = (0, de.Z)(h.breakpoints.down("sm"));
          (0, r.useEffect)(() => {
            null === s && a.length > 0 && c(a[0]);
          }, [a]);
          const b = {
            position: "absolute",
            top: Z ? "20%" : l.top + 10,
            right: Z ? "5%" : window.innerWidth - l.right + 80,
            zIndex: 1e3,
            padding: Z ? "8px" : "16px",
            width: Z ? "90%" : "350px",
            display: "flex",
            flexDirection: "column",
            backgroundColor: "#fff",
          };
          return (0, o.jsx)(o.Fragment, {
            children:
              t &&
              (0, o.jsxs)(M.Z, {
                style: b,
                children: [
                  (0, o.jsxs)(f.Z, {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    paddingBottom: "15px",
                    children: [
                      (0, o.jsx)(y.Z, {
                        variant: "body1",
                        color: h.palette.primary.main,
                        children: "Search Geocode",
                      }),
                      (0, o.jsx)(m.Z, {
                        edge: "end",
                        color: "inherit",
                        onClick: n,
                        "aria-label": "close",
                        children: (0, o.jsx)(p.Z, {}),
                      }),
                    ],
                  }),
                  (0, o.jsx)(ae.Z, {
                    value: s,
                    onChange: (e, t) => {
                      console.log("Selected Feature", e), c(t);
                    },
                    options: a,
                    getOptionLabel: (e) =>
                      ((e) =>
                        "object" === typeof e &&
                        null !== e &&
                        "id" in e &&
                        "libelle" in e)(e)
                        ? e.libelle || "Unknown"
                        : e,
                    renderInput: (e) =>
                      (0, o.jsx)(le.Z, {
                        ...e,
                        label: "Base Grid",
                        variant: "outlined",
                        fullWidth: !0,
                        InputProps: {
                          ...e.InputProps,
                          style: {
                            height: 40,
                            padding: "16px",
                            marginBottom: "16px",
                          },
                        },
                        InputLabelProps: { style: { lineHeight: 1.5 } },
                      }),
                  }),
                  (0, o.jsxs)(f.Z, {
                    display: "flex",
                    justifyContent: "space-between",
                    gap: "16px",
                    children: [
                      (0, o.jsx)(le.Z, {
                        fullWidth: !0,
                        margin: "normal",
                        label: "Abscissa",
                        placeholder: "000",
                        value: d,
                        onChange: (e) => u(e.target.value.slice(0, 3)),
                        InputProps: { style: { height: 40 } },
                        InputLabelProps: { style: { lineHeight: 1.5 } },
                      }),
                      (0, o.jsx)(le.Z, {
                        fullWidth: !0,
                        margin: "normal",
                        label: "Ordinate",
                        placeholder: "000",
                        value: g,
                        onChange: (e) => x(e.target.value.slice(0, 3)),
                        InputProps: { style: { height: 40 } },
                        InputLabelProps: { style: { lineHeight: 1.5 } },
                      }),
                    ],
                  }),
                  (0, o.jsx)(se.default, {
                    onClick: () => {
                      i(s, d, g), n();
                    },
                    color: "primary",
                    variant: "contained",
                    style: { marginTop: "16px" },
                    children: "Search",
                  }),
                ],
              }),
          });
        },
        ge = n(74583),
        xe = n(24037),
        pe = n(45174);
      var he = (e) => {
          let { iconPosition: t, onToggleLayer: n, onOpacityChange: i } = e;
          const [a, l] = (0, r.useState)(!0),
            [s, c] = (0, r.useState)(!1),
            [d, u] = (0, r.useState)(!1),
            [g, x] = (0, r.useState)(50),
            [p, h] = (0, r.useState)(50),
            [m, Z] = (0, r.useState)(50),
            b = (e) => {
              switch (e) {
                case "osm":
                  l(!a), n("osm", !a);
                  break;
                case "road":
                  c(!s), n("road", !s);
                  break;
                case "arial":
                  u(!d), n("arial", !d);
              }
            },
            w = (e, t) => {
              switch (e) {
                case "osm":
                  x(t), i("osm", t);
                  break;
                case "road":
                  h(t), i("road", t);
                  break;
                case "arial":
                  Z(t), i("arial", t);
              }
            },
            j = {
              position: "absolute",
              top: t.top + 10,
              left: 80,
              zIndex: 1e3,
              backgroundColor: "#fff",
              borderRadius: "8px",
              boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
              padding: "16px",
              display: "flex",
              flexDirection: "row",
              gap: "16px",
            };
          return (0, o.jsx)(f.Z, {
            style: j,
            children: (0, o.jsxs)(f.Z, {
              style: {
                width: "100%",
                display: "flex",
                flexDirection: "row",
                gap: "12px",
              },
              children: [
                (0, o.jsxs)(f.Z, {
                  display: "flex",
                  flexDirection: "column",
                  sx: { width: "100%" },
                  children: [
                    (0, o.jsxs)(f.Z, {
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "space-between",
                      alignItems: "center",
                      children: [
                        (0, o.jsx)(y.Z, {
                          variant: "body1",
                          style: { fontSize: "12px" },
                          children: "OSM",
                        }),
                        (0, o.jsx)(ge.Z, {
                          checked: a,
                          onChange: () => b("osm"),
                          color: "primary",
                        }),
                      ],
                    }),
                    (0, o.jsx)(xe.Z, {
                      component: "img",
                      height: "80",
                      image: "/osm.png",
                      alt: "OSM",
                      style: { objectFit: "fill" },
                    }),
                    (0, o.jsx)(pe.ZP, {
                      value: g,
                      onChange: (e, t) => w("osm", Number(t)),
                      "aria-labelledby": "osm-opacity-slider",
                      style: { marginTop: "8px" },
                      sx: {
                        marginTop: "8px",
                        height: 4,
                        "& .MuiSlider-thumb": { height: 12, width: 12 },
                      },
                    }),
                  ],
                }),
                (0, o.jsx)(F.Z, { flexItem: !0 }),
                (0, o.jsxs)(f.Z, {
                  display: "flex",
                  flexDirection: "column",
                  sx: { width: "100%" },
                  children: [
                    (0, o.jsxs)(f.Z, {
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "space-between",
                      alignItems: "center",
                      children: [
                        (0, o.jsx)(y.Z, {
                          variant: "body1",
                          style: { fontSize: "12px" },
                          children: "Road",
                        }),
                        (0, o.jsx)(ge.Z, {
                          checked: s,
                          onChange: () => b("road"),
                          color: "primary",
                        }),
                      ],
                    }),
                    (0, o.jsx)(xe.Z, {
                      component: "img",
                      height: "80",
                      image: "/road.png",
                      alt: "Road",
                      style: { objectFit: "fill" },
                    }),
                    (0, o.jsx)(pe.ZP, {
                      value: p,
                      onChange: (e, t) => w("road", Number(t)),
                      "aria-labelledby": "road-opacity-slider",
                      style: { marginTop: "8px" },
                    }),
                  ],
                }),
                (0, o.jsx)(F.Z, { flexItem: !0 }),
                (0, o.jsxs)(f.Z, {
                  display: "flex",
                  flexDirection: "column",
                  sx: { width: "100%" },
                  children: [
                    (0, o.jsxs)(f.Z, {
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "space-between",
                      alignItems: "center",
                      children: [
                        (0, o.jsx)(y.Z, {
                          variant: "body1",
                          style: { fontSize: "12px" },
                          children: "Arial Maps",
                        }),
                        (0, o.jsx)(ge.Z, {
                          checked: d,
                          onChange: () => b("arial"),
                          color: "primary",
                        }),
                      ],
                    }),
                    (0, o.jsx)(xe.Z, {
                      component: "img",
                      height: "80",
                      image: "/aerial.png",
                      alt: "Aerial Maps",
                      style: { objectFit: "fill" },
                    }),
                    (0, o.jsx)(pe.ZP, {
                      value: m,
                      onChange: (e, t) => w("arial", Number(t)),
                      "aria-labelledby": "arial-opacity-slider",
                      style: { marginTop: "8px" },
                    }),
                  ],
                }),
              ],
            }),
          });
        },
        fe = n(52326),
        me = n(25774),
        ye = n(62436),
        Ze = n(96563),
        be = n(24434),
        we = n(29396),
        je = n(35162),
        ve = n(46828),
        ke = n(91373),
        Se = n(72098);
      var Ce = (e) => {
          let { icon: t, label: n, value: r } = e;
          return (0, o.jsxs)(o.Fragment, {
            children: [
              (0, o.jsxs)(f.Z, {
                display: "flex",
                alignItems: "center",
                paddingY: 1,
                children: [
                  t &&
                    (0, o.jsx)(f.Z, {
                      marginRight: 2,
                      display: "flex",
                      alignItems: "center",
                      children: t,
                    }),
                  (0, o.jsxs)(f.Z, {
                    children: [
                      (0, o.jsx)(y.Z, {
                        variant: "caption",
                        color: "textSecondary",
                        children: n,
                      }),
                      (0, o.jsx)(y.Z, {
                        variant: "body1",
                        color: "primary",
                        children: r,
                      }),
                    ],
                  }),
                ],
              }),
              (0, o.jsx)(F.Z, {}),
            ],
          });
        },
        Le = n(94556);
      var Fe = (e) => {
          let {
            feature: t,
            coordinates: n,
            geocode: i,
            options: a,
            isLoading: l,
            onSearchGeoCodeClick: s,
          } = e;
          const c = l ? "..." : "Unknown Street",
            d = l
              ? "..."
              : (null === t || void 0 === t ? void 0 : t.pr_name) ||
                "Unknown Region",
            u = l
              ? "..."
              : (null === t || void 0 === t ? void 0 : t.pc_name) ||
                "Unknown District",
            g = l
              ? "..."
              : (null === t || void 0 === t ? void 0 : t.pc_name) ||
                "Unknown Community",
            x = l
              ? "..."
              : (null === t || void 0 === t ? void 0 : t.pr_name) ||
                "Unknown Postal Area",
            p = l
              ? "..."
              : (null === t || void 0 === t ? void 0 : t.pc_code) || "000000",
            [h, b] = (0, r.useState)(!1),
            w = (e, t) => {
              "clickaway" !== t && b(!1);
            },
            j = (e) =>
              "object" === typeof e &&
              null !== e &&
              "id" in e &&
              "libelle" in e;
          return (0, o.jsxs)(f.Z, {
            padding: 2,
            bgcolor: "#f5f5f5",
            borderRadius: 2,
            children: [
              (0, o.jsx)(f.Z, {
                marginBottom: 2,
                children: (0, o.jsx)(ae.Z, {
                  freeSolo: !0,
                  getOptionKey: (e) =>
                    j(e)
                      ? e.id && e.key
                        ? "".concat(e.id, "-").concat(e.key)
                        : "geoFeature-".concat(Math.random())
                      : e
                      ? "nonGeo-".concat(e)
                      : "nonGeo-unknown-".concat(Math.random()),
                  options: a,
                  onChange: async (e, t) => {
                    t && j(t) && s(t);
                  },
                  getOptionLabel: (e) => (j(e) ? e.libelle || "Unknown" : e),
                  renderInput: (e) =>
                    (0, o.jsx)(le.Z, {
                      ...e,
                      fullWidth: !0,
                      variant: "outlined",
                      placeholder: "Search Address, Places, Coordinates",
                      InputProps: {
                        ...e.InputProps,
                        endAdornment: (0, o.jsx)(fe.Z, {
                          position: "end",
                          children: (0, o.jsx)(ye.Z, {
                            sx: { color: "white" },
                          }),
                        }),
                      },
                    }),
                }),
              }),
              l &&
                (0, o.jsxs)(f.Z, {
                  sx: {
                    textAlign: "center",
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "center",
                    alignSelf: "center",
                    justifyContent: "center",
                  },
                  children: [
                    (0, o.jsx)(Z.Z, {
                      size: 24,
                      sx: { color: P.Z.palette.primary.main },
                    }),
                    (0, o.jsx)(y.Z, {
                      variant: "body1",
                      sx: { ml: 1, color: P.Z.palette.primary.main },
                      children: "Loading...",
                    }),
                  ],
                }),
              (0, o.jsx)(y.Z, {
                variant: "caption",
                color: "textSecondary",
                marginBottom: 1,
                marginTop: l ? 4 : 0,
                children: "Geocode",
              }),
              (0, o.jsxs)(f.Z, {
                padding: 2,
                borderRadius: 2,
                bgcolor: "#e3f2fd",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: 2,
                children: [
                  (0, o.jsxs)(f.Z, {
                    display: "flex",
                    alignItems: "center",
                    children: [
                      (0, o.jsx)(Ze.Z, { color: "primary" }),
                      (0, o.jsx)(y.Z, {
                        variant: "h6",
                        color: "primary",
                        marginLeft: 1,
                        children: l ? "..." : 0 === i.length ? "Unknown" : i,
                      }),
                    ],
                  }),
                  i &&
                    !l &&
                    i.length > 5 &&
                    (0, o.jsx)(m.Z, {
                      onClick: () => {
                        navigator.clipboard
                          .writeText(i)
                          .then(() => {
                            b(!0);
                          })
                          .catch((e) => {
                            console.error("Could not copy text: ", e);
                          });
                      },
                      size: "small",
                      children: (0, o.jsx)(Se.Z, { color: "primary" }),
                    }),
                  (0, o.jsx)(me.Z, {
                    open: h,
                    autoHideDuration: 3e3,
                    onClose: w,
                    message: "Geocode copied to clipboard!",
                    anchorOrigin: { vertical: "top", horizontal: "center" },
                  }),
                ],
              }),
              (0, o.jsx)(y.Z, {
                variant: "caption",
                color: "textSecondary",
                marginBottom: 1,
                children: "Address Info",
              }),
              (0, o.jsx)(Ce, {
                icon: (0, o.jsx)(be.Z, { color: "primary" }),
                label: "Street Name",
                value: c,
              }),
              (0, o.jsx)(Ce, {
                icon: (0, o.jsx)(Le.Z, { icon: "mdi:code-tags", fontSize: 20 }),
                label: "Region",
                value: d,
              }),
              (0, o.jsx)(Ce, {
                icon: (0, o.jsx)(we.Z, { color: "primary" }),
                label: "District",
                value: u,
              }),
              (0, o.jsx)(Ce, {
                icon: (0, o.jsx)(je.Z, { color: "primary" }),
                label: "Community",
                value: g,
              }),
              (0, o.jsx)(Ce, {
                icon: (0, o.jsx)(ve.Z, { color: "primary" }),
                label: "Postal Area",
                value: x,
              }),
              (0, o.jsx)(Ce, {
                icon: (0, o.jsx)(ke.Z, { color: "primary" }),
                label: "Post Code",
                value: p,
              }),
              (0, o.jsx)(Ce, {
                icon: (0, o.jsx)(Ze.Z, { color: "primary" }),
                label: "Latitude, Longitude",
                value: "".concat(n[0].toFixed(6), ", ").concat(n[1].toFixed(6)),
              }),
              (0, o.jsx)(me.Z, {
                open: h,
                autoHideDuration: 3e3,
                onClose: w,
                message: "Geocode copied to clipboard!",
                anchorOrigin: { vertical: "top", horizontal: "center" },
              }),
            ],
          });
        },
        Pe = n(71733),
        Ie = n(79806),
        Ee = n(6291),
        _e = n(11656),
        De = n(66325),
        Re = n(16463),
        ze = n(38472);
      var Te = () => {
          const [e, t] = (0, r.useState)(null),
            [n, i] = (0, r.useState)(null),
            a = (0, Re.useRouter)();
          (0, r.useEffect)(() => {
            const e = localStorage.getItem("user");
            e && i(JSON.parse(e));
          }, []);
          const l = () => {
              t(null);
            },
            s = Boolean(e);
          return (0, o.jsxs)(o.Fragment, {
            children: [
              (0, o.jsx)(m.Z, {
                color: "inherit",
                "aria-label": "account",
                onClick: (e) => {
                  t(e.currentTarget);
                },
                children: (0, o.jsx)(De.Z, { fontSize: "large" }),
              }),
              (0, o.jsxs)(Ee.Z, {
                anchorEl: e,
                open: s,
                onClose: l,
                PaperProps: { sx: { width: "200px" } },
                children: [
                  n
                    ? (0, o.jsxs)("div", {
                        children: [
                          (0, o.jsx)(_e.Z, {
                            onClick: l,
                            children: (0, o.jsx)(y.Z, {
                              variant: "body1",
                              children: n.email,
                            }),
                          }),
                          (0, o.jsx)(_e.Z, {
                            onClick: l,
                            children: (0, o.jsxs)(y.Z, {
                              variant: "body2",
                              children: ["Role: ", n.role],
                            }),
                          }),
                          (0, o.jsx)(F.Z, {}),
                          "admin" === n.role &&
                            (0, o.jsx)(_e.Z, {
                              onClick: () => {
                                window.open("/admin", "_blank"), l();
                              },
                              children: "Admin Panel",
                            }),
                          (0, o.jsx)(F.Z, {}),
                        ],
                      })
                    : (0, o.jsx)(_e.Z, {
                        children: (0, o.jsx)(y.Z, {
                          variant: "body2",
                          children: "Loading...",
                        }),
                      }),
                  (0, o.jsx)(_e.Z, {
                    onClick: async () => {
                      try {
                        const e = await ze.Z.post(
                          "/api/auth/logout",
                          {},
                          { withCredentials: !0 }
                        );
                        console.log("Logout response:", e),
                          200 === e.status
                            ? (console.log("Logout successful"),
                              localStorage.removeItem("token"),
                              localStorage.removeItem("user"),
                              a.push("/"))
                            : console.error("Logout failed", e.data);
                      } catch (e) {
                        console.error("Error during logout:", e);
                      }
                    },
                    children: "Logout",
                  }),
                ],
              }),
            ],
          });
        },
        Ae = n(6760);
      var Ge = (e) => {
          let { toggleDrawer: t, isForAdminPanel: n } = e;
          return (0, o.jsx)(Pe.Z, {
            position: "static",
            children: (0, o.jsxs)(Ie.Z, {
              children: [
                (0, o.jsx)(m.Z, {
                  edge: "start",
                  color: "inherit",
                  "aria-label": "menu",
                  sx: { mr: 2 },
                  children: (0, o.jsx)("img", {
                    src: "/app_logo.png",
                    alt: "app_logo",
                    height: 30,
                  }),
                }),
                (0, o.jsx)(f.Z, { sx: { flexGrow: 1 } }),
                0 == n &&
                  (0, o.jsxs)(o.Fragment, {
                    children: [
                      (0, o.jsx)(Te, {}),
                      (0, o.jsxs)(m.Z, {
                        color: "inherit",
                        "aria-label": "menu",
                        onClick: () => {
                          t(!0);
                        },
                        children: [
                          (0, o.jsx)(Ae.Z, { fontSize: "large" }),
                          " ",
                        ],
                      }),
                    ],
                  }),
              ],
            }),
          });
        },
        Me = n(28675),
        Ne = n(47343);
      function Oe() {
        const [e, t] = (0, r.useState)(0),
          [n, v] = (0, r.useState)(!1),
          [C, L] = (0, r.useState)(null),
          [F, I] = (0, r.useState)([]),
          [E, G] = (0, r.useState)(),
          M = (0, r.useRef)(null),
          N = (0, r.useRef)(null),
          [O, B] = (0, r.useState)([]),
          W = (0, Re.useSearchParams)(),
          [U, H] = (0, r.useState)(!1),
          [Y, q] = (0, r.useState)(!1),
          [J, K] = (0, r.useState)(!1),
          [Q, X] = (0, r.useState)(!0),
          [$, ee] = (0, r.useState)(null),
          [te, ne] = ((0, Me.tm)(), (0, r.useState)(void 0)),
          [ae, le] = (0, r.useState)(!1),
          se = (0, r.useRef)(null),
          [ce, de] = (0, r.useState)(void 0),
          ge = (0, r.useRef)(null),
          [xe, pe] = (0, r.useState)(void 0),
          fe = (0, r.useRef)(null),
          [me, ye] = (0, r.useState)(!1),
          [Ze, be] = (0, r.useState)(null),
          [we, je] = (0, r.useState)(null),
          [ve, ke] = (0, r.useState)(null),
          Se = (0, r.useRef)([]),
          Ce = () => {
            if (J) K(!1);
            else {
              if (se.current) {
                const e = se.current.getBoundingClientRect();
                ne(e);
              }
              K(!0), ye(!1), q(!1), v(!1);
            }
          },
          Pe = () => {
            if (me) ye(!1);
            else {
              if (fe.current) {
                const e = fe.current.getBoundingClientRect();
                pe(e);
              }
              K(!1), ye(!0), q(!1);
            }
          },
          Ie = () => {
            if (Y) q(!1);
            else {
              if (ge.current) {
                const e = ge.current.getBoundingClientRect();
                de(e);
              }
              q(!0), K(!1), ye(!1);
            }
          },
          Ee = (0, r.useRef)(new g.Z({ format: new h.Z(), strategy: b.VW })),
          _e = (0, r.useRef)(new g.Z({ format: new h.Z(), strategy: b.VW })),
          De = (0, r.useRef)(new g.Z({ format: new h.Z(), strategy: b.VW }));
        const ze = async function (e) {
          let t =
            !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
          le(!0);
          const n = (0, x.vs)(e.coordinate, "EPSG:3857", "EPSG:4326");
          ee({ feature: null, coordinates: n, geocode: "" });
          const o = n[1],
            r = n[0];
          if (1 == t) {
            const e = new i.Z({ geometry: new V.Z((0, x.mi)([n[0], n[1]])) });
            null != De.current &&
              (De.current.clear(), De.current.addFeature(e));
          }
          try {
            const e = await (async (e, t) => {
              try {
                return (
                  console.log("fetchWFSFeatures lat", e),
                  console.log("fetchWFSFeatures long", t),
                  await (0, S.bF)(e, t)
                );
              } catch (n) {
                throw (
                  (console.error("Error fetching features:", n),
                  new Error(
                    "Could not fetch geocode features. Please try again later."
                  ))
                );
              }
            })(o, r);
            le(!1),
              e.length > 0
                ? e.forEach((e) => {
                    const t = e.properties.tooltip,
                      o = e.properties;
                    let r = n[0] + "",
                      i = n[1] + "";
                    (r = r.substr(4, 3)),
                      (i = i.substr(5, 3)),
                      null != t &&
                        (X(!0),
                        ee({
                          feature: o,
                          coordinates: n,
                          geocode: "".concat(t, "-").concat(i).concat(r),
                        }));
                  })
                : console.log("No features found at the clicked location.");
          } catch (a) {
            console.error("Error loading geocode features:", a);
          }
        };
        (0, r.useEffect)(() => {
          H(0 == ae && null != $);
        }, [ae, $]),
          (0, r.useEffect)(() => {
            if (null != E) {
              const e = (e) => {
                J || ze(e);
              };
              return (
                E.on("click", e),
                () => {
                  E.un("click", e);
                }
              );
            }
          }, [E, J, K, X]),
          (0, r.useEffect)(() => {
            console.log("fetchConfig"),
              (async () => {
                if (null == C) {
                  console.log("Get mapconfig");
                  try {
                    const e = await (0, S.WT)();
                    L(e);
                  } catch (e) {
                    console.error("Error fetching map configuration:", e);
                  }
                }
              })(),
              (async () => {
                try {
                  const e = encodeURIComponent(
                      JSON.stringify({
                        bddShema: "zambie",
                        lstLayerSearch: [
                          {
                            index: 0,
                            table: "zone",
                            fieldId: "id",
                            fieldName: "zon_name",
                          },
                          {
                            index: 1,
                            table: "pc_areas",
                            fieldId: "id",
                            fieldName: "pc_name",
                          },
                          {
                            index: 2,
                            table: "pc_subareas",
                            fieldId: "id_0",
                            fieldName: "tooltip",
                          },
                          {
                            index: 3,
                            table: "plot",
                            fieldId: "id_plt",
                            fieldName: "plt_ident",
                          },
                          {
                            index: 4,
                            table: "building_r",
                            fieldId: "id_type_building_r",
                            fieldName: "tooltip",
                          },
                          {
                            index: 5,
                            table: "street",
                            fieldId: "id_str",
                            fieldName: "str_name",
                          },
                        ],
                        dt: new Date().toLocaleString(),
                      })
                    ),
                    t = await (0, S.EX)(e);
                  if (t.layersSearch) {
                    const e = t.layersSearch
                      .flatMap((e) =>
                        e.features
                          ? e.features.map((t) => ({ ...t, table: e.table }))
                          : []
                      )
                      .filter(
                        (e) => !!e && !!e.libelle && "" !== e.libelle.trim()
                      );
                    B(e);
                  }
                } catch (e) {
                  console.error("Error fetching data:", e);
                }
              })();
          }, []),
          (0, r.useEffect)(() => {
            const e = null === W || void 0 === W ? void 0 : W.get("feature");
            if (null != E && null != e) {
              const t = (0, Ne.Ju)(e);
              We(t);
            }
          }, [E]),
          (0, r.useEffect)(() => {
            if (null != E) return;
            const e = -13.1339,
              t = 27.8493,
              n = null === W || void 0 === W ? void 0 : W.get("lat"),
              o = null === W || void 0 === W ? void 0 : W.get("lng"),
              r = (null === W || void 0 === W ? void 0 : W.get("lat"))
                ? parseFloat(n)
                : e,
              p = (null === W || void 0 === W ? void 0 : W.get("lng"))
                ? parseFloat(o)
                : t,
              h = new d.Z({ source: new c.Z() }),
              f = new d.Z({
                source: new k.Z({
                  key: "AkEp977CrlbMYKdZs2Ts3CbcuspkQkElGqYd2_xQb7F9ng_ENERukH0wTJAh01Zl",
                  imagerySet: "Road",
                }),
                visible: !1,
                preload: 1 / 0,
              }),
              m = new d.Z({
                source: new k.Z({
                  key: "AkEp977CrlbMYKdZs2Ts3CbcuspkQkElGqYd2_xQb7F9ng_ENERukH0wTJAh01Zl",
                  imagerySet: "Aerial",
                }),
                visible: !1,
              }),
              y = new D.ZP({
                fill: new R.Z({ color: "rgba(255, 255, 255, 0.2)" }),
                stroke: new z.Z({ color: "#ffcc33", width: 2 }),
                image: new T.Z({
                  radius: 7,
                  fill: new R.Z({ color: "#ffcc33" }),
                }),
              }),
              Z = new u.Z({ source: Ee.current || new g.Z(), style: y }),
              b = new u.Z({ source: _e.current || new g.Z(), style: y }),
              j = new u.Z({
                source: De.current || new g.Z(),
                style: new D.ZP({
                  image: new A.Z({ anchor: [0.5, 1], src: "/map_pin.png" }),
                }),
              }),
              v = new a.Z({
                target: "map",
                layers: [h, f, m, Z, j, b],
                view: new l.ZP({ center: (0, x.mi)([p, r]), zoom: 6 }),
                controls: [new w.Z({ minWidth: 100 })],
              });
            G(v),
              be(h),
              je(f),
              ke(m),
              (M.current = document.createElement("div")),
              (M.current.className = "tooltip"),
              document.body.appendChild(M.current);
            const S = new s.Z({
              element: M.current,
              offset: [10, 0],
              positioning: "bottom-left",
            });
            v.addOverlay(S),
              (N.current = S),
              v.on("pointermove", function (e) {
                const t = v.forEachFeatureAtPixel(e.pixel, (e) => e);
                if ((console.log("feature", t), t && M.current)) {
                  const n = t.get("pc_name") || "";
                  (M.current.innerHTML = n),
                    S.setPosition(e.coordinate),
                    (M.current.style.display = "block");
                } else M.current && (M.current.style.display = "none");
              }),
              G(v);
            return (
              (() => {
                const e = v.getView(),
                  t =
                    null === v || void 0 === v
                      ? void 0
                      : v.getView().getCenter(),
                  n = e.calculateExtent(v.getSize())[3];
                if (null == t)
                  return void console.error("Map center is not defined.");
                const o = new i.Z({ geometry: new V.Z([t[0], n + 1e5]) });
                if (
                  (o.setStyle(
                    new D.ZP({
                      image: new A.Z({
                        anchor: [0.5, 1],
                        src: "/map_pin.png",
                        scale: 1,
                      }),
                    })
                  ),
                  null == De.current)
                )
                  return void console.error("Marker source is not defined.");
                De.current.addFeature(o);
                const r = Date.now(),
                  a = () => {
                    const e = Date.now() - r,
                      i = Math.min(e / 1e3, 1),
                      l = ((e) => {
                        const t = 7.5625,
                          n = 2.75;
                        return e < 1 / n
                          ? t * e * e
                          : e < 2 / n
                          ? t * (e -= 1.5 / n) * e + 0.75
                          : e < 2.5 / n
                          ? t * (e -= 2.25 / n) * e + 0.9375
                          : t * (e -= 2.625 / n) * e + 0.984375;
                      })(i),
                      s = n + (t[1] - n) * l,
                      c = o.getGeometry();
                    null != c
                      ? (c.setCoordinates([t[0], s]),
                        i < 1 ? requestAnimationFrame(a) : c.setCoordinates(t))
                      : console.error("Geometry is not defined.");
                  };
                if (
                  null ==
                  (null === W || void 0 === W ? void 0 : W.get("feature"))
                ) {
                  const e = v.getPixelFromCoordinate(t);
                  ze({ pixel: e, coordinate: t }, !1), requestAnimationFrame(a);
                }
              })(),
              () => {}
            );
          }, []);
        const [Te, Ae] = (0, r.useState)({}),
          [Oe, Be] = (0, r.useState)({}),
          We = async (e) => {
            let t = "";
            t = (e.extent && e.extent.length, S.vK);
            const n = "maxFeatures=1&featureID="
              .concat(e.table, ".")
              .concat(e.id);
            Ve(
              {
                layerName: e.table || "",
                idLayer: e.id.toString(),
                wfsUrl: "".concat(
                  "http://196.13.104.124/tomcat/geoserver/zambia/ows",
                  "?service=WFS"
                ),
                name: e.libelle || "",
              },
              n,
              t
            );
          },
          Ve = async (e, t, n) => {
            const o = ""
              .concat(
                "http://196.13.104.124/tomcat/geoserver/zambia/ows",
                "?service=WFS&version=1.1.0&request=GetFeature&typename=zambie:"
              )
              .concat(e.layerName, "&outputFormat=application/json");
            console.log("baseUrl", o);
            const r = t.length > 0 ? "".concat(o, "&").concat(t) : o;
            Se.current.push(r);
            try {
              if ((He(), Oe[e.idLayer] && Ee.current && 0 === t.length)) {
                const t = Ee.current.getFeatures(),
                  n = Oe[e.idLayer],
                  o = t.includes(n[0]);
                return (
                  console.log("isVisible", o),
                  o
                    ? (Ee.current.removeFeatures(Oe[e.idLayer]),
                      I((t) => t.filter((t) => t.idLayer !== e.idLayer)),
                      console.log("Layer ".concat(e.idLayer, " hidden.")))
                    : (Ee.current.addFeatures(Oe[e.idLayer]),
                      I((t) => [...t, e]),
                      console.log("Layer ".concat(e.idLayer, " shown."))),
                  void Ye()
                );
              }
              const n = await fetch(r),
                o = await n.json();
              if (
                (console.log("res data", o),
                Ye(),
                o && o.features && o.features.length > 0)
              ) {
                if (!Ee.current)
                  return void console.error("Map is not initialized.");
                const n = new h.Z().readFeatures(o, {
                  featureProjection: "EPSG:3857",
                });
                if (
                  (n.forEach((t) => {
                    t.set("layerId", e.idLayer);
                  }),
                  Oe[e.idLayer] && Ee.current && 0 === t.length)
                )
                  return void console.log("Layer already loaded.");
                if (
                  (console.log("Layer loaded", e.idLayer),
                  Ee.current.addFeatures(n),
                  t.length > 0)
                ) {
                  const e = (0, ie.lJ)();
                  n.forEach((t) => {
                    (0, ie.l7)(e, t.getGeometry().getExtent());
                  }),
                    null === E ||
                      void 0 === E ||
                      E.getView().fit(e, {
                        padding: [50, 50, 50, 50],
                        duration: 1e3,
                        maxZoom: 16,
                      }),
                    t.length > 0 &&
                      setTimeout(() => {
                        var e;
                        ((e) => {
                          const t = E.getPixelFromCoordinate(e);
                          ze({ pixel: t, coordinate: e });
                        })(
                          null !==
                            (e =
                              null === E || void 0 === E
                                ? void 0
                                : E.getView().getCenter()) && void 0 !== e
                            ? e
                            : [0, 0]
                        );
                      }, 2e3);
                }
                (Te[e.idLayer] = e.zoomLevels || []),
                  Ae({ ...Te }),
                  (Oe[e.idLayer] = n),
                  Be({ ...Oe }),
                  I((t) => [...t, e]);
              } else console.log("No features found.");
            } catch (i) {
              console.error("Error fetching data:", i);
            } finally {
              (Se.current = Se.current.filter((e) => e !== r)), Ye();
            }
          },
          Ue = () => () => {
            K(!1), ye(!1), q(!1), v(!n);
          },
          He = () => t((e) => e + 1),
          Ye = () => t((e) => Math.max(e - 1, 0)),
          qe = e > 0;
        return (0, o.jsxs)(o.Fragment, {
          children: [
            (0, o.jsx)(Ge, {
              isForAdminPanel: !1,
              toggleDrawer: () => {
                v(!n);
              },
            }),
            ce &&
              (0, o.jsx)(ue, {
                iconPosition: ce,
                open: Y,
                onClose: () => {
                  q(!1);
                },
                onSearch: (e, t, n) => {
                  console.log("abscissa", t),
                    console.log("ordinate", n),
                    e && We(e);
                },
                geoCodeFeatures: O.filter((e) => "pc_subareas" === e.table),
              }),
            (0, o.jsxs)(f.Z, {
              sx: {
                display: "flex",
                flexDirection: "row",
                height: "calc(100vh - 64px)",
              },
              children: [
                (0, o.jsxs)(f.Z, {
                  sx: { flexGrow: 1, transition: "margin-left 0.3s ease" },
                  children: [
                    (0, o.jsx)("div", {
                      id: "map",
                      style: { height: "100%", width: "100%" },
                    }),
                    (0, o.jsxs)(f.Z, {
                      sx: {
                        position: "absolute",
                        left: 20,
                        top: 100,
                        width: 150,
                        display: "flex",
                        flexDirection: "column",
                      },
                      children: [
                        (0, o.jsx)("div", {
                          ref: se,
                          children: (0, o.jsx)(oe.default, {
                            src: J ? "/measure_active.png" : "/measure.png",
                            alt: J ? "measure_active" : "measure",
                            width: 64,
                            height: 64,
                            onClick: Ce,
                            style: { cursor: "pointer" },
                          }),
                        }),
                        (0, o.jsx)("div", {
                          ref: fe,
                          children: (0, o.jsx)(oe.default, {
                            src: me ? "/layers_active.png" : "/layers.png",
                            alt: me ? "layers_active" : "layers",
                            width: 64,
                            height: 64,
                            style: { cursor: "pointer" },
                            onClick: Pe,
                          }),
                        }),
                        (0, o.jsx)(oe.default, {
                          src: "/legend.png",
                          alt: "Legend",
                          width: 64,
                          height: 64,
                          style: { cursor: "pointer" },
                          onClick: Ue(),
                        }),
                      ],
                    }),
                    (0, o.jsx)(f.Z, {
                      sx: {
                        position: "absolute",
                        right: { xs: "10px", md: "20%" },
                        top: 100,
                        width: 80,
                        display: "flex",
                        flexDirection: "column",
                      },
                      children: (0, o.jsx)("div", {
                        ref: ge,
                        children: (0, o.jsx)(oe.default, {
                          src: "/icon_ geocode.png",
                          alt: "icon_ geocode",
                          width: 64,
                          height: 64,
                          onClick: Ie,
                          style: { cursor: "pointer" },
                        }),
                      }),
                    }),
                    te &&
                      E &&
                      (0, o.jsx)(re, {
                        map: E,
                        popupVisible: J,
                        setPopupVisible: K,
                        iconPosition: te,
                        vectorSource: _e.current,
                      }),
                    xe &&
                      1 == me &&
                      (0, o.jsx)(he, {
                        iconPosition: xe,
                        onToggleLayer: (e, t) => {
                          switch (e) {
                            case "osm":
                              Ze && Ze.setVisible(t);
                              break;
                            case "road":
                              we && we.setVisible(t);
                              break;
                            case "arial":
                              ve && ve.setVisible(t);
                          }
                        },
                        onOpacityChange: (e, t) => {
                          const n = t / 100;
                          switch (e) {
                            case "osm":
                              Ze && Ze.setOpacity(n);
                              break;
                            case "road":
                              we && we.setOpacity(n);
                              break;
                            case "arial":
                              ve && ve.setOpacity(n);
                          }
                        },
                      }),
                    qe &&
                      (0, o.jsxs)(f.Z, {
                        sx: {
                          position: "absolute",
                          top: "100px",
                          left: "50%",
                          transform: "translateX(-50%)",
                          zIndex: 1e3,
                          textAlign: "center",
                          display: "flex",
                          flexDirection: "row",
                          alignItems: "center",
                        },
                        children: [
                          (0, o.jsx)(Z.Z, {
                            size: 24,
                            sx: { color: P.Z.palette.primary.main },
                          }),
                          (0, o.jsx)(y.Z, {
                            variant: "body1",
                            sx: { ml: 1, color: P.Z.palette.primary.main },
                            children: "Loading...",
                          }),
                        ],
                      }),
                  ],
                }),
                (0, o.jsx)(f.Z, {
                  sx: {
                    width: n ? "20%" : "0",
                    transition: "width 0.3s ease",
                    overflow: "hidden",
                    position: "absolute",
                    height: "100%",
                    minWidth: n ? "250px" : "0",
                    backgroundColor: "white",
                    boxShadow: n ? "2px 0 5px rgba(0, 0, 0, 0.5)" : "none",
                  },
                  children: (0, o.jsxs)(f.Z, {
                    sx: {
                      position: "absolute",
                      top: 0,
                      left: 0,
                      height: "100%",
                      width: "100%",
                      display: "flex",
                      flexDirection: "column",
                    },
                    children: [
                      (0, o.jsxs)(f.Z, {
                        sx: {
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                          marginBottom: "5px",
                          backgroundColor: "#f5f5f5",
                          padding: "16px",
                          height: "34px",
                        },
                        children: [
                          (0, o.jsx)(y.Z, {
                            variant: "h6",
                            component: "div",
                            color: P.Z.palette.primary.main,
                            children: "Legend",
                          }),
                          (0, o.jsx)(m.Z, {
                            edge: "end",
                            color: "inherit",
                            onClick: Ue(),
                            children: (0, o.jsx)(p.Z, {}),
                          }),
                        ],
                      }),
                      C &&
                        (0, o.jsx)(_, {
                          thematics: C.thematics,
                          onLayerClick: (e) => {
                            Ve(e, "", S.vK);
                          },
                          loadedLayers: F,
                        }),
                    ],
                  }),
                }),
                (() => {
                  const e = () => {
                    H(!U);
                  };
                  (0, j.QS)({
                    onSwipedDown: () => H(!1),
                    preventDefaultTouchmoveEvent: !0,
                    trackMouse: !0,
                  });
                  return (0, o.jsxs)(o.Fragment, {
                    children: [
                      (0, o.jsx)(f.Z, {
                        sx: {
                          position: "fixed",
                          bottom: "20px",
                          right: "20px",
                          zIndex: 1e3,
                          display: { xs: "block", md: "none" },
                        },
                        children: (0, o.jsx)(m.Z, {
                          onClick: e,
                          sx: {
                            backgroundColor: "#fff",
                            boxShadow: "0px 2px 10px rgba(0, 0, 0, 0.2)",
                          },
                          children: (0, o.jsx)(Le.Z, {
                            icon: "mdi:menu",
                            fontSize: 24,
                          }),
                        }),
                      }),
                      (0, o.jsx)(f.Z, {
                        sx: {
                          position: { xs: "fixed", md: "relative" },
                          bottom: { xs: 0, md: "auto" },
                          right: { xs: 0, md: 0 },
                          height: { xs: U ? "40vh" : "0", md: "100%" },
                          width: { xs: "100%", md: Q ? "20%" : "0" },
                          backgroundColor: "#f5f5f5",
                          boxShadow: {
                            xs: U ? "0px -2px 5px rgba(0, 0, 0, 0.5)" : "none",
                            md: Q ? "2px -2px 5px rgba(0, 0, 0, 0.5)" : "none",
                          },
                          transition: "height 0.3s ease, width 0.3s ease",
                          overflowY: "auto",
                          zIndex: 999,
                        },
                        children: (0, o.jsx)(Fe, {
                          isLoading: ae,
                          feature: $ ? $.feature : null,
                          coordinates: $ ? $.coordinates : [0, 0],
                          geocode: $ ? $.geocode : "",
                          options: O,
                          onSearchGeoCodeClick: (t) => {
                            e(), We(t);
                          },
                        }),
                      }),
                    ],
                  });
                })(),
              ],
            }),
          ],
        });
      }
      var Be = () =>
        (0, o.jsxs)(r.Suspense, {
          fallback: (0, o.jsx)(v, {}),
          children: [" ", (0, o.jsx)(Oe, {})],
        });
    },
    28675: function (e, t, n) {
      "use strict";
      n.d(t, {
        CG: function () {
          return a;
        },
        TL: function () {
          return i;
        },
        tm: function () {
          return l;
        },
      });
      var o = n(11444),
        r = n(2265);
      const i = () => (0, o.I0)(),
        a = o.v9;
      function l() {
        const e = (0, r.useRef)(!0),
          t = (0, r.useCallback)(() => e.current, []);
        return (
          (0, r.useEffect)(
            () => () => {
              e.current = !1;
            },
            []
          ),
          t
        );
      }
    },
    21949: function (e, t, n) {
      "use strict";
      const o = (0, n(29030).Z)({
        palette: {
          primary: {
            main: "#31317F",
            light: "#63a4ff",
            dark: "#004ba0",
            contrastText: "#fff",
          },
          secondary: {
            main: "#dc004e",
            light: "#ff616f",
            dark: "#9a0036",
            contrastText: "#fff",
          },
          background: { default: "#f5f5f5" },
          text: { primary: "#000", secondary: "#555" },
        },
        typography: {
          fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
          h1: { fontSize: "2.2rem" },
          h2: { fontSize: "1.8rem" },
        },
      });
      t.Z = o;
    },
  },
  function (e) {
    e.O(
      0,
      [
        5734, 8507, 8622, 2795, 8472, 309, 3504, 1444, 3983, 9903, 5090, 3154,
        3173, 4840, 8868, 8117, 5744, 2971, 7023, 1744,
      ],
      function () {
        return (t = 68032), e((e.s = t));
        var t;
      }
    );
    var t = e.O();
    _N_E = t;
  },
]);
